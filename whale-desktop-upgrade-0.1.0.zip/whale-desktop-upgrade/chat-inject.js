// chat-inject.js —— 「聊天映射」在挂件页面里的显示层
// 不新造气泡：复用它自带的那个气泡（.dshwv-pop），消息来了把气泡内容换成消息并打开。
//   停留时长按字数自动算（可配，最长 20 秒）
//   点一下：气泡放大看全文；再点一下：缩回
//   长按 1 秒：让位给余额显示，然后自动关掉
(function () {
  if (window.__whaleChat) return 'exists'

  var CFG = {
    baseDuration: 4000, // 基础停留（毫秒）
    perChar: 80, // 每个字加多少毫秒
    maxDuration: 20000, // 最长停留
    maxChars: 0, // 收起时截到多少字（0 = 不截，超出靠展开看）
    showFrom: true, // 是否显示「谁说的」
    scale: 1 // 字号倍数
  }

  var timer = null
  var showing = false
  var hadOpen = false // 借用时气泡本来是开着的吗
  var observer = null
  var zoomed = false
  var pressTimer = null
  var longFired = false

  var STYLE_ID = 'dshwv-chat-style'
  var CSS = [
    // 消息态：气泡里除了「形状」和「我们的话」，别的一律藏起来
    '.dshwv-pop.dshwv-chat-mode > *:not(.dshwv-chat-say):not(.dshwv-shapewrap){visibility:hidden !important}',
    '.dshwv-pop.dshwv-chat-mode > .dshwv-chat-say{opacity:1 !important;visibility:visible !important;',
    'white-space:normal !important;pointer-events:auto;cursor:pointer;overflow:hidden;',
    'left:46% !important;top:36% !important;width:57% !important;height:47% !important}',
    // 放大：整只气泡放大，以尾巴为锚点；字按比例收回来，能多装字
    '.dshwv-pop.dshwv-chat-zoom{transform:scale(1.62) !important;transform-origin:50% 92%;',
    'transition:transform .22s cubic-bezier(.34,1.4,.64,1);z-index:6}',
    '.dshwv-pop.dshwv-chat-zoom > .dshwv-chat-say{cursor:zoom-out}',
    '.dshwv-chat-say{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}',
    '.dshwv-chat-say .dshwv-chat-from{font-size:calc(var(--dshw-u) * 52);font-weight:600;',
    'letter-spacing:.06em;opacity:.62;margin-bottom:calc(var(--dshw-u) * 8);white-space:nowrap}',
    '.dshwv-chat-say .dshwv-chat-text{font-size:calc(var(--dshw-u) * 66);font-weight:700;line-height:1.32;',
    'white-space:pre-wrap;word-break:break-word;max-height:100%;overflow:hidden;min-height:0;',
    'display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:4}',
    // 展开：字按 1/1.62 缩回原来的观感，区域却大了，还能滑着看全文（滚动条藏起来）
    '.dshwv-pop.dshwv-chat-zoom .dshwv-chat-text{font-size:calc(var(--dshw-u) * 39) !important;',
    'line-height:1.42;display:block;overflow-y:auto;overflow-x:hidden;scrollbar-width:none;-ms-overflow-style:none}',
    '.dshwv-pop.dshwv-chat-zoom .dshwv-chat-from{font-size:calc(var(--dshw-u) * 32) !important}',
    '.dshwv-pop.dshwv-chat-zoom .dshwv-chat-text::-webkit-scrollbar{width:0;height:0;display:none}'
  ].join('\n')

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return
    var st = document.createElement('style')
    st.id = STYLE_ID
    st.textContent = CSS
    ;(document.head || document.documentElement).appendChild(st)
  }

  function dom() {
    var pop = document.querySelector('.dshwv-pop')
    return pop ? { pop: pop } : null
  }

  /** 停留时长：字数越多停越久，卡在 [1.5s, maxDuration] */
  function autoDuration(len) {
    var base = Number(CFG.baseDuration) > 0 ? Number(CFG.baseDuration) : 4000
    var per = Number(CFG.perChar) >= 0 ? Number(CFG.perChar) : 80
    var max = Number(CFG.maxDuration) > 0 ? Number(CFG.maxDuration) : 20000
    var v = base + Math.max(0, len) * per
    return Math.round(Math.max(1500, Math.min(max, v)))
  }

  function armTimer(ms) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(function () {
      timer = null
      cleanup(hadOpen)
    }, Math.max(800, ms))
  }

  function watch() {
    if (observer || typeof MutationObserver !== 'function') return
    var d = dom()
    if (!d) return
    observer = new MutationObserver(function () {
      if (!showing) return
      // 原生把气泡收起来了：我们也收拾干净（别再把它顶开）
      if (!d.pop.classList.contains('dshwv-pop-open')) cleanup(false)
    })
    try {
      observer.observe(d.pop, { attributes: true, attributeFilter: ['class'], subtree: false })
    } catch (err) {}
  }

  /** keepOpen=true 表示原先气泡就在显示，走的时候不要替它关 */
  function cleanup(keepOpen) {
    if (timer) {
      clearTimeout(timer)
      timer = null
    }
    if (pressTimer) {
      clearTimeout(pressTimer)
      pressTimer = null
    }
    showing = false
    zoomed = false
    var d = dom()
    if (!d) return
    try {
      d.pop.classList.remove('dshwv-chat-mode')
      d.pop.classList.remove('dshwv-chat-zoom')
      var say = d.pop.querySelector('.dshwv-chat-say')
      if (say && say.parentNode) say.parentNode.removeChild(say)
      if (!keepOpen) {
        d.pop.classList.remove('dshwv-pop-open')
        var tx = d.pop.querySelector('.dshwv-text')
        if (tx) tx.style.opacity = ''
      }
    } catch (err) {}
  }

  function toggleZoom() {
    var d = dom()
    if (!d || !showing) return
    if (!zoomed) {
      zoomed = true
      d.pop.classList.add('dshwv-chat-zoom')
      if (timer) {
        clearTimeout(timer)
        timer = null
      }
    } else {
      zoomed = false
      d.pop.classList.remove('dshwv-chat-zoom')
      armTimer(autoDuration(String(lastText).length))
    }
  }

  /** 长按：让位给余额（主进程收到后会去刷新余额），然后关掉 */
  function longPress() {
    var d = dom()
    cleanup(true)
    try {
      if (window.whaleShell && window.whaleShell.chatEvent) window.whaleShell.chatEvent('longpress')
    } catch (err) {}
    if (!d) return
  }

  function bindPress(say) {
    say.addEventListener('pointerdown', function (e) {
      e.preventDefault()
      e.stopPropagation()
      longFired = false
      if (pressTimer) clearTimeout(pressTimer)
      pressTimer = setTimeout(function () {
        pressTimer = null
        longFired = true
        longPress()
      }, 1000)
    })
    var end = function (e) {
      if (e) {
        e.preventDefault()
        e.stopPropagation()
      }
      if (pressTimer) {
        clearTimeout(pressTimer)
        pressTimer = null
      }
      if (!longFired) toggleZoom()
      longFired = false
    }
    say.addEventListener('pointerup', end)
    say.addEventListener('pointercancel', function () {
      if (pressTimer) {
        clearTimeout(pressTimer)
        pressTimer = null
      }
      longFired = false
    })
  }

  var lastText = ''

  function push(msg) {
    try {
      if (!msg || typeof msg !== 'object') return 'bad'
      var text = String(msg.text == null ? '' : msg.text)
      if (!text.trim()) return 'empty'
      ensureStyle()
      var d = dom()
      if (!d) return 'no-dom'
      watch()

      var fullText = text
      var shown = fullText
      var cap = Number(CFG.maxChars) || 0
      if (cap > 0 && shown.length > cap) shown = shown.slice(0, cap - 1) + '…'
      var from = msg.from ? String(msg.from) : ''
      lastText = fullText

      // 连发时先把上一条收掉，但别把原生开着的气泡关了
      if (showing) cleanup(hadOpen)
      hadOpen = d.pop.classList.contains('dshwv-pop-open')

      var say = d.pop.querySelector('.dshwv-chat-say')
      if (!say) {
        say = document.createElement('div')
        // 借 .dshwv-text 的定位/居中/配色，再叠我们自己的名字
        say.className = 'dshwv-text dshwv-chat-say'
        d.pop.appendChild(say)
        bindPress(say)
      }
      say.textContent = ''
      if (from && CFG.showFrom !== false) {
        var f = document.createElement('div')
        f.className = 'dshwv-chat-from'
        f.textContent = from
        say.appendChild(f)
      }
      var t = document.createElement('div')
      t.className = 'dshwv-chat-text' + (shown.length > 46 ? ' dshwv-chat-small' : '')
      t.textContent = shown
      say.appendChild(t)

      var sc = Number(CFG.scale)
      say.style.fontSize = sc > 0 && sc !== 1 ? sc + 'em' : ''
      say.style.opacity = '1'
      d.pop.classList.add('dshwv-chat-mode')
      d.pop.classList.add('dshwv-pop-open')
      showing = true
      zoomed = false

      var dur = Number(msg.duration) > 0 ? Number(msg.duration) : autoDuration(fullText.length)
      armTimer(dur)
      return 'ok'
    } catch (e) {
      return 'err:' + String((e && e.message) || e)
    }
  }

  function clear() {
    cleanup(false)
    return 'ok'
  }

  window.__whaleChat = {
    push: push,
    clear: clear,
    zoom: function (v) {
      var d = dom()
      if (!d || !showing) return 'idle'
      var want = v === undefined ? !zoomed : !!v
      if (want !== zoomed) toggleZoom()
      return zoomed ? 'zoom' : 'normal'
    },
    cfg: function (patch) {
      if (patch && typeof patch === 'object') {
        for (var k in patch) {
          if (Object.prototype.hasOwnProperty.call(patch, k) && CFG[k] !== undefined) CFG[k] = patch[k]
        }
      }
      return JSON.stringify(CFG)
    },
    state: function () {
      var d = dom()
      return JSON.stringify({
        showing: showing,
        zoomed: zoomed,
        mode: d ? d.pop.classList.contains('dshwv-chat-mode') : false,
        open: d ? d.pop.classList.contains('dshwv-pop-open') : false,
        cfg: CFG,
        hasPop: !!d
      })
    }
  }

  return 'ready'
})()
