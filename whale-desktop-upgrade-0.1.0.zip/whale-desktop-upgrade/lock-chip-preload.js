// lock-chip-preload.js —— 锁定后浮在挂件上的那颗「解锁小锁」
// 它是个独立小窗（不受主窗口穿透影响），点一下就解锁
const { ipcRenderer } = require('electron')

function bind() {
  document.addEventListener(
    'mousedown',
    (e) => {
      try {
        e.preventDefault()
        e.stopPropagation()
      } catch (err) {}
      ipcRenderer.send('whale:lock-chip-click')
    },
    true
  )
}

if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', bind)
else bind()
