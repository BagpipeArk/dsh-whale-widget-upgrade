// host-shim.mjs —— 给 dsh-whale-widget 造一个「假 DSH 宿主」
// 目的：原插件 lib/index.js 是 cordis 插件，依赖 ctx.webServer / ctx.credentials / ctx.connection /
// ctx.deepseekAccount 等宿主服务。这里把这几样最小实现出来，并把它们挂到一个本地 HTTP 服务上，
// 于是插件全部 22 条 /dsh-whale/* 路由、记账、气泡、角色、音效、设置功能都能原样跑起来 —— 不再需要 DSH。
import http from 'node:http'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { isPatched } from './patch-vendor.mjs'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const WIDGET_DIR = path.join(ROOT, 'vendor', 'whale-widget')

export const DEFAULT_DSH_HOME =
  process.env.WHALE_HOME || process.env.DSH_HOME || path.join(os.homedir(), '.dsh')

// ---------- 凭据服务（替代 DSH 的 ctx.credentials） ----------
class CredentialStore {
  constructor(home) {
    this.file = path.join(home, '.whale-standalone-credentials.json')
    this.data = {}
    try {
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'))
      if (parsed && typeof parsed === 'object') this.data = parsed
    } catch (err) {}
  }
  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true })
      fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2), { encoding: 'utf8', mode: 0o600 })
    } catch (err) {}
  }
  async resolve(ref) {
    const key = String(ref || '').trim()
    if (!key) return { key, value: '' }
    const env = process.env[key]
    if (env) return { key, value: String(env) }
    const hit = this.data[key]
    return { key, value: hit == null ? '' : String(hit) }
  }
  async set(ref, value) {
    const key = String(ref || '').trim()
    if (!key) throw new Error('bad credential ref')
    this.data[key] = String(value == null ? '' : value)
    this.save()
  }
  async unset(ref) {
    const key = String(ref || '').trim()
    delete this.data[key]
    this.save()
  }
  async list() {
    return Object.keys(this.data)
  }
}

// ---------- 连接栅栏（替代 DSH 的 ctx.connection） ----------
// 我们自己就是唯一的页面来源，只监听回环；插件自己的第一层校验已经足够，这里直接放行。
const connectionService = {
  requestRejection() {
    return false
  },
}

// ---------- HTTP 服务（替代 DSH 的 ctx.webServer） ----------
function createWebServer() {
  const routes = []
  const indexTappers = []
  return {
    routes,
    indexTappers,
    service: {
      register(route) {
        if (route && route.path) routes.push(route)
        const idx = routes.length - 1
        return () => {
          const i = routes.indexOf(routes[idx])
          if (i >= 0) routes.splice(i, 1)
        }
      },
      tapIndex(fn) {
        if (typeof fn === 'function') indexTappers.push(fn)
        return () => {
          const i = indexTappers.indexOf(fn)
          if (i >= 0) indexTappers.splice(i, 1)
        }
      },
    },
  }
}

function matchRoute(routes, pathname) {
  for (const r of routes) {
    if (r.kind === 'prefix') {
      if (pathname === r.path || pathname.startsWith(r.path.replace(/\/$/, '') + '/')) return r
    } else if (pathname === r.path) {
      return r
    }
  }
  return null
}

const MIME_TABLE = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.moc3': 'application/octet-stream',
  '.moc': 'application/octet-stream',
  '.wav': 'audio/wav',
  '.mp3': 'audio/mpeg',
}

function mimeOf(file) {
  return MIME_TABLE[path.extname(file).toLowerCase()] || 'application/octet-stream'
}

/** 把 URL 里的相对路径拼到 base 下；越界（..）返回 null。 */
function safeJoin(base, rel) {
  const root = path.resolve(base)
  const target = path.resolve(root, rel)
  if (target !== root && !target.startsWith(root + path.sep)) return null
  return target
}

const BASE_PAGE_HEAD = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>小鲸鱼</title>
<style>
  html, body { margin: 0; padding: 0; width: 100%; height: 100%; background: transparent; overflow: hidden; }
  body { -webkit-user-select: none; user-select: none; }
</style>
</head>
<body>`

// 兜底特征位：widget.js 若还没打补丁，启动前会自检「是不是 DSH 主聊天界面」，
// 判据是 #root 里存在 composer 输入区。补丁已打（默认）时这里什么都不需要放。
const FAKE_COMPOSER = `
<div id="root" aria-hidden="true" style="position:fixed;left:-10000px;top:-10000px;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none"><textarea tabindex="-1"></textarea></div>`

const BASE_PAGE_TAIL = `
</body>
</html>`

function buildPage(patched) {
  return BASE_PAGE_HEAD + (patched ? '' : FAKE_COMPOSER) + BASE_PAGE_TAIL
}

/**
 * 启动假宿主。
 * @param {{home?: string, port?: number, account?: object, onLog?: (s:string)=>void}} opts
 */
export async function startHost(opts = {}) {
  const home = opts.home || DEFAULT_DSH_HOME
  const log = opts.onLog || ((s) => console.log('[whale-host] ' + s))

  // 插件内部按 process.env.DSH_HOME 决定数据目录 —— 这里统一钉死，避免落到奇怪的位置
  process.env.DSH_HOME = home

  const creds = new CredentialStore(home)
  const patched = isPatched()
  log('widget.js 自检补丁：' + (patched ? '已生效' : '未生效（将用假输入框兜底）'))
  const web = createWebServer()
  const listeners = new Map()

  const account = opts.account || null // 由 web-balance 注入；没有就退化成「未登录」

  const ctx = {
    // 插件同时用「属性直取」和「ctx.get(name)」两种方式，两边都得给
    webServer: web.service,
    credentials: creds,
    connection: connectionService,
    get(name) {
      if (name === 'webServer') return web.service
      if (name === 'credentials') return creds
      if (name === 'connection') return connectionService
      if (name === 'deepseekAccount') return account
      return null
    },
    on(event, fn) {
      const arr = listeners.get(event) || []
      arr.push(fn)
      listeners.set(event, arr)
      return () => {
        const list = listeners.get(event) || []
        const i = list.indexOf(fn)
        if (i >= 0) list.splice(i, 1)
      }
    },
    effect(fn) {
      const d = typeof fn === 'function' ? fn() : null
      return typeof d === 'function' ? d : () => {}
    },
    emit(event, ...args) {
      for (const fn of (listeners.get(event) || []).slice()) {
        try {
          fn(...args)
        } catch (err) {}
      }
    },
  }

  const root = {
    ...ctx,
    inject(names, cb) {
      // 假宿主里所有服务都是现成的，直接同步回调
      return cb ? cb(ctx) : undefined
    },
  }

  const pluginUrl = new URL('file://' + path.join(WIDGET_DIR, 'lib', 'index.js').replace(/\\/g, '/'))
  const mod = await import(pluginUrl.href)
  const plugin = mod.default || mod
  log('加载插件 ' + (plugin && plugin.name ? plugin.name : 'whale') + ' ...')
  if (!plugin || typeof plugin.apply !== 'function') throw new Error('插件没有 apply()')
  plugin.apply(root)
  log('已注册路由 ' + web.routes.length + ' 条')

  const server = http.createServer((req, res) => {
    let pathname = '/'
    try {
      pathname = new URL(req.url || '/', 'http://127.0.0.1').pathname
    } catch (err) {}

    // 控制中心页面：与挂件同源（同 origin 才能共用 localStorage 里的吸附/位置记忆）
    if (pathname === '/control.html' || pathname === '/control.js' || pathname === '/control.css') {
      const file = path.join(ROOT, pathname.slice(1))
      if (!fs.existsSync(file)) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('missing ' + pathname)
        return
      }
      const type =
        pathname.endsWith('.js') ? 'text/javascript; charset=utf-8'
          : pathname.endsWith('.css') ? 'text/css; charset=utf-8'
            : 'text/html; charset=utf-8'
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' })
      res.end(fs.readFileSync(file))
      return
    }

    // Live2D 运行库（core / pixi / display）
    if (pathname.startsWith('/whale-lib/')) {
      const rel = decodeURIComponent(pathname.slice('/whale-lib/'.length))
      const file = safeJoin(path.join(ROOT, 'web', 'live2d', 'lib'), rel)
      if (!file) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('forbidden')
        return
      }
      if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('missing')
        return
      }
      res.writeHead(200, { 'Content-Type': mimeOf(file), 'Cache-Control': 'no-cache' })
      res.end(fs.readFileSync(file))
      return
    }

    // Live2D 模型文件（含 moc3 / 贴图 / 动作 / 表情）
    if (pathname.startsWith('/whale-l2d/')) {
      const rel = decodeURIComponent(pathname.slice('/whale-l2d/'.length))
      const base = opts.live2dDir || path.join(ROOT, 'live2d-models')
      const file = safeJoin(base, rel)
      if (!file) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('forbidden')
        return
      }
      if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('missing')
        return
      }
      res.writeHead(200, { 'Content-Type': mimeOf(file), 'Cache-Control': 'no-cache' })
      res.end(fs.readFileSync(file))
      return
    }

    if (pathname === '/' || pathname === '/index.html' || pathname === '/desktop.html') {
      let html = buildPage(patched)
      for (const tap of web.indexTappers) {
        try {
          const out = tap(html)
          if (typeof out === 'string' && out) html = out
        } catch (err) {}
      }
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store',
      })
      res.end(html)
      return
    }

    const route = matchRoute(web.routes, pathname)
    if (!route) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
      res.end('not found')
      return
    }
    try {
      route.handler(req, res)
    } catch (err) {
      try {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' })
        res.end('handler error: ' + String((err && err.message) || err))
      } catch (e2) {}
    }
  })

  const port = await new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(opts.port || 0, '127.0.0.1', () => resolve(server.address().port))
  })

  return {
    home,
    port,
    url: 'http://127.0.0.1:' + port + '/',
    ctx,
    credentials: creds,
    server,
    routes: web.routes,
    close() {
      try {
        server.close()
      } catch (err) {}
    },
  }
}
