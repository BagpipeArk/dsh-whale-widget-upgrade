# -*- coding: utf-8 -*-
"""鲸鱼娘桌宠 · 共用的大模型调用

从 AstrBot 的 cmd_config.json 里挑一个可用的对话模型（OpenAI 兼容协议），
供窥屏分析和语音聊天共用；每次调用都重读配置，改了模型不用重启。
"""
import json
import os
import urllib.error
import urllib.request

import whale_paths


_VISION_HINTS = (
    "gpt-4o", "gpt-4.1", "gpt-5", "vision", "vl-", "-vl", "omni", "claude",
    "gemini", "glm-4v", "qwen-vl", "minicpm-v", "internvl", "llava", "step-1v",
)


def _looks_vision(model):
    m = str(model or "").lower()
    return any(h in m for h in _VISION_HINTS)


def load_provider(prefer_vision=False):
    """返回 (api_base, api_key, model)。

    prefer_vision=True 时优先挑看起来能看图的模型（语音聊天要带上屏幕画面时用），
    挑不到就退回普通对话模型，靠调用方降级。
    """
    path = whale_paths.astrbot_config()
    if not path or not os.path.isfile(path):
        raise RuntimeError(
            "找不到模型配置：请在 paths.json 里填 astrbotConfig，"
            "或设 ASTRBOT_CONFIG 指向 cmd_config.json；也可以把配置放成 <根目录>/astrbot.json"
        )
    with open(path, encoding="utf-8-sig") as f:
        cfg = json.load(f)

    sources = {s.get("id"): s for s in (cfg.get("provider_sources") or [])}
    providers = cfg.get("provider") or []
    if isinstance(providers, dict):
        providers = list(providers.values())

    found = []
    for p in providers:
        if not isinstance(p, dict):
            continue
        if p.get("enable") is False:
            continue
        if p.get("type") and "tts" in str(p.get("type")).lower():
            continue
        src = sources.get(p.get("provider_source_id") or "") or {}
        keys = src.get("key") or []
        if isinstance(keys, str):
            keys = [keys]
        key = (keys[0] if keys else "") or ""
        base = (src.get("api_base") or "").rstrip("/")
        model = p.get("model") or ""
        if key and base and model:
            found.append((base, key, model))
    if not found:
        raise RuntimeError("配置里没找到可用的对话模型")
    if prefer_vision:
        yes = [x for x in found if _looks_vision(x[2])]
        found = yes + [x for x in found if x not in yes]
    return found[0]


def load_providers(prefer_vision=False):
    """返回按优先级排好的全部候选 [(api_base, api_key, model)]。

    cmd_config 里同一个模型可能挂在不同账号下，某个账号没开通会直接 400/404，
    所以调用方要能挨个试过去，而不是认死第一个。
    """
    path = whale_paths.astrbot_config()
    if not path or not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8-sig") as f:
        cfg = json.load(f)
    sources = {s.get("id"): s for s in (cfg.get("provider_sources") or [])}
    providers = cfg.get("provider") or []
    if isinstance(providers, dict):
        providers = list(providers.values())
    out, seen = [], set()
    for p in providers:
        if not isinstance(p, dict) or p.get("enable") is False:
            continue
        if p.get("type") and "tts" in str(p.get("type")).lower():
            continue
        src = sources.get(p.get("provider_source_id") or "") or {}
        keys = src.get("key") or []
        if isinstance(keys, str):
            keys = [keys]
        key = (keys[0] if keys else "") or ""
        base = (src.get("api_base") or "").rstrip("/")
        model = p.get("model") or ""
        if not (key and base and model):
            continue
        sig = (base, key[:8], model)
        if sig in seen:
            continue
        seen.add(sig)
        out.append((base, key, model))
    if prefer_vision:
        yes = [x for x in out if _looks_vision(x[2])]
        out = yes + [x for x in out if x not in yes]
    return out


def _call(base, key, model, messages, temperature, max_tokens, timeout):
    body = json.dumps(
        {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        },
        ensure_ascii=False,
    ).encode("utf-8")
    req = urllib.request.Request(
        base + "/chat/completions",
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + key,
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8", "replace"))
    choices = data.get("choices") or []
    if not choices:
        raise RuntimeError("模型没有返回内容")
    msg = choices[0].get("message") or {}
    return (msg.get("content") or "").strip()


def chat(messages, temperature=0.8, max_tokens=400, timeout=60, prefer_vision=False):
    """调一次对话补全，返回纯文本。按优先级挨个试账号，全失败才抛异常。"""
    cands = load_providers(prefer_vision=prefer_vision)
    if not cands:
        raise RuntimeError(
            "找不到模型配置：请在 paths.json 里填 astrbotConfig，或设 ASTRBOT_CONFIG"
        )
    errs = []
    for base, key, model in cands:
        try:
            return _call(base, key, model, messages, temperature, max_tokens, timeout)
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", "replace")[:160]
            except Exception:
                pass
            errs.append("%s: HTTP %s %s" % (model, exc.code, detail))
        except Exception as exc:
            errs.append("%s: %s" % (model, exc))
    raise RuntimeError("所有模型都没答上：\n" + "\n".join(errs[-4:]))
