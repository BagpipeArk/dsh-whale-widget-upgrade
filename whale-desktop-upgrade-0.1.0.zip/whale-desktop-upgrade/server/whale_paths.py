# -*- coding: utf-8 -*-
"""鲸鱼娘桌宠 · 路径配置

所有「本机绝对路径」都从这里拿，发布出去的副本里不会再出现写死的 C:\\Users\\xxx。

优先级一律是：环境变量 > <根目录>/paths.json > 相对路径。
paths.json 的模板见根目录的 paths.example.json。
"""
import json
import os
import sys

BASE = os.environ.get("WHALE_HOME") or os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)
if BASE not in sys.path:
    sys.path.append(BASE)

_cache = None


def _load():
    """读 paths.json（UTF-8 带 BOM 也能读），失败就返回空字典。"""
    for p in (
        os.path.join(BASE, "paths.json"),
        os.path.join(BASE, "config", "paths.json"),
    ):
        try:
            with open(p, encoding="utf-8-sig") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except Exception:
            continue
    return {}


def get(key, default=""):
    """取 paths.json 里的一个值；空值或缺失时返回 default。"""
    global _cache
    if _cache is None:
        _cache = _load()
    v = _cache.get(key)
    if isinstance(v, str) and v.strip():
        return os.path.expandvars(os.path.expanduser(v.strip()))
    return default


def first_existing(*cands):
    """按顺序返回第一个真实存在的文件，都没有就返回空串。"""
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return ""


def astrbot_config():
    """AstrBot 的 cmd_config.json：环境变量 > paths.json > <根目录>/astrbot.json。"""
    return (
        os.environ.get("ASTRBOT_CONFIG")
        or first_existing(
            get("astrbotConfig"),
            os.path.join(BASE, "astrbot.json"),
        )
    )


def ref_audio():
    """参考音频：环境变量 > paths.json > <根目录>/ref/ref.wav > GPT-SoVITS 的 ref_audio 里找一个。"""
    env = os.environ.get("WHALE_REF_AUDIO")
    if env and os.path.isfile(env):
        return env
    got = first_existing(
        get("WHALE_REF_AUDIO"),
        os.path.join(BASE, "ref", "ref.wav"),
    )
    if got:
        return got
    gsv = get("gsvDir")
    if gsv:
        box = os.path.join(gsv, "ref_audio")
        if os.path.isdir(box):
            for dirpath, _dirs, files in os.walk(box):
                for name in sorted(files):
                    if name.lower().endswith(".wav"):
                        return os.path.join(dirpath, name)
    return ""


def stt_model_dir():
    """faster-whisper 模型目录：环境变量 > paths.json > <根目录>/models。"""
    return (
        os.environ.get("WHALE_STT_MODEL_DIR")
        or get("WHALE_STT_MODEL_DIR")
        or os.path.join(BASE, "models")
    )
