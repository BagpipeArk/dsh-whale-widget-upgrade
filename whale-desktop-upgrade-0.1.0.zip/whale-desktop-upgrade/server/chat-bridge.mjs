// chat-bridge.mjs —— 「聊天映射」的桥接服务
//
// 目的：让桌宠能显示「别的 agent 发来的话」。
// 做法：起一个只监听回环地址的小 HTTP 服务，任何渠道（AstrBot / DSH / GPT / Claude / 自建脚本）
//       只要 POST 一条 JSON 过来，消息就会被送进挂件气泡。渠道适配留给外部，这里只定协议。
//
// 端点：
//   GET  /chat/health          健康检查 + 能力清单
//   POST /chat/push            推一条消息（核心）
//   GET  /chat/history?limit=  最近收过的消息
//   POST /chat/clear           清空历史
//   GET  /chat/events          SSE：新消息实时推给订阅者
//   OPTIONS *                  CORS 预检

import http from 'node:http'
import crypto from 'node:crypto'

export const CHAT_DEFAULT = {
  on: false,
  port: 32169,
  host: '127.0.0.1', // 只想给局域网/别的机器用就改成 0.0.0.0（记得设 token）
  token: '', // 留空 = 不校验
  bubble: {
    on: true, // 关掉就只收消息不出气泡（例如只在历史里攒着）
    baseDuration: 4000, // 基础停留，毫秒
    perChar: 80, // 每个字加多少毫秒
    maxDuration: 20000, // 最长停留，毫秒
    maxChars: 0, // 收起时截到多少字，0 = 不截（长的靠点击展开看）
    showFrom: true,
    scale: 1
  },
  // 反向拉取：让别人不用改代码也能接（定时请求一个 URL，把返回里的某个字段当消息）
  poll: {
    on: false,
    interval: 30, // 秒
    method: 'GET',
    url: '',
    headers: '', // JSON 字符串，例如 {"Authorization":"Bearer xxx"}
    body: '', // POST 用，字符串
    pick: 'message', // 从响应 JSON 里取哪个字段，支持 a.b.c
    from: '远端',
    dedupe: true // 内容和上次一样就不重复弹
  }
}

function merge(base, patch) {
  const out = Object.assign({}, base)
  for (const k of Object.keys(patch || {})) {
    const v = patch[k]
    if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object') {
      out[k] = merge(base[k], v)
    } else if (v !== undefined) {
      out[k] = v
    }
  }
  return out
}

export function normalizeChat(raw) {
  return merge(CHAT_DEFAULT, raw || {})
}

function pickPath(obj, dotted) {
  let cur = obj
  for (const seg of String(dotted || '').split('.')) {
    if (!seg) continue
    if (cur == null) return undefined
    if (Array.isArray(cur) && /^\d+$/.test(seg)) cur = cur[Number(seg)]
    else cur = cur[seg]
  }
  return cur
}

/** 把各种来源的 body 归一化成 { text, from, channel } */
export function normalizeIncoming(body) {
  if (body == null) return null
  if (typeof body === 'string') return { text: body, from: '', channel: 'raw' }
  if (typeof body !== 'object') return { text: String(body), from: '', channel: 'raw' }

  // OneBot v11 / AstrBot 的 webhook 上报
  const isOneBot = body.post_type === 'message' || (body.message_type && body.raw_message != null)
  if (isOneBot) {
    const s = body.sender || {}
    const text = String(body.raw_message != null ? body.raw_message : body.message != null ? body.message : '')
    return {
      text,
      from: String(s.card || s.nickname || body.user_id || ''),
      channel: 'onebot:' + String(body.message_type || '')
    }
  }

  const text = body.text != null ? body.text : body.message != null ? body.message : body.content != null ? body.content : body.msg
  if (text == null) return null
  // message 可能是数组（各家 SDK 的 segment），只挑能读的部分
  const flat = Array.isArray(text)
    ? text.map((seg) => (seg && typeof seg === 'object' ? seg.text || seg.content || '' : String(seg))).join('')
    : typeof text === 'object'
      ? String(text.text || text.content || JSON.stringify(text))
      : String(text)
  return {
    text: flat,
    from: String(body.from || body.title || body.nickname || body.name || body.channel || ''),
    channel: String(body.channel || body.source || 'push')
  }
}

function readBody(req, limit = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', (c) => {
      size += c.length
      if (size > limit) {
        reject(new Error('body too large'))
        req.destroy()
        return
      }
      chunks.push(c)
    })
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

function send(res, code, obj, extraHeaders) {
  const text = typeof obj === 'string' ? obj : JSON.stringify(obj)
  res.writeHead(
    code,
    Object.assign(
      {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Whale-Token',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      extraHeaders || {}
    )
  )
  res.end(text)
}

/**
 * @param {{getConfig?:()=>object, onMessage:(msg:object)=>void, onLog?:(s:string)=>void}} opts
 */
export async function startChatBridge(opts = {}) {
  const log = opts.onLog || ((s) => console.log('[chat] ' + s))
  const onMessage = opts.onMessage || (() => {})
  const getConfig = opts.getConfig || (() => CHAT_DEFAULT)

  let cfg = normalizeChat(getConfig())
  const history = [] // 最近消息（内存）
  const subs = new Set() // SSE 订阅者
  let server = null
  let port = 0
  let running = false
  let lastError = ''
  let pollTimer = null
  let pollLast = ''
  let pollFails = 0

  const HISTORY_MAX = 200

  function tokenOk(req, url) {
    if (!cfg.token) return true
    const auth = String(req.headers['authorization'] || '')
    const bearer = auth.toLowerCase().startsWith('bearer ') ? auth.slice(7).trim() : ''
    const head = String(req.headers['x-whale-token'] || '')
    const qs = url && url.searchParams ? String(url.searchParams.get('token') || '') : ''
    return bearer === cfg.token || head === cfg.token || qs === cfg.token
  }

  function record(msg) {
    const item = {
      id: msg.id || crypto.randomBytes(6).toString('hex'),
      text: msg.text,
      from: msg.from,
      channel: msg.channel,
      at: Date.now()
    }
    history.unshift(item)
    if (history.length > HISTORY_MAX) history.length = HISTORY_MAX
    for (const res of subs) {
      try {
        res.write('data: ' + JSON.stringify(item) + '\n\n')
      } catch (err) {}
    }
    return item
  }

  /** 程序内部/控制中心也能用这条路径推消息 */
  function push(msg) {
    const norm = normalizeIncoming(msg)
    if (!norm || !String(norm.text || '').trim()) return { ok: false, error: '消息内容是空的' }
    const item = record(norm)
    if (cfg.bubble && cfg.bubble.on !== false) {
      try {
        onMessage(item)
      } catch (err) {
        log('气泡转发失败: ' + (err && err.message))
      }
    }
    return { ok: true, id: item.id, at: item.at }
  }

  async function handler(req, res) {
    let url
    try {
      url = new URL(req.url || '/', 'http://127.0.0.1')
    } catch (err) {
      send(res, 400, { ok: false, error: 'bad url' })
      return
    }
    const p = url.pathname

    if (req.method === 'OPTIONS') {
      send(res, 204, '')
      return
    }

    if (p === '/chat/health' || p === '/') {
      send(res, 200, {
        ok: true,
        name: 'whale-chat-bridge',
        version: '1.0.0',
        running,
        port,
        bubble: !!(cfg.bubble && cfg.bubble.on !== false),
        auth: !!cfg.token,
        endpoints: ['POST /chat/push', 'GET /chat/history', 'POST /chat/clear', 'GET /chat/events'],
        accept: {
          generic: { text: '文本', from: '可选，来者名字' },
          onebot: '原文照发（post_type=message 的上报体）直接兼容'
        }
      })
      return
    }

    if (!tokenOk(req, url)) {
      send(res, 401, { ok: false, error: 'token 不对' })
      return
    }

    if (p === '/chat/push') {
      if (req.method !== 'POST') {
        send(res, 405, { ok: false, error: '用 POST' })
        return
      }
      let raw = ''
      try {
        raw = await readBody(req)
      } catch (err) {
        send(res, 400, { ok: false, error: String(err && err.message) })
        return
      }
      let body
      try {
        body = raw.trim() ? JSON.parse(raw) : null
      } catch (err) {
        body = raw // 不是 JSON，就当纯文本消息
      }
      const out = push(body)
      send(res, out.ok ? 200 : 400, out)
      return
    }

    if (p === '/chat/history') {
      const limit = Math.max(1, Math.min(200, Number(url.searchParams.get('limit')) || 20))
      send(res, 200, { ok: true, items: history.slice(0, limit) })
      return
    }

    if (p === '/chat/clear') {
      if (req.method !== 'POST') {
        send(res, 405, { ok: false, error: '用 POST' })
        return
      }
      history.length = 0
      send(res, 200, { ok: true })
      return
    }

    if (p === '/chat/events') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-store',
        Connection: 'keep-alive',
        'Access-Control-Allow-Origin': '*'
      })
      res.write(': whale chat bridge\n\n')
      subs.add(res)
      const ping = setInterval(() => {
        try {
          res.write(': ping\n\n')
        } catch (err) {}
      }, 25000)
      req.on('close', () => {
        clearInterval(ping)
        subs.delete(res)
      })
      return
    }

    send(res, 404, { ok: false, error: '没有这个端点' })
  }

  async function listen() {
    await stopListen()
    cfg = normalizeChat(getConfig())
    if (!cfg.on) {
      running = false
      log('聊天映射：未开启')
      return { ok: true, running: false }
    }
    server = http.createServer((req, res) => {
      Promise.resolve(handler(req, res)).catch((err) => {
        try {
          send(res, 500, { ok: false, error: String((err && err.message) || err) })
        } catch (e2) {}
      })
    })
    const host = String(cfg.host || '127.0.0.1')
    const want = Number(cfg.port) || 32169
    try {
      port = await new Promise((resolve, reject) => {
        server.once('error', reject)
        server.listen(want, host, () => resolve(server.address().port))
      })
      running = true
      lastError = ''
      log('聊天映射已监听 http://' + host + ':' + port + '/chat/push')
      return { ok: true, running: true, port, url: 'http://' + host + ':' + port }
    } catch (err) {
      lastError = String((err && err.message) || err)
      running = false
      try {
        server.close()
      } catch (e2) {}
      server = null
      log('聊天映射启动失败: ' + lastError)
      return { ok: false, error: lastError }
    }
  }

  async function stopListen() {
    stopPoll()
    if (!server) {
      running = false
      return
    }
    const s = server
    server = null
    running = false
    await new Promise((resolve) => {
      try {
        for (const r of subs) {
          try {
            r.end()
          } catch (e) {}
        }
        subs.clear()
        s.close(() => resolve())
        setTimeout(resolve, 400)
      } catch (err) {
        resolve()
      }
    })
  }

  // ---------- 反向拉取 ----------
  function stopPoll() {
    if (pollTimer) {
      clearInterval(pollTimer)
      pollTimer = null
    }
  }

  async function pollOnce() {
    const c = cfg.poll || {}
    if (!c.url) return
    let headers = {}
    try {
      headers = c.headers ? JSON.parse(c.headers) : {}
    } catch (err) {
      headers = {}
    }
    if (!Object.keys(headers).some((k) => k.toLowerCase() === 'content-type') && c.body) {
      headers['Content-Type'] = 'application/json'
    }
    const method = String(c.method || 'GET').toUpperCase()
    try {
      const r = await fetch(c.url, {
        method,
        headers,
        body: method === 'GET' || method === 'HEAD' ? undefined : c.body || undefined,
        signal: AbortSignal.timeout(15000)
      })
      const text = await r.text()
      if (!r.ok) {
        pollFails += 1
        log('拉取失败 HTTP ' + r.status)
        return
      }
      pollFails = 0
      let val = text
      try {
        val = pickPath(JSON.parse(text), c.pick || 'message')
      } catch (err) {
        val = text
      }
      if (val == null) return
      const out = String(val).trim()
      if (!out) return
      if (c.dedupe !== false && out === pollLast) return
      pollLast = out
      push({ text: out, from: c.from || '远端', channel: 'poll' })
    } catch (err) {
      pollFails += 1
      if (pollFails % 5 === 1) log('拉取异常: ' + (err && err.message))
    }
  }

  function startPoll() {
    stopPoll()
    const c = cfg.poll || {}
    if (!c.on || !c.url) return
    const ms = Math.max(5, Number(c.interval) || 30) * 1000
    pollTimer = setInterval(() => {
      pollOnce()
    }, ms)
    setTimeout(() => pollOnce(), 1500)
    log('反向拉取已开启：每 ' + ms / 1000 + ' 秒请求一次')
  }

  /** 配置变了：重新落配置、重启监听和拉取 */
  async function apply() {
    const r = await listen()
    startPoll()
    return Object.assign({ ok: r.ok }, r, { status: status() })
  }

  function status() {
    return {
      running,
      port,
      url: running ? 'http://' + String(cfg.host || '127.0.0.1') + ':' + port : '',
      error: lastError,
      received: history.length,
      last: history[0] || null,
      pollFails
    }
  }

  await listen()
  startPoll()

  return {
    apply,
    push,
    status,
    history: (limit) => history.slice(0, Math.max(1, Number(limit) || 20)),
    clear: () => {
      history.length = 0
      return { ok: true }
    },
    getConfig: () => cfg,
    pollOnce,
    close: async () => {
      await stopListen()
    }
  }
}
