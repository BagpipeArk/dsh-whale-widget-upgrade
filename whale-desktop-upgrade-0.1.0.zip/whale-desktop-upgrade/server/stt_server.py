# -*- coding: utf-8 -*-
"""鲸鱼娘桌宠 · 本地语音识别服务

常驻 faster-whisper(small/int8) + WASAPI loopback 录音，提供：
  GET  /health                     -> 状态
  GET  /recent?seconds=90          -> 最近这段时间"电脑在说什么"的文字
  POST /transcribe  (raw bytes)    -> 立即识别一段音频(wav/mp3/任意av能解)
  POST /config      {json}         -> 运行时调参(enabled/threshold/device_match)
日志: <根目录>/stt.log
"""
import io
import os
import sys
import json
import time
import wave
import queue
import threading
import traceback
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

# 根目录：优先环境变量 WHALE_HOME，否则用本文件上一级（server/ 的父目录），换机器不用改代码
BASE = os.environ.get("WHALE_HOME") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(BASE, "stt.log")
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import whale_paths  # noqa: E402

MODEL_DIR = whale_paths.stt_model_dir()
PORT = int(os.environ.get("WHALE_STT_PORT", "32171"))
SR_TARGET = 16000

_log_lock = threading.Lock()


def log(msg):
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with _log_lock:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        pass


# ---------------- 配置 ----------------
CFG = {
    "enabled": True,
    "device_match": "",      # 空=默认输出设备的 loopback
    "thr": 0.008,            # 触发阈值(RMS)
    "silence_sec": 0.9,      # 静音多久判定一句结束
    "min_speech_sec": 0.6,   # 太短的不识别
    "max_seg_sec": 24.0,     # 单段最长
    "keep_recent_sec": 180,  # 内存里保留多久的转写
    "model": os.environ.get("WHALE_STT_MODEL", "small"),
    "prompt": "以下是普通话的句子，包含<WORLD_SERIES>、<WORLD_PLACE>、<CHAR_NAME>、<CHAR_ALIAS>等专有名词。",
}

RECENT = deque(maxlen=400)   # (ts, text)
RECENT_LOCK = threading.Lock()

SEG_Q = queue.Queue(maxsize=6)
MODEL = None
MODEL_LOCK = threading.Lock()
STATS = {"segments": 0, "dropped": 0, "last_audio_ts": 0.0, "last_text": "", "last_error": ""}


# ---------------- 模型 ----------------
def get_model():
    global MODEL
    with MODEL_LOCK:
        if MODEL is None:
            from faster_whisper import WhisperModel
            t0 = time.time()
            MODEL = WhisperModel(
                CFG["model"], device="cpu", compute_type="int8",
                download_root=MODEL_DIR, cpu_threads=min(8, os.cpu_count() or 4),
            )
            log("模型就绪 %s (%.1fs)" % (CFG["model"], time.time() - t0))
        return MODEL


def to_16k_mono(int16_bytes, ch, sr):
    a = np.frombuffer(int16_bytes, dtype=np.int16)
    if ch > 1 and len(a) >= ch:
        a = a.reshape(-1, ch).mean(axis=1).astype(np.int16)
    if sr != SR_TARGET and len(a):
        n = int(round(len(a) * SR_TARGET / sr))
        if n > 0:
            idx = np.linspace(0, len(a) - 1, n)
            a = np.interp(idx, np.arange(len(a)), a.astype(np.float32)).astype(np.int16)
    return (a.astype(np.float32) / 32768.0)


def wav_bytes(a_float, sr=SR_TARGET):
    pcm = np.clip(a_float, -1, 1)
    pcm = (pcm * 32767).astype(np.int16).tobytes()
    bio = io.BytesIO()
    with wave.open(bio, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm)
    return bio.getvalue()


def transcribe_audio(src, is_bytes=False):
    """src: 本地路径 或 音频字节。返回文字。"""
    m = get_model()
    if is_bytes:
        try:
            import av
            with av.open(io.BytesIO(src)) as c:
                audio = None
                sr_in = 0
                for s in c.decode(audio=0):
                    if audio is None:
                        audio = s.to_ndarray()
                        sr_in = int(getattr(s, "sample_rate", 0) or 0)
                    else:
                        audio = np.concatenate([audio, s.to_ndarray()], axis=1)
                if audio is None:
                    return ""
                if audio.dtype != np.float32:
                    if audio.dtype == np.int16:
                        audio = audio.astype(np.float32) / 32768.0
                    elif audio.dtype == np.int32:
                        audio = audio.astype(np.float32) / 2147483648.0
                    else:
                        audio = audio.astype(np.float32)
                if audio.ndim > 1:
                    if audio.shape[0] < audio.shape[1]:
                        audio = audio.mean(axis=0)
                    else:
                        audio = audio.mean(axis=1)
                # 传进来的 wav 可能是 44.1k/48k，whisper 只认 16k，
                # 不重采样会当成 16k 播放，整段变调被判定成非人声。
                if sr_in and sr_in != SR_TARGET and len(audio):
                    n = int(round(len(audio) * SR_TARGET / sr_in))
                    if n > 0:
                        audio = np.interp(
                            np.linspace(0, len(audio) - 1, n),
                            np.arange(len(audio)),
                            audio,
                        ).astype(np.float32)
                segs, _ = m.transcribe(audio, language="zh", beam_size=5,
                                       vad_filter=True, initial_prompt=CFG["prompt"])
        except Exception:
            log("bytes 解码失败\n" + traceback.format_exc())
            return ""
    else:
        segs, _ = m.transcribe(src, language="zh", beam_size=5,
                               vad_filter=True, initial_prompt=CFG["prompt"])
    return "".join(s.text for s in segs).strip()


def collect_text(segs):
    """过滤掉置信度低/基本不是人声的片段（唱歌、纯音乐、噪声）。"""
    out = []
    for s in segs:
        no_speech = getattr(s, "no_speech_prob", 0.0) or 0.0
        logprob = getattr(s, "avg_logprob", 0.0) or 0.0
        if no_speech > 0.6 or logprob < -1.0:
            continue
        txt = (s.text or "").strip()
        if txt:
            out.append(txt)
    return "".join(out).strip()


# 静音窗口：桌宠自己念 TTS 的时候，回环会把它自己的声音也录进来，
# 那段时间的转写不能让窥屏当成「这个窗口里有人在说话」。
MUTE_UNTIL = [0.0]


def muted_left():
    return max(0.0, MUTE_UNTIL[0] - time.time())


def push_text(txt, audio_sec=0.0):
    if not txt:
        return
    if muted_left() > 0:
        log("自己正在说话，丢掉这段回环：%s" % txt[:24])
        return
    with RECENT_LOCK:
        RECENT.append((time.time(), txt, audio_sec))
    STATS["last_text"] = txt
    log("识别(%0.1fs): %s" % (audio_sec, txt))


# ---------------- 转写工作线程 ----------------
def worker():
    get_model()
    while True:
        item = SEG_Q.get()
        if item is None:
            return
        ch, sr, data = item
        try:
            audio = to_16k_mono(data, ch, sr)
            sec = len(audio) / SR_TARGET
            segs, _ = get_model().transcribe(audio, language="zh", beam_size=5,
                                             vad_filter=True, condition_on_previous_text=False,
                                             initial_prompt=CFG["prompt"])
            push_text(collect_text(segs), sec)
            STATS["segments"] += 1
        except Exception:
            STATS["last_error"] = traceback.format_exc()[-400:]
            log("转写异常\n" + traceback.format_exc())


# ---------------- 录音监听线程 ----------------
def pick_loopback(p):
    import pyaudiowpatch as pyaudio
    match = (CFG.get("device_match") or "").strip()
    devices = list(p.get_loopback_device_info_generator())
    if not devices:
        return None
    if not match:
        try:
            return p.get_default_wasapi_loopback()
        except Exception:
            pass
    for d in devices:
        if match in d["name"]:
            return d
    return devices[0]


def watcher():
    import pyaudiowpatch as pyaudio
    p = pyaudio.PyAudio()
    dev = pick_loopback(p)
    if not dev:
        log("没有找到 loopback 设备，监听退出")
        return
    sr = int(dev["defaultSampleRate"])
    ch = max(1, int(dev["maxInputChannels"]))
    block = 2048
    log("开始监听 %s (%d Hz, %d ch)" % (dev["name"], sr, ch))

    stream = None
    speech = []
    speech_frames = 0
    silence_run = 0.0
    base = 0.0025
    while True:
        try:
            if not CFG["enabled"]:
                if stream is not None:
                    stream.stop_stream(); stream.close(); stream = None
                    log("监听暂停")
                speech = []; speech_frames = 0; silence_run = 0.0
                time.sleep(1.0)
                continue
            if stream is None:
                dev = pick_loopback(p)
                stream = p.open(format=pyaudio.paInt16, channels=ch, rate=sr, input=True,
                                input_device_index=dev["index"], frames_per_buffer=block)
                log("录音流已打开 %s" % dev["name"])
            data = stream.read(block, exception_on_overflow=False)
        except Exception:
            STATS["last_error"] = traceback.format_exc()[-400:]
            log("录音异常，2 秒后重建\n" + traceback.format_exc())
            try:
                if stream is not None:
                    stream.close()
            except Exception:
                pass
            stream = None
            time.sleep(2.0)
            continue

        a = np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0
        if a.size == 0:
            continue
        rms = float(np.sqrt((a * a).mean()))
        dur = a.size / (sr * ch) if a.size else 0.0
        thr = max(CFG["thr"], base * 3.0)

        if rms < thr * 0.6:
            base = base * 0.98 + rms * 0.02
        if rms > thr:
            STATS["last_audio_ts"] = time.time()

        if rms > thr:
            speech.append(data)
            speech_frames += a.size // max(1, ch)
            silence_run = 0.0
        elif speech:
            silence_run += dur
            speech.append(data)
            speech_frames += a.size // max(1, ch)
            if silence_run >= CFG["silence_sec"]:
                seg_len = speech_frames / sr
                if seg_len >= CFG["min_speech_sec"]:
                    try:
                        SEG_Q.put_nowait((ch, sr, b"".join(speech)))
                    except queue.Full:
                        STATS["dropped"] += 1
                        log("队列满，丢弃一段")
                speech = []; speech_frames = 0; silence_run = 0.0
        if speech and speech_frames / sr >= CFG["max_seg_sec"]:
            try:
                SEG_Q.put_nowait((ch, sr, b"".join(speech)))
            except queue.Full:
                STATS["dropped"] += 1
            speech = []; speech_frames = 0; silence_run = 0.0


# ---------------- HTTP ----------------
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        try:
            if self.path.startswith("/health"):
                self._send(200, {"ok": True, "enabled": CFG["enabled"], "model": CFG["model"],
                                 "segments": STATS["segments"], "recent": len(RECENT),
                                 "last_text": STATS["last_text"],
                                 "last_audio_ago": (round(time.time() - STATS["last_audio_ts"], 1)
                                                    if STATS["last_audio_ts"] else None),
                                 "error": STATS["last_error"][-200:]})
            elif self.path.startswith("/recent"):
                sec = 90.0
                if "seconds=" in self.path:
                    try:
                        sec = float(self.path.split("seconds=")[1].split("&")[0])
                    except Exception:
                        pass
                now = time.time()
                with RECENT_LOCK:
                    items = [{"t": t, "ago": round(now - t, 1), "text": x, "audio_sec": round(d, 1)}
                             for (t, x, d) in RECENT if now - t <= sec]
                self._send(200, {"ok": True, "seconds": sec,
                                 "text": " ".join(i["text"] for i in items), "items": items})
            else:
                self._send(404, {"ok": False})
        except Exception:
            self._send(500, {"ok": False, "error": traceback.format_exc()[-300:]})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b""
            if self.path.startswith("/transcribe"):
                txt = transcribe_audio(raw, is_bytes=True)
                self._send(200, {"ok": True, "text": txt})
            elif self.path.startswith("/mute"):
                try:
                    upd = json.loads(raw.decode("utf-8") or "{}")
                except Exception:
                    upd = {}
                sec = float(upd.get("seconds") or 0)
                MUTE_UNTIL[0] = max(MUTE_UNTIL[0], time.time() + max(0.0, sec))
                log("静音窗口 %.1fs（自己正在念）" % sec)
                self._send(200, {"ok": True, "mutedFor": round(muted_left(), 2)})
            elif self.path.startswith("/config"):
                upd = json.loads(raw.decode("utf-8") or "{}")
                for k, v in upd.items():
                    if k in CFG:
                        CFG[k] = v
                log("配置更新 %s" % json.dumps(upd, ensure_ascii=False))
                self._send(200, {"ok": True, "cfg": CFG})
            else:
                self._send(404, {"ok": False})
        except Exception:
            self._send(500, {"ok": False, "error": traceback.format_exc()[-300:]})


def main():
    log("==== stt_server 启动 :%d ====" % PORT)
    threading.Thread(target=worker, daemon=True).start()
    threading.Thread(target=watcher, daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    srv.daemon_threads = True
    srv.serve_forever()


if __name__ == "__main__":
    main()
