// peek.mjs —— 「窥屏」：只盯一个窗口，按 10 秒一张连续抓，攒一批再交给 AI 说一次话
//
// v2 设计要点（2026-11-09 改）：
//   · 只抓用户选中的那一个窗口（sourceId 精确匹配，types 只用 'window'）——
//     即使别的窗口盖在上面、你切到别的程序，抓到的仍然只有这个窗口自己的画面。
//   · 抓图节奏：每 captureSec（默认 10）秒一张，画面没变的那张不重复入队。
//   · 说话节奏：每 45~90 秒随机一次汇总，把这段时间攒下的几张图**一起**交给分析端点，
//     让 AI 看着这一串画面说一句话，而不是只看一张。
//   · 抓到的图只在内存里过一遍，POST 完立刻丢弃。
//   · 分析端点默认指向本机 AstrBot 插件（32170），也可以换成自己的服务。
import crypto from 'node:crypto'

const DEFAULT_CFG = {
  on: false,
  sourceId: '',
  sourceName: '',
  captureSec: 10, // 每多少秒抓一张图
  minSec: 45, // 汇总（说话）最短间隔
  maxSec: 90, // 汇总最长间隔
  maxFrames: 9, // 一次最多带几张图，多了丢最老的
  analyzeUrl: 'http://127.0.0.1:32170/peek',
  token: '',
  thumbWidth: 1280,
  thumbHeight: 720,
  quiet: false, // 没东西可看时也照样回一句话
}

function mergeCfg(raw) {
  const out = Object.assign({}, DEFAULT_CFG)
  const v = raw || {}
  for (const k of Object.keys(DEFAULT_CFG)) {
    if (v[k] !== undefined && v[k] !== null) out[k] = v[k]
  }
  out.captureSec = Math.min(60, Math.max(2, Number(out.captureSec) || 10))
  out.minSec = Math.max(5, Number(out.minSec) || 45)
  out.maxSec = Math.max(out.minSec, Number(out.maxSec) || 90)
  out.maxFrames = Math.min(30, Math.max(1, Math.round(Number(out.maxFrames) || 9)))
  out.thumbWidth = Math.max(320, Number(out.thumbWidth) || 1280)
  out.thumbHeight = Math.max(200, Number(out.thumbHeight) || 720)
  return out
}

export function createPeek(opts) {
  const desktopCapturer = opts.desktopCapturer
  const getConfig = opts.getConfig || (() => ({}))
  const onSay = opts.onSay || (() => {})
  const onState = opts.onState || (() => {})
  const log = opts.log || (() => {})

  let cfg = mergeCfg(getConfig())
  let captureTimer = null
  let summaryTimer = null
  let running = false
  let lastHash = ''
  let buffer = [] // [{ png, at, hash }]
  let latest = null // 最近抓到的那一张，不受 buffer 被汇总清空影响（语音聊天要复用）
  let frames = 0 // 累计抓到的有效帧
  let rounds = 0 // 累计汇总次数
  let lastError = ''
  let lastAt = 0
  let lastSayAt = 0
  let missCount = 0
  let summarizing = false

  function status() {
    return {
      on: !!cfg.on,
      live: running && !!cfg.sourceId,
      sourceId: cfg.sourceId,
      sourceName: cfg.sourceName,
      captureSec: cfg.captureSec,
      minSec: cfg.minSec,
      maxSec: cfg.maxSec,
      buffered: buffer.length,
      frames,
      rounds,
      lastAt,
      lastSayAt,
      lastError,
    }
  }

  function publish() {
    try {
      onState(status())
    } catch (err) {}
  }

  function clearTimers() {
    if (captureTimer) {
      clearTimeout(captureTimer)
      captureTimer = null
    }
    if (summaryTimer) {
      clearTimeout(summaryTimer)
      summaryTimer = null
    }
  }

  async function listWindows() {
    const width = 320
    const height = 200
    const sources = await desktopCapturer.getSources({
      types: ['window'],
      thumbnailSize: { width, height },
      fetchWindowIcons: true,
    })
    return sources
      .filter((s) => {
        const name = String(s.name || '').trim()
        if (!name) return false
        // 桌宠自己、系统壳窗口、显卡叠加层这些不让人选
        if (/WhaleDesktop|小鲸鱼|选择要窥屏/i.test(name)) return false
        if (/^(no_active_wnd|Program Manager|Default IME|MSCTFIME UI|AsHDRControl|AsHotplugCtrl|NVIDIA GeForce Overlay|Windows Input Experience|TextInputHost)$/i.test(name)) {
          return false
        }
        let has = false
        try {
          has = !!(s.thumbnail && !s.thumbnail.isEmpty())
        } catch (err) {}
        return has
      })
      .map((s) => {
        let thumb = ''
        try {
          if (s.thumbnail && !s.thumbnail.isEmpty()) thumb = s.thumbnail.toDataURL()
        } catch (err) {}
        let icon = ''
        try {
          if (s.appIcon && !s.appIcon.isEmpty()) icon = s.appIcon.toDataURL()
        } catch (err) {}
        return { id: s.id, name: s.name, thumb: thumb, app: icon }
      })
      .sort((a, b) => String(a.name).localeCompare(String(b.name), 'zh-Hans-CN'))
  }

  // 只取 window 类型、并且 id 精确等于选中窗口的那一个源。
  // 不做任何整屏抓取，所以别的窗口盖在上面也不影响这里拿到的东西。
  // 返回 { missing } 表示窗口没了；{ empty } 表示窗口在但暂时没画面（最小化等）。
  async function grabFrame() {
    const sources = await desktopCapturer.getSources({
      types: ['window'],
      thumbnailSize: { width: cfg.thumbWidth, height: cfg.thumbHeight },
      fetchWindowIcons: false,
    })
    const target = sources.find((s) => s.id === cfg.sourceId)
    if (!target) return { missing: true }
    if (!target.thumbnail || target.thumbnail.isEmpty()) return { empty: true }
    // 用 JPEG 而不是 PNG：一张 1280x720 的 PNG 动辄七八百 KB，攒九张再发出去太重
    const buf = target.thumbnail.toJPEG(72)
    return { png: buf, mime: 'image/jpeg', name: target.name || cfg.sourceName }
  }

  // 一批图交给分析端点。老字段 image（最后一张）保留，方便老的接收端不受影响。
  async function analyze(shots, windowName) {
    const url = String(cfg.analyzeUrl || '').trim()
    if (!url) throw new Error('分析端点没配置')
    const images = shots.map((s) => 'data:' + (s.mime || 'image/jpeg') + ';base64,' + s.png.toString('base64'))
    const spanSec = shots.length > 1 ? Math.round((shots[shots.length - 1].at - shots[0].at) / 1000) : 0
    const body = {
      window: windowName,
      images: images,
      image: images[images.length - 1],
      count: images.length,
      spanSec: spanSec,
      captureSec: cfg.captureSec,
      at: Date.now(),
      quiet: !!cfg.quiet,
    }
    const headers = { 'Content-Type': 'application/json' }
    if (cfg.token) headers['X-Token'] = String(cfg.token)
    const resp = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    })
    const text = await resp.text()
    if (!resp.ok) throw new Error('分析端返回 ' + resp.status + '：' + text.slice(0, 160))
    let data = null
    try {
      data = JSON.parse(text)
    } catch (err) {
      throw new Error('分析端返回的不是 JSON：' + text.slice(0, 160))
    }
    return data || {}
  }

  function nextSummaryDelay() {
    const lo = cfg.minSec * 1000
    const hi = cfg.maxSec * 1000
    return Math.round(lo + Math.random() * (hi - lo))
  }

  // ---- 抓图：每 captureSec 秒一张 ----
  function scheduleCapture(ms) {
    if (captureTimer) clearTimeout(captureTimer)
    captureTimer = null
    if (!running) return
    captureTimer = setTimeout(captureTick, ms == null ? cfg.captureSec * 1000 : ms)
  }

  async function captureTick() {
    if (!running) return
    let frame = null
    try {
      frame = await grabFrame()
    } catch (err) {
      lastError = '抓图失败：' + ((err && err.message) || err)
      log('[peek] ' + lastError)
    }

    if (frame.missing) {
      missCount += 1
      // 窗口可能被关掉了：连续三次找不到就自动收工，别空转
      if (missCount >= 3) {
        log('[peek] 目标窗口连续三次没抓到，自动关闭窥屏')
        stop('窗口不见了')
        try {
          onSay({ text: '那个窗口好像关掉了，我先不看了。要接着看就再点一次眼睛。', from: '窥屏', channel: 'peek' })
        } catch (err) {}
        return
      }
      publish()
      scheduleCapture()
      return
    }
    if (frame.empty) {
      // 窗口还在，只是这会儿没画面（最小化了 / 正在切桌面）。
      // 这不算丢窗口，安静等下一张。
      log('[peek] 窗口暂时没有画面，等下一张')
      publish()
      scheduleCapture()
      return
    }
    missCount = 0
    lastError = ''

    const hash = crypto.createHash('md5').update(frame.png).digest('hex')
    if (hash !== lastHash) {
      lastHash = hash
      buffer.push({ png: frame.png, mime: frame.mime, at: Date.now(), hash: hash })
      latest = buffer[buffer.length - 1]
      while (buffer.length > cfg.maxFrames) buffer.shift()
      frames += 1
      lastAt = Date.now()
      log('[peek] 抓到第 ' + frames + ' 张，缓冲区 ' + buffer.length + ' 张')
      publish()
    }
    scheduleCapture()
  }

  // ---- 汇总：每 45~90 秒把 buffer 里的几张一起交给 AI，说一次话 ----
  function scheduleSummary(ms) {
    if (summaryTimer) clearTimeout(summaryTimer)
    summaryTimer = null
    if (!running) return
    summaryTimer = setTimeout(summaryTick, ms == null ? nextSummaryDelay() : ms)
  }

  async function summaryTick() {
    if (!running) return
    if (summarizing) {
      scheduleSummary()
      return
    }
    if (!buffer.length) {
      // 这段时间画面完全没动过，就不打扰
      log('[peek] 这一轮没有新画面，跳过汇总')
      scheduleSummary()
      return
    }
    const shots = buffer.slice()
    buffer = []
    summarizing = true
    try {
      const result = await analyze(shots, cfg.sourceName)
      const reply = String((result && (result.text || result.message)) || '').trim()
      rounds += 1
      lastSayAt = Date.now()
      if (reply) {
        log('[peek] 汇总回复：' + reply.slice(0, 60) + (reply.length > 60 ? '…' : ''))
        try {
          const said = onSay({ text: reply, from: '窥屏', channel: 'peek', duration: 20000 })
          if (said && typeof said.catch === 'function') {
            said
              .then((ok) => log('[peek] 气泡发出: ' + (ok ? '成功' : '失败')))
              .catch((err) => log('[peek] 气泡异常: ' + ((err && err.message) || err)))
          }
        } catch (err) {
          log('[peek] 气泡异常: ' + ((err && err.message) || err))
        }
      } else {
        log('[peek] 分析端没给文字：' + JSON.stringify(result).slice(0, 200))
      }
      publish()
    } catch (err) {
      lastError = (err && err.message) || String(err)
      // 分析失败也别把图丢了：放回去，下一轮再试（不够上限的话）
      buffer = shots.concat(buffer).slice(-cfg.maxFrames)
      log('[peek] ' + lastError)
      publish()
    } finally {
      summarizing = false
    }
    scheduleSummary()
  }

  function start(sourceId, sourceName) {
    if (!sourceId) return { ok: false, error: '没有选中窗口' }
    cfg = mergeCfg(Object.assign({}, getConfig(), {
      on: true,
      sourceId: sourceId,
      sourceName: sourceName || '',
    }))
    running = true
    buffer = []
    latest = null
    frames = 0
    rounds = 0
    lastHash = ''
    lastError = ''
    missCount = 0
    lastSayAt = 0
    clearTimers()
    log('[peek] 开始窥屏：' + (sourceName || sourceId) + '，抓图 ' + cfg.captureSec + 's / 汇总 ' + cfg.minSec + '-' + cfg.maxSec + 's')
    publish()
    scheduleCapture(1200)
    scheduleSummary()
    return { ok: true, status: status() }
  }

  function stop(reason) {
    running = false
    clearTimers()
    buffer = []
    latest = null
    cfg = mergeCfg(Object.assign({}, cfg, { on: false, sourceId: '', sourceName: '' }))
    if (reason) log('[peek] 停止窥屏：' + reason)
    publish()
    return { ok: true, status: status() }
  }

  function applyCfg(raw) {
    const wasOn = running
    const prevId = cfg.sourceId
    cfg = mergeCfg(raw)
    if (wasOn && cfg.sourceId && cfg.sourceId === prevId) {
      // 只是改了节奏：两个计时器按新配置重排，不打断已经攒着的画面
      if (running) {
        scheduleCapture()
        scheduleSummary()
      }
      publish()
      return status()
    }
    if (wasOn && (!cfg.sourceId || cfg.sourceId !== prevId)) {
      // 配置里换了窗口：照着新窗口重开
      running = true
      buffer = []
      lastHash = ''
      missCount = 0
      clearTimers()
      scheduleCapture(1200)
      scheduleSummary()
    }
    publish()
    return status()
  }

  function dispose() {
    running = false
    clearTimers()
    buffer = []
  }

  // 给语音聊天用：直接给最近抓到的那一帧，不再额外截屏
  function recent(limit) {
    const n = Math.max(1, Number(limit) || 1)
    const items = buffer.length ? buffer.slice(-n) : latest ? [latest] : []
    return items.map((f) => ({
      at: f.at || 0,
      mime: f.mime || 'image/jpeg',
      dataUrl: 'data:' + (f.mime || 'image/jpeg') + ';base64,' + Buffer.from(f.png).toString('base64'),
    }))
  }

  return { status, listWindows, start, stop, applyCfg, dispose, recent }
}
