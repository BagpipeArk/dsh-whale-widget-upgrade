# -*- coding: utf-8 -*-
"""鲸鱼娘桌宠 · 语音聊天

按住热键（默认 `~`）说话，松开后：录音 → 本地识别 → 模型回答 → 弹气泡 + 念出来。

  GET  /health              -> 状态
  POST /config  {json}      -> 运行时调参（enabled / hotkey）
  POST /say     {"text":""} -> 跳过录音，直接当作用户说了一句（调试用）

和其他模块的关系：
  · 识别走 stt_server(32171) 的 /transcribe
  · 回答交给主进程(32174) 的 /talk/say，由它弹气泡并按 talk 优先级播报
  · 主进程不可达时退化：直接调 tts_server(32172) 用 talk 优先级念
  · 录音/思考期间会告诉主进程 talk 状态，窥屏那边据此闭嘴，不许插嘴
日志: <根目录>/voice-chat.log
"""
import io as _io
import json
import os
import queue
import struct
import sys
import threading
import time
import traceback
import urllib.error
import urllib.request
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import whale_paths  # noqa: E402
import whale_llm  # noqa: E402

BASE = whale_paths.BASE
LOG_PATH = os.path.join(BASE, "voice-chat.log")
PORT = int(os.environ.get("WHALE_VOICE_PORT", "32173"))
STT_URL = os.environ.get("WHALE_STT_URL", "http://127.0.0.1:32171")
TTS_URL = os.environ.get("WHALE_TTS_URL", "http://127.0.0.1:32172")
UI_URL = os.environ.get("WHALE_UI_URL", "http://127.0.0.1:32174")

# 按住多久才算「在说话」：太短当普通按键（不然打字按到 ` 就开录）
HOLD_MS = int(os.environ.get("WHALE_VOICE_HOLD_MS", "180"))
MIN_SEC = 0.60          # 有效语音最短时长
MIN_RMS = 150           # 音量低于这个就当成没说话（16bit 满量程 32768）
MAX_SEC = 30.0          # 单次最长录音
HISTORY_TURNS = 6       # 记住最近几轮，方便接着聊

VK_ESCAPE = 0x1B
VK_OEM_3 = 0xC0         # ` ~ 键
_NAME_TO_VK = {
    "`": VK_OEM_3, "~": VK_OEM_3, "grave": VK_OEM_3,
    "space": 0x20, "enter": 0x0D, "tab": 0x09,
    "capslock": 0x14, "esc": VK_ESCAPE, "escape": VK_ESCAPE,
    "shift": 0xA0, "ctrl": 0xA2, "alt": 0xA4,
    "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75,
    "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B,
}


def _vk_of(name):
    """把 '`' / 'F8' / 'ctrl' / '0x78' 之类解析成虚拟键码。"""
    s = str(name or "").strip()
    if not s:
        return VK_OEM_3
    low = s.lower()
    if low in _NAME_TO_VK:
        return _NAME_TO_VK[low]
    if low.startswith("0x"):
        try:
            return int(low, 16)
        except ValueError:
            return VK_OEM_3
    if len(s) == 1:
        ch = s.upper()
        if "A" <= ch <= "Z" or "0" <= ch <= "9":
            return ord(ch)
    return VK_OEM_3


CFG = {
    "enabled": os.environ.get("WHALE_VOICE_OFF") != "1",
    "hotkey": os.environ.get("WHALE_VOICE_KEY") or whale_paths.get("voiceHotkey", "`"),
    "beep": os.environ.get("WHALE_VOICE_BEEP") != "0",
    # 收音设备偏好：按名字包含匹配。填 "default" 则完全跟随系统默认输入。
    "mic": os.environ.get("WHALE_VOICE_MIC") or whale_paths.get("voiceMic", "default"),
}


def _pick_input(p):
    """按偏好挑录音设备，挑不到就回退系统默认输入。"""
    want = str(CFG.get("mic") or "").strip()
    if want and want.lower() not in ("default", "系统默认", "auto"):
        fallback = None
        for i in range(p.get_device_count()):
            try:
                d = p.get_device_info_by_index(i)
            except Exception:
                continue
            if int(d.get("maxInputChannels") or 0) < 1:
                continue
            if str(d.get("name") or "").find(want) < 0:
                continue
            if d.get("isLoopbackDevice"):
                continue
            if int(d.get("defaultSampleRate") or 0) == 44100:
                return d
            if fallback is None:
                fallback = d
        if fallback is not None:
            return fallback
    return p.get_default_input_device_info()
CFG["vk"] = _vk_of(CFG["hotkey"])

_log_lock = threading.Lock()


def log(msg):
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        with _log_lock:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        pass


def _save_hotkey(name):
    """把热键写回 paths.json，下次启动直接生效，不用再学一遍。"""
    for path in (
        os.path.join(whale_paths.BASE, "paths.json"),
        os.path.join(whale_paths.BASE, "config", "paths.json"),
    ):
        if not os.path.isfile(path):
            continue
        try:
            with open(path, encoding="utf-8-sig") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                continue
            data["voiceHotkey"] = name
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception:
            continue
    return False


# ---------------- 和主进程 / TTS 说话 ----------------
def _post(url, payload, timeout=8.0):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", "replace") or "{}")


def talk_state(state, hold_ms=0):
    """告诉主进程语音聊天的状态，让窥屏在这段时间闭嘴。"""
    try:
        _post(UI_URL + "/talk/state", {"state": state, "holdMs": int(hold_ms)}, timeout=3.0)
    except Exception:
        pass


def hint(text, ms=1200):
    """在桌宠上闪一个小气泡。声音被游戏独占时，这是唯一还看得见的反馈。"""
    try:
        _post(UI_URL + "/talk/hint", {"text": text, "ms": int(ms)}, timeout=3.0)
    except Exception:
        pass


def silence_tts():
    """开录前先把自己正在念的停掉，免得录进去。"""
    try:
        _post(TTS_URL + "/stop", {}, timeout=3.0)
    except Exception:
        pass


def deliver(text, wav_ms=0):
    """把回答交出去：优先走主进程（弹气泡 + 播报），不行就自己念。"""
    try:
        _post(UI_URL + "/talk/say", {"text": text, "wavMs": int(wav_ms)}, timeout=10.0)
        return True
    except Exception as exc:
        log("主进程不可达(%s)，退回直接播报" % exc)
    try:
        _post(TTS_URL + "/speak", {"text": text, "source": "talk", "wait": False}, timeout=120.0)
        return True
    except Exception as exc:
        log("播报也失败了：%s" % exc)
        return False


def transcribe(wav_bytes, rate=16000):
    if not wav_bytes:
        return ""
    req = urllib.request.Request(
        STT_URL + "/transcribe",
        data=wav_bytes,
        headers={"Content-Type": "application/octet-stream"},
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read().decode("utf-8", "replace") or "{}")
    return str(data.get("text") or "").strip()


# ---------------- 录音 ----------------
_rec_lock = threading.Lock()
_rec = None
_abort = False          # {"pa":..,"stream":..,"frames":[..],"rate":..,"ch":..,"t0":..}
_rec_busy = threading.Lock()
_jobs = queue.Queue()


def _beep(kind):
    if not CFG.get("beep"):
        return
    try:
        import winsound
        if kind == "tap":
            winsound.Beep(1568, 35)      # 按下瞬间的轻提示，告诉用户「我听见键了」
        elif kind == "start":
            winsound.Beep(1046, 55)
        elif kind == "stop":
            winsound.Beep(784, 55)
        else:
            winsound.Beep(392, 90)
    except Exception:
        pass


_dbg = {}


def dbg_start(index, sec=90):
    """调试用：从指定输入设备开一条长录音，配合 /talk/dbgstop 判断哪个麦克风才是「人声」。"""
    dbg_stop()
    import pyaudiowpatch as pa

    p = pa.PyAudio()
    d = p.get_device_info_by_index(int(index))
    rate = int(d.get("defaultSampleRate") or 48000)
    ch = max(1, min(2, int(d.get("maxInputChannels") or 1)))
    st = p.open(
        format=pa.paInt16,
        channels=ch,
        rate=rate,
        input=True,
        input_device_index=int(index),
        frames_per_buffer=1024,
    )
    _dbg.clear()
    _dbg.update(stream=st, frames=[], rate=rate, ch=ch, dev=int(index), pa=p,
                t0=time.time(), limit=float(sec), name=str(d.get("name"))[:40])

    def _loop():
        st2 = st
        while _dbg.get("stream") is st2:
            if time.time() - _dbg["t0"] > _dbg["limit"]:
                break
            try:
                _dbg["frames"].append(st2.read(1024, exception_on_overflow=False))
            except Exception:
                break

    threading.Thread(target=_loop, daemon=True).start()
    return {"ok": True, "dev": int(index), "name": _dbg["name"], "rate": rate, "ch": ch}


def dbg_stop():
    """收尾调试录音：写 wav 到 <根目录>\dbg-<dev>.wav，返回时长和音量。"""
    st = _dbg.get("stream")
    if not st:
        return {"ok": False, "error": "没有在录"}
    _dbg["stream"] = None
    time.sleep(0.15)
    frames = _dbg.get("frames") or []
    try:
        st.stop_stream()
        st.close()
    except Exception:
        pass
    rate, ch = _dbg.get("rate") or 48000, _dbg.get("ch") or 1
    pcm = b"".join(frames)
    if not pcm:
        return {"ok": False, "error": "一个字节都没收到"}
    path = os.path.join(BASE, "dbg-%s.wav" % _dbg.get("dev"))
    with wave.open(path, "wb") as w:
        w.setnchannels(ch)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    total = len(pcm) // 2
    peak = 0
    step = max(1, total // 20000)
    ssum = 0
    ssum = 0
    n = 0
    for i in range(0, total - step, step):
        v = struct.unpack_from("<h", pcm, i * 2)[0]
        ssum += v * v
        n += 1
        if abs(v) > peak:
            peak = abs(v)
    rms = int((ssum / max(1, n)) ** 0.5)
    sec = len(pcm) / 2.0 / ch / rate
    return {"ok": True, "path": path, "sec": round(sec, 2), "rms": rms, "peak": peak,
            "dev": _dbg.get("dev"), "name": _dbg.get("name")}


def start_record():
    """开始录音。立刻返回，真正的设备打开交给后台线程——
    有些机器上 PyAudio 打开麦克风会卡好几秒，不能把 HTTP 请求和热键线程一起拖住。"""
    global _abort
    with _rec_lock:
        if _rec is not None:
            return False
    if not _rec_busy.acquire(blocking=False):
        return False
    _abort = False
    threading.Thread(target=_open_and_record, daemon=True).start()
    return True


def _open_and_record():
    global _rec
    try:
        log("开录：准备音频设备")
        threading.Thread(target=_beep, args=("start",), daemon=True).start()
        threading.Thread(target=silence_tts, daemon=True).start()
        import pyaudiowpatch as pa

        p = pa.PyAudio()
        dev = _pick_input(p)
        idx = int(dev["index"])
        rate = int(dev.get("defaultSampleRate") or 44100)
        try:
            maxch = int(dev.get("maxInputChannels") or 1)
        except Exception:
            maxch = 1
        log("开录：默认输入 %s %dHz maxch=%d" % (str(dev.get("name"))[:24], rate, maxch))

        stream = None
        last = None
        chans = 1
        for c in (2, maxch if maxch > 0 else 2, 1):
            if c < 1:
                continue
            try:
                stream = p.open(
                    format=pa.paInt16,
                    channels=int(c),
                    rate=rate,
                    input=True,
                    input_device_index=idx,
                    frames_per_buffer=1024,
                )
                chans = int(c)
                break
            except Exception as exc:
                last = exc
                stream = None
        if stream is None:
            raise last or RuntimeError("打不开默认麦克风")

        rec = {
            "pa": p,
            "stream": stream,
            "frames": [],
            "rate": rate,
            "ch": chans,
            "t0": time.time(),
            "cancelled": False,
        }
        with _rec_lock:
            if _abort:
                log("设备开好了，但手已经松开，这次不要了")
                try:
                    stream.stop_stream(); stream.close(); p.terminate()
                except Exception:
                    pass
                _rec_busy.release()
                return
            _rec = rec
        log("开始录音：%s %.0fHz %dch" % (str(dev.get("name"))[:28], rate, chans))
        talk_state("listening", hold_ms=int((MIN_SEC + 6) * 1000))
        _record_loop(rec)
    except Exception:
        log("开录失败：\n" + traceback.format_exc()[-500:])
        try:
            _rec_busy.release()
        except Exception:
            pass
        with _rec_lock:
            _rec = None
        talk_state("idle")


def _record_loop(rec):
    stream = rec["stream"]
    frames = rec["frames"]
    limit = int(rec["rate"] / 1024 * MAX_SEC)
    try:
        while True:
            with _rec_lock:
                if _rec is not rec or rec["cancelled"]:
                    break
            data = stream.read(1024, exception_on_overflow=False)
            frames.append(data)
            if len(frames) >= limit:
                log("录音到了 %.0f 秒上限，自动收尾" % MAX_SEC)
                stop_record()
                break
            # 按键已经松开但没收到松手信号时的兜底
            if len(frames) % 40 == 0 and not _key_down:
                stop_record()
                break
    except Exception:
        log("录音线程异常：\n" + traceback.format_exc()[-400:])


def _rms(pcm):
    """粗略音量：静音段会被识别成乱码，先按音量筛一道。"""
    if not pcm:
        return 0.0
    try:
        import numpy as np

        a = np.frombuffer(pcm[: len(pcm) // 2 * 2], dtype=np.int16).astype(np.float32)
        if a.size == 0:
            return 0.0
        return float(np.sqrt((a * a).mean()))
    except Exception:
        return 999.0  # 算不出来就别拦着


def _enhance_pcm(pcm, rate):
    """游戏里说话时环境音很脏：切掉 100Hz 以下和 7kHz 以上的杂音，
    再把峰值抬到够响的范围，识别率会明显好一些。失败就原样返回。"""
    try:
        import numpy as np

        a = np.frombuffer(pcm[: len(pcm) // 2 * 2], dtype=np.int16).astype(np.float32)
        if a.size < 512:
            return pcm
        dt = 1.0 / float(rate)
        # 一阶高通 100Hz
        rc = 1.0 / (2 * 3.1415926 * 100.0)
        alpha = rc / (rc + dt)
        hp = np.empty_like(a)
        prev_x = a[0]
        prev_y = 0.0
        for i in range(a.size):
            x = a[i]
            prev_y = alpha * (prev_y + x - prev_x)
            prev_x = x
            hp[i] = prev_y
        # 一阶低通 7000Hz
        rc2 = 1.0 / (2 * 3.1415926 * 7000.0)
        a2 = dt / (rc2 + dt)
        lp = np.empty_like(hp)
        prev = 0.0
        for i in range(hp.size):
            prev = prev + a2 * (hp[i] - prev)
            lp[i] = prev
        peak = float(np.abs(lp).max())
        if peak > 1:
            gain = min(8.0, (0.85 * 32767.0) / peak)
            lp = lp * gain
        out = np.clip(lp, -32768, 32767).astype(np.int16)
        return out.tobytes()
    except Exception:
        return pcm


def _pcm_to_wav(rec):
    pcm = b"".join(rec["frames"])
    ch = rec["ch"]
    if ch > 1:
        # 多声道降成单声道，取左右平均，省得识别把两路当成两个人在说
        n = len(pcm) // 2 // ch
        vals = struct.unpack("<%dh" % (n * ch), pcm[: n * ch * 2])
        mono = [0] * n
        for i in range(n):
            s = 0
            base = i * ch
            for c in range(ch):
                s += vals[base + c]
            mono[i] = int(s / ch)
        pcm = struct.pack("<%dh" % n, *mono)
    pcm = _enhance_pcm(pcm, int(rec["rate"]))
    buf = _io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(rec["rate"]))
        w.writeframes(pcm)
    return buf.getvalue()


def stop_record(cancel=False):
    global _rec, _abort
    with _rec_lock:
        rec = _rec
        if rec is None:
            if _rec_busy.locked():
                _abort = True
            return
        if cancel:
            rec["cancelled"] = True
        _rec = None
    dur = time.time() - rec.get("t0", time.time())
    try:
        rec["stream"].stop_stream()
        rec["stream"].close()
    except Exception:
        pass
    try:
        rec["pa"].terminate()
    except Exception:
        pass
    try:
        _rec_busy.release()
    except Exception:
        pass
    if cancel:
        log("录音取消（%.1fs）" % dur)
        talk_state("idle")
        _beep("cancel")
        return
    _beep("stop")
    if dur < MIN_SEC:
        log("太短了（%.2fs），忽略" % dur)
        talk_state("idle")
        return
    rms = _rms(b"".join(rec["frames"]))
    if rms < MIN_RMS:
        log("几乎没声音（rms=%.0f < %d），这次不算" % (rms, MIN_RMS))
        talk_state("idle")
        return
    log("这段音量 rms=%.0f" % rms)
    try:
        wav = _pcm_to_wav(rec)
    except Exception:
        log("打包 wav 失败：\n" + traceback.format_exc()[-400:])
        talk_state("idle")
        return
    log("录音结束 %.1fs / %d bytes，送去识别" % (dur, len(wav)))
    try:
        with open(os.path.join(HERE, "voice-last.wav"), "wb") as f:
            f.write(wav)
    except Exception:
        pass
    _jobs.put(wav)


# ---------------- 对话 ----------------
SYSTEM_PROMPT = """你是<CHAR_NAME>，<WORLD_PLACE><WORLD_SCHOOL><WORLD_DEPT>的学生，也是校园网路上的歌手「<CHAR_ALIAS>」。现在你在跟用户面对面语音聊天。

说话规则：
1. 像真人开口那样短。一般一到两句，最多六十个字，别写列表、别分点、别用括号写动作。
2. 语气轻快亲近，可以有"欸""嗯""好啦""怎么说呢"这类口气，但别每句都卖萌。
3. 对方的话是语音识别出来的，可能有错字，按最合理的意思理解，不要去纠正他的字。
4. 绝对不要提"语音识别""转写""识别错误"这类词。
5. 被问到难过的事，把话说轻一点，不要讲大道理，也不要美化死亡和牺牲。
6. 你只输出你要说出口的那句话，不要加旁白。
7. 有时候会附带一张我当时的屏幕画面——那是我正在看的东西（视频、游戏、网页）。可以顺着画面自然地搭一句，但别说什么"截图""画面里""我看到你的屏幕"这类话。"""

_history = []
_hist_lock = threading.Lock()


def grab_snapshot():
    """跟主进程要一张当前屏幕。拿不到就算了，不影响说话。"""
    try:
        data = _post(UI_URL + "/talk/snapshot", {}, timeout=8.0)
        if data.get("reason") == "peek-off":
            return ""  # 没开窥屏就不截图，单纯聊天
        url = data.get("dataUrl") or ""
        if data.get("ok") and url.startswith("data:image"):
            log("拿到一张屏幕截图（%d KB）" % (len(url) // 1024))
            return url
    except Exception as exc:
        log("取截图失败：%s" % exc)
    return ""


def _clean_reply(text):
    import re as _re
    s = (text or "").strip()
    s = _re.sub(r"[（(][^（）()]{1,24}[）)]", "", s)
    s = s.replace("**", "").replace("__", "")
    s = _re.sub(r"```[\s\S]*?```", " ", s)
    s = _re.sub(r"\s+", " ", s).strip()
    if len(s) > 140:
        cut = s[:140]
        m = max(cut.rfind("。"), cut.rfind("！"), cut.rfind("？"))
        s = cut[: m + 1] if m > 8 else cut
    return s.strip()


def _ask(user_text, image_url=""):
    with _hist_lock:
        msgs = [{"role": "system", "content": SYSTEM_PROMPT}]
        msgs.extend(_history[-HISTORY_TURNS * 2 :])
    if image_url:
        content = [
            {"type": "text", "text": user_text},
            {"type": "image_url", "image_url": {"url": image_url}},
        ]
    else:
        content = user_text
    msgs.append({"role": "user", "content": content})
    try:
        reply = whale_llm.chat(
            msgs, temperature=0.85, max_tokens=220, prefer_vision=bool(image_url)
        )
    except Exception:
        if not image_url:
            raise
        # 模型吃不下图就别硬塞，退回纯语音，别让一句话都答不上来
        log("带图问失败，退回纯文本：\n" + traceback.format_exc()[-300:])
        msgs[-1] = {"role": "user", "content": user_text}
        reply = whale_llm.chat(msgs, temperature=0.85, max_tokens=220)
    reply = _clean_reply(reply)
    if reply:
        with _hist_lock:
            _history.append({"role": "user", "content": user_text})
            _history.append({"role": "assistant", "content": reply})
            del _history[: max(0, len(_history) - HISTORY_TURNS * 2)]
    return reply


def _worker():
    while True:
        job = _jobs.get()
        try:
            t0 = time.time()
            talk_state("thinking", hold_ms=20000)
            if isinstance(job, tuple) and job and job[0] == "text":
                text = str(job[1] or "").strip()
            else:
                text = transcribe(job)
            if not text or len(text.strip("。，、？！.,?! ")) < 2:
                log("识别不出有用内容（%r），安静收场" % (text or ""))
                talk_state("idle")
                continue
            log("我听到：%s" % text[:80])
            snap = grab_snapshot()
            reply = _ask(text, snap)
            if not reply:
                log("模型没给回答")
                talk_state("idle")
                continue
            wav_ms = int(min(30000, max(2500, len(reply) / 4.2 * 1000 + 1200)))
            log("回答(%.1fs)：%s" % (time.time() - t0, reply[:80]))
            deliver(reply, wav_ms)
            # 播完之前窥屏都别插嘴
            time.sleep(wav_ms / 1000.0 + 0.6)
            talk_state("idle")
        except Exception:
            log("处理失败：\n" + traceback.format_exc()[-600:])
            talk_state("idle")


# ---------------- 全局热键（按住说话） ----------------
# 两条通路同时监听，任一条收到算数：
#   1) GetAsyncKeyState 轮询：25ms 一次，平时够用，但全屏独占的游戏里常常读不到；
#   2) Raw Input（RIDEV_INPUTSINK）：注册一个隐藏窗口收全域键盘，游戏独占/非前台也能收到。
# 两者共用下面这套状态机，靠 _key_down 去重，不会重复开录。
_key_down = False
_down_at = 0.0
_last_up_at = 0.0
_key_timer = None
_hotkey_lock = threading.Lock()
HOOK_STATS = {"hotkey": 0, "raw": 0, "poll": 0, "error": "", "raw_error": "", "raw_ok": False}
# 学键模式：CAPTURE["until"] 之前收到的按键都记进 items，用来认「按的到底是哪个键」
CAPTURE = {"until": 0.0, "items": []}

# 钩子/raw 回调里绝不能做写日志、起线程这类慢活：
# 低级键盘钩子回调超时（LowLevelHooksTimeout 默认 300ms）会被系统静默卸掉，
# 表现就是「按了几下之后再也收不到」。所以回调只往队列里丢事件，处理交给专门线程。
_key_events = queue.Queue()


def _push_key_event(kind, src):
    try:
        _key_events.put_nowait((kind, src))
    except Exception:
        pass


def _key_dispatcher():
    while True:
        try:
            kind, src = _key_events.get()
        except Exception:
            continue
        try:
            if kind == "down":
                _hotkey_down(src)
            else:
                _hotkey_up(src)
        except Exception:
            pass


def _on_hotkey_down():
    if not CFG["enabled"]:
        return
    start_record()


def _on_hotkey_up():
    if _rec is not None:
        threading.Thread(target=stop_record, daemon=True).start()


def _hotkey_down(src="poll"):
    """按下：谁先发现都走这里。"""
    global _key_down, _down_at, _key_timer, _last_up_at
    with _hotkey_lock:
        if _key_down:
            return
        # 三条通路会互相追尾：hook 松手后轮询才看到按下，会误判成「按短了」。350ms 内当同一个动作。
        if time.time() - _last_up_at < 0.35:
            HOOK_STATS["debounce"] = HOOK_STATS.get("debounce", 0) + 1
            return
        _key_down = True
        _down_at = time.time()
    vk = int(CFG.get("vk") or VK_OEM_3)
    HOOK_STATS["hotkey"] += 1
    HOOK_STATS[src] = HOOK_STATS.get(src, 0) + 1
    HOOK_STATS["last_down"] = time.strftime("%H:%M:%S")
    log("热键按下 vk=%d（第 %d 次，来源 %s）" % (vk, HOOK_STATS["hotkey"], src))
    threading.Thread(target=_beep, args=("tap",), daemon=True).start()
    threading.Thread(target=hint, args=("🎙 听着…", 3000), daemon=True).start()
    t = threading.Timer(HOLD_MS / 1000.0, _on_hotkey_down)
    t.daemon = True
    with _hotkey_lock:
        _key_timer = t
    t.start()


def _hotkey_up(src="poll"):
    """松开：轮询和 raw input 都会报，已经松开就忽略。"""
    global _key_down, _key_timer, _last_up_at
    with _hotkey_lock:
        if not _key_down:
            return
        _key_down = False
        _last_up_at = time.time()
        held_ms = (time.time() - _down_at) * 1000 if _down_at else 0
        t = _key_timer
        _key_timer = None
    log("热键松开：按住 %.0fms（%s）" % (held_ms, src))
    if t is not None:
        t.cancel()
        if held_ms < HOLD_MS:
            log("太短了（< %dms），这次不开录" % HOLD_MS)
            threading.Thread(target=_beep, args=("cancel",), daemon=True).start()
            threading.Thread(target=hint, args=("按短了，按住久一点", 1200), daemon=True).start()
    _on_hotkey_up()


def _key_thread():
    """轮询按键状态判断「按住说话」。

    最初用的是 SetWindowsHookEx 低级钩子，实际跑起来一条事件都收不到（还被系统静默卸过），
    换成 GetAsyncKeyState 轮询：25ms 一次、不需要焦点、不挑权限。游戏全屏时可能读不到，
    所以再叠一层 raw input 兜底（见 _raw_key_thread）。
    """
    import ctypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]

    esc_latch = False
    log("热键轮询已就绪：按住 %s 说话（Esc 取消）" % CFG["hotkey"])
    while True:
        try:
            vk = int(CFG.get("vk") or VK_OEM_3)
            if user32.GetAsyncKeyState(vk) & 0x8000:
                _hotkey_down("poll")
            else:
                _hotkey_up("poll")

            esc = bool(user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000)
            if esc and not esc_latch and _rec is not None:
                esc_latch = True
                threading.Thread(target=lambda: stop_record(cancel=True), daemon=True).start()
            elif not esc:
                esc_latch = False
        except Exception:
            import traceback as _tb
            HOOK_STATS["error"] = _tb.format_exc()[-200:]
        time.sleep(0.025)


def _raw_key_thread():
    """Raw Input 监听：注册 RIDEV_INPUTSINK，不靠焦点，全屏游戏里也能收到按键。

    这条路失败的机器（权限/系统策略）就只靠轮询，不影响其它功能。
    """
    import ctypes
    from ctypes import wintypes

    WM_INPUT = 0x00FF
    WM_APP_REHOOK = 0x8000 + 1
    RID_INPUT = 0x10000003
    RIDEV_INPUTSINK = 0x00000100
    RIM_TYPEKEYBOARD = 1
    RI_KEY_BREAK = 0x01

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    user32.DefWindowProcW.restype = ctypes.c_ssize_t
    user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.CreateWindowExW.restype = wintypes.HWND
    user32.CreateWindowExW.argtypes = [
        wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
        wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, wintypes.LPVOID,
    ]
    user32.GetRawInputData.restype = wintypes.UINT
    user32.GetRawInputData.argtypes = [
        wintypes.HANDLE, wintypes.UINT, wintypes.LPVOID, ctypes.POINTER(wintypes.UINT), wintypes.UINT,
    ]

    class RAWINPUTDEVICE(ctypes.Structure):
        _fields_ = [
            ("usUsagePage", wintypes.USHORT),
            ("usUsage", wintypes.USHORT),
            ("dwFlags", wintypes.DWORD),
            ("hwndTarget", wintypes.HWND),
        ]

    class RAWINPUTHEADER(ctypes.Structure):
        _fields_ = [
            ("dwType", wintypes.DWORD),
            ("dwSize", wintypes.DWORD),
            ("hDevice", wintypes.HANDLE),
            ("wParam", wintypes.WPARAM),
        ]

    class RAWKEYBOARD(ctypes.Structure):
        _fields_ = [
            ("MakeCode", wintypes.USHORT),
            ("Flags", wintypes.USHORT),
            ("Reserved", wintypes.USHORT),
            ("VKey", wintypes.USHORT),
            ("Message", wintypes.UINT),
            ("ExtraInformation", wintypes.ULONG),
        ]

    WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)

    class WNDCLASSW(ctypes.Structure):
        _fields_ = [
            ("style", wintypes.UINT),
            ("lpfnWndProc", WNDPROC),
            ("cbClsExtra", ctypes.c_int),
            ("cbWndExtra", ctypes.c_int),
            ("hInstance", wintypes.HINSTANCE),
            ("hIcon", wintypes.HICON),
            ("hCursor", wintypes.HANDLE),
            ("hbrBackground", wintypes.HBRUSH),
            ("lpszMenuName", wintypes.LPCWSTR),
            ("lpszClassName", wintypes.LPCWSTR),
        ]

    def _on_raw(lparam):
        try:
            size = wintypes.UINT(0)
            hdr_size = ctypes.sizeof(RAWINPUTHEADER)
            user32.GetRawInputData(lparam, RID_INPUT, None, ctypes.byref(size), hdr_size)
            if not size.value:
                return
            buf = ctypes.create_string_buffer(size.value)
            got = user32.GetRawInputData(lparam, RID_INPUT, buf, ctypes.byref(size), hdr_size)
            if got == 0xFFFFFFFF or got == 0:
                return
            hdr = ctypes.cast(buf, ctypes.POINTER(RAWINPUTHEADER)).contents
            if hdr.dwType != RIM_TYPEKEYBOARD:
                return
            kb = ctypes.cast(
                ctypes.byref(buf, hdr_size), ctypes.POINTER(RAWKEYBOARD)
            ).contents
            vk = int(kb.VKey)
            HOOK_STATS["raw_any"] = HOOK_STATS.get("raw_any", 0) + 1
            try:
                recent = HOOK_STATS.get("raw_recent")
                if not isinstance(recent, list):
                    recent = []
                recent.append(vk)
                if len(recent) > 14:
                    del recent[:-14]
                HOOK_STATS["raw_recent"] = recent
            except Exception:
                pass
            if not (kb.Flags & RI_KEY_BREAK):
                try:
                    hist = HOOK_STATS.get("hist")
                    if not isinstance(hist, dict):
                        hist = {}
                    hist[str(vk)] = int(hist.get(str(vk), 0)) + 1
                    HOOK_STATS["hist"] = hist
                except Exception:
                    pass
            try:
                if time.time() < float(CAPTURE.get("until") or 0.0):
                    CAPTURE.setdefault("items", []).append(
                        "vk=%d scan=%d %s"
                        % (vk, int(kb.MakeCode), "up" if (kb.Flags & RI_KEY_BREAK) else "down")
                    )
                    if len(CAPTURE["items"]) > 40:
                        del CAPTURE["items"][:-40]
            except Exception:
                pass
            want = int(CFG.get("vk") or VK_OEM_3)
            if vk not in (want, VK_ESCAPE):
                return
            is_break = bool(kb.Flags & RI_KEY_BREAK)
            if vk == VK_ESCAPE:
                if not is_break and _rec is not None:
                    threading.Thread(
                        target=lambda: stop_record(cancel=True), daemon=True
                    ).start()
                return
            _push_key_event("up" if is_break else "down", "raw")
        except Exception:
            import traceback as _tb
            HOOK_STATS["raw_error"] = _tb.format_exc()[-200:]

    _hookbox = {}

    def _reinstall_hook():
        """必须由挂着消息循环的这条线程来装/重装钩子：
        低级键盘钩子的回调会被派发到「安装它的那个线程」，别的线程装上去等于白装。"""
        try:
            old = _hookbox.get("hh")
            if old:
                try:
                    user32.UnhookWindowsHookEx(ctypes.c_void_p(old))
                except Exception:
                    pass
            proc_ref = _hookbox.get("proc")
            if not proc_ref:
                return
            nh = user32.SetWindowsHookExW(13, proc_ref, None, 0)
            if nh:
                _hookbox["hh"] = nh
                _hookbox["live"] = True
                HOOK_STATS["ll_ok"] = True
                HOOK_STATS["ll_rehook"] = HOOK_STATS.get("ll_rehook", 0) + 1
            else:
                HOOK_STATS["ll_error"] = "rehook failed: %d" % ctypes.get_last_error()
        except Exception:
            pass

    def _wndproc(hwnd, msg, wparam, lparam):
        if msg == WM_INPUT:
            _on_raw(lparam)
            return 0
        if msg == WM_APP_REHOOK:
            _reinstall_hook()
            return 0
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    proc = WNDPROC(_wndproc)  # 必须留引用，否则回调被回收
    hinst = kernel32.GetModuleHandleW(None)
    cls_name = "WhaleVoiceRawInputWnd"
    wc = WNDCLASSW(0, proc, 0, 0, hinst, None, None, None, None, cls_name)
    try:
        user32.RegisterClassW(ctypes.byref(wc))
    except Exception:
        pass
    hwnd = user32.CreateWindowExW(0, cls_name, "whale-voice-raw", 0, 0, 0, 0, 0, None, None, hinst, None)
    if not hwnd:
        HOOK_STATS["raw_error"] = "CreateWindowExW failed: %d" % ctypes.get_last_error()
        log("raw input 不可用（建窗口失败），只靠轮询")
        return
    rid = RAWINPUTDEVICE(0x01, 0x06, RIDEV_INPUTSINK, hwnd)  # generic desktop / keyboard
    if not user32.RegisterRawInputDevices(ctypes.byref(rid), 1, ctypes.sizeof(rid)):
        HOOK_STATS["raw_error"] = "RegisterRawInputDevices failed: %d" % ctypes.get_last_error()
        log("raw input 注册失败（可能权限不够），只靠轮询")
        return
    HOOK_STATS["raw_ok"] = True
    log("raw input 已挂上：全屏/独占游戏里也能收到按键")

    # 第三条路：低级键盘钩子。比 raw input 更靠前，游戏独占键盘时往往还能拿到，
    # 回调里永远 CallNextHookEx，不吞键、不挡游戏输入。
    class KBDLLHOOKSTRUCT(ctypes.Structure):
        _fields_ = [
            ("vkCode", wintypes.DWORD),
            ("scanCode", wintypes.DWORD),
            ("flags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", ctypes.c_void_p),
        ]

    HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
    user32.SetWindowsHookExW.restype = ctypes.c_void_p
    user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, ctypes.c_void_p, wintypes.DWORD]
    user32.CallNextHookEx.restype = ctypes.c_ssize_t
    user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]

    def _ll_proc(nCode, wparam, lparam):
        try:
            if nCode == 0 and lparam:
                kb = ctypes.cast(lparam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                vk = int(kb.vkCode)
                HOOK_STATS["ll_any"] = HOOK_STATS.get("ll_any", 0) + 1
                want = int(CFG.get("vk") or VK_OEM_3)
                if vk == VK_ESCAPE:
                    if int(wparam) in (0x100, 0x104) and _rec is not None:
                        threading.Thread(
                            target=lambda: stop_record(cancel=True), daemon=True
                        ).start()
                elif vk == want:
                    if int(wparam) in (0x100, 0x104):
                        _push_key_event("down", "hook")
                    elif int(wparam) in (0x101, 0x105):
                        _push_key_event("up", "hook")
        except Exception:
            import traceback as _tb
            HOOK_STATS["ll_error"] = _tb.format_exc()[-200:]
        try:
            return user32.CallNextHookEx(None, nCode, wparam, lparam)
        except Exception:
            return 0

    hook_proc = HOOKPROC(_ll_proc)  # 保留引用，不然回调会失效
    _hookbox["proc"] = hook_proc
    hhook = user32.SetWindowsHookExW(13, hook_proc, None, 0)  # WH_KEYBOARD_LL，hMod 必须 NULL
    if hhook:
        _hookbox["hh"] = hhook
        _hookbox["live"] = True
        HOOK_STATS["ll_ok"] = True
        log("键盘钩子已挂上：游戏独占键盘时也收得到")
        user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]

        def _keepalive():
            # 系统可能因为回调超时静默摘钩子。这里只做「发现钩子不再有输入就喊一声」，
            # 重装交给挂着消息循环的窗口线程（PostMessage），绝不在这条线程自己装。
            last_ll = HOOK_STATS.get("ll_any", 0)
            last_raw = HOOK_STATS.get("raw_any", 0)
            while True:
                time.sleep(4)
                try:
                    ll = HOOK_STATS.get("ll_any", 0)
                    raw = HOOK_STATS.get("raw_any", 0)
                    if raw > last_raw and ll <= last_ll:
                        HOOK_STATS["ll_stale"] = HOOK_STATS.get("ll_stale", 0) + 1
                        user32.PostMessageW(hwnd, WM_APP_REHOOK, 0, 0)
                    last_ll = ll
                    last_raw = raw
                except Exception:
                    pass

        threading.Thread(target=_keepalive, daemon=True).start()
    else:
        HOOK_STATS["ll_error"] = "SetWindowsHookExW failed: %d" % ctypes.get_last_error()
        log("键盘钩子挂不上，靠 raw input 和轮询")

    msg = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))


# ---------------- HTTP ----------------
class Handler(BaseHTTPRequestHandler):
    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health"):
            try:
                base, _key, model = whale_llm.load_provider()
            except Exception:
                model = ""
            return self._json(
                200,
                {
                    "ok": True,
                    "enabled": bool(CFG["enabled"]),
                    "hotkey": CFG["hotkey"],
                    "recording": _rec is not None,
                    "model": model,
                    "turns": len(_history) // 2,
                    "hook": dict(HOOK_STATS),
                    "vk": CFG.get("vk"),
                    "hist": HOOK_STATS.get("hist") or {},
                    "capturing": time.time() < float(CAPTURE.get("until") or 0.0),
                    "capture": CAPTURE.get("items") or [],
                },
            )
        return self._json(404, {"ok": False})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            data = json.loads(raw.decode("utf-8") or "{}")
        except Exception as exc:
            return self._json(400, {"ok": False, "error": "body 不是 JSON: %s" % exc})

        if self.path.startswith("/config"):
            if "enabled" in data:
                CFG["enabled"] = bool(data["enabled"])
            if "hotkey" in data:
                CFG["hotkey"] = str(data["hotkey"])
                CFG["vk"] = _vk_of(CFG["hotkey"])
            if "beep" in data:
                CFG["beep"] = bool(data["beep"])
            log("配置更新 %s" % json.dumps(data, ensure_ascii=False))
            return self._json(200, {"ok": True, "cfg": {k: CFG[k] for k in ("enabled", "hotkey", "beep")}})

        if self.path.startswith("/say"):
            text = str(data.get("text") or "").strip()
            if not text:
                return self._json(400, {"ok": False, "error": "没有 text"})
            _jobs.put(("text", text))
            return self._json(200, {"ok": True})

        if self.path.startswith("/listen"):
            return self._json(200, {"ok": start_record()})

        if self.path.startswith("/talk/dbgstart"):
            try:
                return self._json(200, dbg_start(int(data.get("index") or 0), float(data.get("sec") or 90)))
            except Exception as exc:
                return self._json(500, {"ok": False, "error": str(exc)[:200]})

        if self.path.startswith("/talk/dbgstop"):
            return self._json(200, dbg_stop())

        if self.path.startswith("/talk/capture"):
            ms = int(data.get("ms") or 12000)
            CAPTURE["items"] = []
            CAPTURE["until"] = time.time() + ms / 1000.0
            log("进入学键模式 %dms" % ms)
            return self._json(200, {"ok": True, "ms": ms})

        if self.path.startswith("/talk/bind"):
            vk = int(data.get("vk") or 0)
            if not vk:
                return self._json(400, {"ok": False, "error": "没有 vk"})
            name = "0x%02X" % vk
            CFG["vk"] = vk
            CFG["hotkey"] = name
            saved = _save_hotkey(name)
            log("热键改绑 vk=%d 写盘=%s" % (vk, saved))
            return self._json(200, {"ok": True, "vk": vk, "saved": saved})

        return self._json(404, {"ok": False})

    def log_message(self, fmt, *args):
        return


def main():
    log("==== voice-chat 启动 :%d  热键=%s ====" % (PORT, CFG["hotkey"]))
    threading.Thread(target=_worker, daemon=True).start()
    threading.Thread(target=_key_dispatcher, daemon=True).start()
    threading.Thread(target=_key_thread, daemon=True).start()
    threading.Thread(target=_raw_key_thread, daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    srv.daemon_threads = True
    srv.serve_forever()


if __name__ == "__main__":
    main()
