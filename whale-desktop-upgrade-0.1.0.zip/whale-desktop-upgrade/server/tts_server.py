# -*- coding: utf-8 -*-
"""鲸鱼娘桌宠 · 语音播放服务（<CHAR_NAME> GPT-SoVITS 音色）

把合成的语音直接在本机音箱播出来，不再只能在聊天里发语音消息。

  GET  /health                     -> 状态
  POST /speak   {"text": "...", "volume": 0.9, "wait": false}
                                   -> 合成并立即播放，返回 {ok, dur, cached}
  POST /synth   {"text": "..."}    -> 只合成，返回 audio/wav 字节
  POST /stop                       -> 停止播放
  POST /config  {"volume": 0.8}    -> 运行时调音量
日志: <根目录>/tts.log
"""
import os
import io
import json
import time
import wave
import hashlib
import threading
import subprocess
import sys
import traceback
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# 根目录：优先环境变量 WHALE_HOME，否则用本文件上一级（server/ 的父目录），换机器不用改代码
BASE = os.environ.get("WHALE_HOME") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(BASE, "tts.log")
CACHE_DIR = os.path.join(BASE, "server", "tts_cache")
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import whale_paths  # noqa: E402

ASTRBOT_CONFIG = whale_paths.astrbot_config()
PORT = int(os.environ.get("WHALE_TTS_PORT", "32172"))
GSV_URL = os.environ.get("WHALE_GSV_URL", "http://127.0.0.1:9880")
# 从 AstrBot 配置里读哪一路 GSV 音色参数：换成你自己的 provider id，或设环境变量
TTS_PROVIDER_ID = os.environ.get("WHALE_TTS_PROVIDER_ID", "<TTS_PROVIDER_ID>")
STT_URL = os.environ.get("WHALE_STT_URL", "http://127.0.0.1:32171")

_log_lock = threading.Lock()

# ---- 谁在说话（优先级仲裁）----
# talk（语音聊天）> chat（聊天映射）> peek（窥屏）
# 规则：talk 正在说的时候，peek/chat 的播报一律跳过，绝不插嘴；
#       反过来 talk 要说话，可以把 peek/chat 直接打断。
SPEAK_SRC = {"name": "", "until": 0.0}
SRC_LOCK = threading.Lock()
SRC_RANK = {"talk": 3, "chat": 2, "peek": 1}


def wav_seconds(data):
    try:
        with wave.open(io.BytesIO(data), "rb") as w:
            return w.getnframes() / float(w.getframerate() or 1)
    except Exception:
        return max(0.0, (len(data) - 44) / 96000.0)


def speak_allowed(source):
    src = (source or "chat").strip().lower()
    if src not in SRC_RANK:
        src = "chat"
    with SRC_LOCK:
        busy = time.time() < SPEAK_SRC["until"]
        cur = SPEAK_SRC["name"]
    if busy and cur and SRC_RANK.get(src, 0) < SRC_RANK.get(cur, 0):
        return False, src, cur
    return True, src, cur


def mark_source(src, seconds):
    with SRC_LOCK:
        SPEAK_SRC["name"] = src
        SPEAK_SRC["until"] = time.time() + max(0.5, float(seconds)) + 0.4


def clear_source():
    with SRC_LOCK:
        SPEAK_SRC["name"] = ""
        SPEAK_SRC["until"] = 0.0


def log(msg):
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with _log_lock:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line + "\n")
    except Exception:
        pass


CFG = {"volume": 0.9, "speed_factor": 1.0, "enabled": True}
PLAY_LOCK = threading.Lock()
CURRENT = {"proc": None}


def _ref_audio_default():
    """参考音频：环境变量 WHALE_REF_AUDIO > paths.json > <BASE>/ref/ref.wav > GPT-SoVITS 目录里找。"""
    return whale_paths.ref_audio()


def gsv_params():
    """每次重读 AstrBot 配置里的 GSV 音色参数，改了音色不用重启这里。"""
    default = {
        "ref_audio_path": _ref_audio_default(),
        "prompt_text": "此刻复活，听起来就很好玩吧，对吧对吧，你也一起来，来见识下我的才艺",
        "text_lang": "zh",
        "prompt_lang": "zh",
        "text_split_method": "cut5",
        "top_k": 15,
        "top_p": 0.9,
        "temperature": 0.9,
    }
    try:
        with open(ASTRBOT_CONFIG, encoding="utf-8-sig") as f:
            cfg = json.load(f)
        for p in cfg.get("provider", []):
            if p.get("id") == TTS_PROVIDER_ID:
                g = p.get("gsv_default_parms") or {}
                default["ref_audio_path"] = g.get("gsv_ref_audio_path", default["ref_audio_path"])
                default["prompt_text"] = g.get("gsv_prompt_text", default["prompt_text"])
                default["text_lang"] = g.get("gsv_text_lang", "zh")
                default["prompt_lang"] = g.get("gsv_prompt_lang", "zh")
                default["text_split_method"] = g.get("gsv_text_split_method", "cut5")
                default["top_k"] = g.get("gsv_top_k", 15)
                default["top_p"] = g.get("gsv_top_p", 0.9)
                default["temperature"] = g.get("gsv_temperature", 0.9)
                break
    except Exception:
        log("读 AstrBot 配置失败，用内置默认音色\n" + traceback.format_exc())
    return default


def synth_wav(text, speed=None):
    """返回 wav 字节。命中缓存直接返回。"""
    text = (text or "").strip()
    if not text:
        raise ValueError("text 为空")
    speed = float(speed if speed is not None else CFG["speed_factor"])
    key = hashlib.md5((text + "|%.2f" % speed).encode("utf-8")).hexdigest()[:16]
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = os.path.join(CACHE_DIR, key + ".wav")
    if os.path.exists(path) and os.path.getsize(path) > 1000:
        return open(path, "rb").read(), True

    p = gsv_params()
    payload = {
        "text": text,
        "text_lang": p["text_lang"],
        "ref_audio_path": p["ref_audio_path"],
        "prompt_lang": p["prompt_lang"],
        "prompt_text": p["prompt_text"],
        "text_split_method": p["text_split_method"],
        "media_type": "wav",
        "streaming_mode": False,
        "top_k": p["top_k"],
        "top_p": p["top_p"],
        "temperature": p["temperature"],
        "speed_factor": speed,
    }
    req = urllib.request.Request(
        GSV_URL.rstrip("/") + "/tts",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=180) as r:
        data = r.read()
    if not data or data[:4] != b"RIFF":
        raise RuntimeError("合成返回不是 wav: %r" % data[:80])
    open(path, "wb").write(data)
    log("合成 %.1fs %d bytes: %s" % (time.time() - t0, len(data), text[:40]))
    return data, False


def notify_stt_mute(seconds):
    """正在念的这段话别被本地回环识别抓走，不然桌宠会以为自己听到了自己。"""
    try:
        body = json.dumps({"seconds": round(float(seconds) + 1.2, 2)}).encode("utf-8")
        req = urllib.request.Request(
            STT_URL.rstrip("/") + "/mute",
            data=body,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        pass


def play_wav_bytes(data, volume=None):
    """用独立 powershell 进程播放（MediaPlayer 控制音量最方便）。"""
    vol = float(volume if volume is not None else CFG["volume"])
    vol = max(0.0, min(1.0, vol))
    os.makedirs(os.path.join(BASE, "server", "tts_cache"), exist_ok=True)
    tmp = os.path.join(BASE, "server", "tts_cache", "_play_%d.wav" % int(time.time() * 1000))
    open(tmp, "wb").write(data)
    ps = (
        "Add-Type -AssemblyName PresentationCore;"
        "$p = New-Object System.Windows.Media.MediaPlayer;"
        "$p.Open([uri]'%s');"
        "$p.Volume = %f;"
        "$p.Play();"
        "$n = 0;"
        "while ($n -lt 600 -and -not $p.NaturalDuration.HasTimeSpan) { Start-Sleep -Milliseconds 50; $n++ };"
        "if ($p.NaturalDuration.HasTimeSpan) { Start-Sleep -Seconds ([math]::Ceiling($p.NaturalDuration.TimeSpan.TotalSeconds) + 1) }"
        " else { Start-Sleep -Seconds 6 };"
        "$p.Close(); Remove-Item -LiteralPath '%s' -ErrorAction SilentlyContinue"
    ) % (tmp.replace("'", "''"), vol, tmp.replace("'", "''"))
    with PLAY_LOCK:
        stop_playback()
        proc = subprocess.Popen(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        CURRENT["proc"] = proc
    return proc


def stop_playback():
    proc = CURRENT.get("proc")
    if proc and proc.poll() is None:
        try:
            proc.kill()
        except Exception:
            pass
    CURRENT["proc"] = None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health"):
            try:
                with urllib.request.urlopen(GSV_URL.rstrip("/") + "/tts", timeout=3) as r:
                    gsv = r.status < 500
            except urllib.error.HTTPError:
                gsv = True   # 接口存在，只是方法不对
            except Exception:
                gsv = False
            return self._json(200, {"ok": True, "enabled": CFG["enabled"], "volume": CFG["volume"],
                                    "gsv_ready": gsv, "gsv_url": GSV_URL,
                                    "playing": bool(CURRENT.get("proc") and CURRENT["proc"].poll() is None)})
        self._json(404, {"ok": False})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            data = json.loads(raw.decode("utf-8") or "{}")
        except Exception as exc:
            return self._json(400, {"ok": False, "error": "body 不是 JSON: %s" % exc})

        if self.path.startswith("/stop"):
            stop_playback()
            clear_source()
            return self._json(200, {"ok": True, "stopped": True})

        if self.path.startswith("/config"):
            for k in ("volume", "speed_factor", "enabled"):
                if k in data:
                    CFG[k] = data[k]
            log("配置更新 %s" % json.dumps(data, ensure_ascii=False))
            return self._json(200, {"ok": True, "cfg": CFG})

        text = str(data.get("text") or "").strip()
        if not text:
            return self._json(400, {"ok": False, "error": "没有 text"})
        if not CFG["enabled"]:
            return self._json(200, {"ok": True, "skipped": True, "reason": "disabled"})

        source = str(data.get("source") or "chat")
        if self.path.startswith("/speak"):
            ok, src, cur = speak_allowed(source)
            if not ok:
                log("让路：%s 正在说话，跳过 %s 的播报（%s）" % (cur, src, text[:24]))
                return self._json(200, {"ok": True, "skipped": True, "reason": "busy-" + cur})
        else:
            src = "chat"

        try:
            t0 = time.time()
            wav, cached = synth_wav(text, data.get("speed"))
            if self.path.startswith("/synth"):
                self.send_response(200)
                self.send_header("Content-Type", "audio/wav")
                self.send_header("Content-Length", str(len(wav)))
                self.end_headers()
                self.wfile.write(wav)
                log("返回音频 %d bytes (%s)" % (len(wav), text[:30]))
                return
            # /speak
            dur = wav_seconds(wav)
            notify_stt_mute(dur)
            proc = play_wav_bytes(wav, data.get("volume"))
            mark_source(src, dur)
            if data.get("wait") is False:
                return self._json(200, {"ok": True, "cached": cached, "bytes": len(wav),
                                        "elapsed": round(time.time() - t0, 2)})
            try:
                proc.wait(timeout=180)
            except Exception:
                pass
            return self._json(200, {"ok": True, "cached": cached, "bytes": len(wav),
                                    "elapsed": round(time.time() - t0, 2)})
        except Exception:
            log("处理失败\n" + traceback.format_exc())
            return self._json(500, {"ok": False, "error": traceback.format_exc()[-300:]})


def main():
    log("==== tts_server 启动 :%d (GSV=%s) ====" % (PORT, GSV_URL))
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    srv.daemon_threads = True
    srv.serve_forever()


if __name__ == "__main__":
    main()
