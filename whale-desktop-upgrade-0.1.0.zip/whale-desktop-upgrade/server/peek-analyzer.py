# -*- coding: utf-8 -*-
"""窥屏分析端点：把桌宠攒下的一串窗口画面交给视觉模型，回一句<CHAR_NAME>的话。

桌宠（peek.mjs）每 10 秒抓一张「用户选中的那个窗口」，攒 45~90 秒后 POST 到这里：
    { "window": "xxx", "images": ["data:image/jpeg;base64,...", ...], "spanSec": 60, "count": 6 }
返回：
    { "text": "一句人话" }

模型配置直接复用 AstrBot 的 cmd_config.json，每次请求重读，改了模型不用重启这里。
只监听 127.0.0.1，端口默认 32170。
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOST = "127.0.0.1"
PORT = int(os.environ.get("PEEK_PORT", "32170"))

# 根目录：优先环境变量 WHALE_HOME，否则用本文件上一级（server/ 的父目录）
BASE = os.environ.get("WHALE_HOME") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 模型来源：环境变量 ASTRBOT_CONFIG > paths.json 的 astrbotConfig > <BASE>/astrbot.json。
# 都没配就当作没配置，调用时会给出明确提示，不再回落到任何本机绝对路径。
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import whale_paths  # noqa: E402

ASTRBOT_CONFIG = whale_paths.astrbot_config()

# 优先用这个对话模型（它得能看图）。找不到就退回默认对话模型。
PREFERRED_PROVIDERS = [
    p.strip()
    for p in os.environ.get("PEEK_PROVIDER", "openai_1/gpt-5.6,openai/gpt-5.6,GLM/glm-4.5-air").split(",")
    if p.strip()
]

LOG_FILE = os.environ.get("PEEK_LOG") or os.path.join(BASE, "peek-analyzer.log")

SYSTEM_PROMPT = """你是<CHAR_NAME>，<WORLD_PLACE><WORLD_SCHOOL><WORLD_DEPT>的学生，也是校园网络歌手「<CHAR_ALIAS>」。
现在你正陪着用户，看他选中的那个窗口里正在发生的事。你拿到的是那个窗口最近一段时间里连续几张画面（约每 10 秒一张，按时间从早到晚）。

说话要求：
1. 只看那个窗口里的内容。你没有看整块屏幕，也不要提到桌面上其他窗口、图标或系统界面。
2. 用你自己的口气，1~2 句，像坐在旁边一起看的人随口说的。不要长篇分析、不要列点。
3. 不要写括号里的动作描写，不要说“作为 AI”“根据图片”。
4. 画面是游戏就跟着起劲或提醒小心；是视频就跟着看下去；是代码或文档就问一句进度、或者提醒歇一会儿。
5. 别硬找话说，画面没什么变化就轻轻搭一句也行。
6. 如果给你的文字里附带了这个窗口的声音内容，就当作你亲耳听到的，自然地接；不要逐字复述，也不要提语音识别、识别错字这类事。"""

USER_PROMPT = (
    "这是窗口「{window}」最近 {span} 秒里的 {count} 张画面（每 {cap} 秒一张，按时间从早到晚）。{speech}"
    "看看我在做什么，用你的口气跟我说一句。"
)

STT_URL = os.environ.get("WHALE_STT_URL", "http://127.0.0.1:32171")

BRACKET_ACTIONS = re.compile(r"[（(][^（）()]{1,24}[）)]")


def log(msg: str) -> None:
    line = time.strftime("%m-%d %H:%M:%S ") + str(msg)
    try:
        print(line, flush=True)
    except Exception:
        pass
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def clean_text(text: str) -> str:
    text = (text or "").strip()
    text = text.replace("**", "").replace("__", "")
    text = BRACKET_ACTIONS.sub("", text)
    text = re.sub(r"\s{2,}", " ", text).strip()
    if len(text) > 220:
        text = text[:220].rstrip() + "…"
    return text


def load_provider() -> tuple[str, str, str]:
    """返回 (api_base, api_key, model)。每次重读配置。"""
    if not ASTRBOT_CONFIG or not os.path.isfile(ASTRBOT_CONFIG):
        raise RuntimeError(
            "找不到模型配置：请在 paths.json 里填 astrbotConfig，"
            "或设 ASTRBOT_CONFIG 指向 cmd_config.json；也可以直接把配置放成 <根目录>/astrbot.json"
        )
    with open(ASTRBOT_CONFIG, encoding="utf-8-sig") as f:
        cfg = json.load(f)

    sources = {s.get("id"): s for s in (cfg.get("provider_sources") or [])}
    providers = {p.get("id"): p for p in (cfg.get("provider") or [])}

    order = PREFERRED_PROVIDERS + list(providers.keys())
    seen = set()
    for pid in order:
        if pid in seen:
            continue
        seen.add(pid)
        p = providers.get(pid)
        if not p or p.get("enable") is False:
            continue
        if p.get("type") and "tts" in str(p.get("type")):
            continue
        src = sources.get(p.get("provider_source_id") or "")
        if not src:
            continue
        keys = src.get("key") or []
        if isinstance(keys, str):
            keys = [keys]
        key = (keys[0] if keys else "") or ""
        base = (src.get("api_base") or "").rstrip("/")
        model = p.get("model") or ""
        if key and base and model:
            return base, key, model
    raise RuntimeError("配置里没找到可用的对话模型")


def fetch_speech(span: int) -> str:
    """从本地语音识别服务取这段时间电脑在说什么（识别不到就返回空串）。"""
    try:
        url = "%s/recent?seconds=%d" % (STT_URL.rstrip("/"), max(30, int(span)))
        with urllib.request.urlopen(url, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        text = (data.get("text") or "").strip()
    except Exception:
        return ""
    if not text:
        return ""
    if len(text) > 600:
        text = text[-600:]
    return "\n另外，这段时间这个窗口里传出的说话声（本地语音识别，可能有错字）：%s\n" % text


def call_model(images: list[str], window: str, span: int, count: int, cap: float, speech: str = "") -> str:
    base, key, model = load_provider()
    content = [{"type": "text", "text": USER_PROMPT.format(window=window, span=span, count=count, cap=cap, speech=speech)}]
    for img in images:
        content.append({"type": "image_url", "image_url": {"url": img}})
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": content},
        ],
        "max_tokens": 400,
        "temperature": 0.85,
    }
    req = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read().decode("utf-8", "ignore"))
    try:
        text = data["choices"][0]["message"]["content"]
    except Exception:
        raise RuntimeError("模型返回格式不对：" + json.dumps(data, ensure_ascii=False)[:200])
    if isinstance(text, list):
        text = "".join(part.get("text", "") for part in text if isinstance(part, dict))
    return clean_text(text)


def pick(images: list[str], limit: int = 6) -> list[str]:
    if len(images) <= limit:
        return images
    if limit == 1:
        return [images[-1]]
    step = (len(images) - 1) / (limit - 1)
    return [images[round(i * step)] for i in range(limit)]


class Handler(BaseHTTPRequestHandler):
    server_version = "WhalePeek/1.0"

    def _json(self, code: int, obj: dict) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/peek/health"):
            return self._json(200, {"ok": True, "service": "peek-analyzer", "port": PORT})
        self._json(404, {"error": "not found"})

    def do_POST(self):
        if not self.path.startswith("/peek"):
            return self._json(404, {"error": "not found"})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            data = json.loads(raw.decode("utf-8", "ignore") or "{}")
        except Exception as exc:
            return self._json(400, {"error": "body 不是 JSON: %s" % exc})

        images = data.get("images") or []
        if not isinstance(images, list):
            images = []
        if not images and data.get("image"):
            images = [data["image"]]
        images = [x for x in images if isinstance(x, str) and x.strip()]
        if not images:
            return self._json(400, {"error": "没有图片"})

        window = str(data.get("window") or "那个窗口")
        cap = data.get("captureSec") or 10
        count = len(images)
        span = int(data.get("spanSec") or count * float(cap))
        images = pick(images, int(os.environ.get("PEEK_MAX_IMAGES", "6")))

        started = time.time()
        try:
            speech = fetch_speech(span)
            if speech:
                log("[peek] 附带声音: %s" % speech.strip()[:100])
            text = call_model(images, window, span, count, cap, speech)
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", "ignore")[:200]
            except Exception:
                pass
            log("[peek] 模型 HTTP %s %s" % (exc.code, detail))
            return self._json(502, {"error": "模型返回 %s: %s" % (exc.code, detail)})
        except Exception as exc:
            log("[peek] 失败: %s" % exc)
            return self._json(502, {"error": str(exc)})

        if not text:
            return self._json(502, {"error": "模型没说话"})
        log("[peek] %s (%d 张/%.1fs) -> %s" % (window, count, time.time() - started, text[:100]))
        return self._json(200, {"text": text, "window": window, "images": count})

    def log_message(self, fmt, *args):
        return


def main():
    log("[peek] 分析端点启动: http://%s:%d/peek" % (HOST, PORT))
    try:
        base, key, model = load_provider()
        log("[peek] 使用模型: %s (%s)" % (model, base))
    except Exception as exc:
        log("[peek] 警告：%s" % exc)
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
