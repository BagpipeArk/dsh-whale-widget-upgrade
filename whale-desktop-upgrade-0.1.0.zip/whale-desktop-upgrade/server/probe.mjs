import { startHost } from './host-shim.mjs'

const host = await startHost({ port: 32168, onLog: (s) => console.log('[log] ' + s) })
console.log('URL:', host.url)

async function hit(p) {
  try {
    const r = await fetch(host.url.replace(/\/$/, '') + p)
    const t = await r.text()
    console.log(`\n=== ${p} -> ${r.status} (${r.headers.get('content-type')}) ===`)
    console.log(t.slice(0, 600))
  } catch (err) {
    console.log(`\n=== ${p} -> ERR ${err.message} ===`)
  }
}

await hit('/')
await hit('/dsh-whale/size.json')
await hit('/dsh-whale/balance.json')
await hit('/dsh-whale/bubble.json')
await hit('/dsh-whale/roles.json')
await hit('/dsh-whale/update-check.json')

setTimeout(() => process.exit(0), 1500)
