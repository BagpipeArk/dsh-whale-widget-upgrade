// patch-vendor.mjs —— 对上游 widget.js 做两处「外部够不着、只能改源码」的补丁
//
// ① 自检闸门：[standalone-patch]
//    assets/whale-widget.js 启动时会探测 #root 里是否存在 DSH composer 输入区，
//    探测不到就无限等待、一行 DOM 都不碰 —— 独立桌面版没有 DSH 界面，于是永远不出现。
//    做法：把 dshwIsChatRoot() 改成直接返回 true。
//
// ② 点击形变：[click-tap-patch]
//    出厂的按压形变写死成 SQUISH = 'scaleY(0.88) scaleX(1.05)'，而 SQUISH 在 IIFE 闭包里，
//    外部拿不到（实测 typeof 全 undefined）。控制中心要能调「点击的运动幅度」，
//    所以把**读取处**改成走一个外部可写的钩子：window.__whaleTap = { on, amp }。
//
// 两个补丁都是幂等的，重复执行安全；原文件第一次打补丁前留一份 .orig 备份。
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const TARGET = path.resolve(__dirname, '..', 'vendor', 'whale-widget', 'assets', 'whale-widget.js')

const MARK = '[standalone-patch]'
const ORIGINAL_HEAD = `function dshwIsChatRoot(r) {
  if (!r || !r.querySelector) return false`

const PATCHED_HEAD = `function dshwIsChatRoot(r) {
  // ${MARK} 独立桌面版：没有 DSH 聊天界面，自检直接放行（原判据保留在下方，不再使用）
  return true
  // eslint-disable-next-line no-unreachable
  if (!r || !r.querySelector) return false`

const TAP_MARK = '[click-tap-patch]'
const TAP_ORIG = `var SQUISH = 'scaleY(0.88) scaleX(1.05)'`
const TAP_HEAD = `var __whaleTapSquish = function () {
  // ${TAP_MARK} 点击形变幅度：amp = 压扁量（0~0.35），由控制中心写入 window.__whaleTap
  try {
    var c = window.__whaleTap
    if (c && c.on === false) return 'scaleY(1) scaleX(1)'
    var a = c && isFinite(Number(c.amp)) ? Math.max(0, Math.min(0.35, Number(c.amp))) : 0.12
    return 'scaleY(' + (1 - a).toFixed(3) + ') scaleX(' + (1 + a * 0.55).toFixed(3) + ')'
  } catch (err) { return SQUISH }
}
var SQUISH = 'scaleY(0.88) scaleX(1.05)'`

function backupOnce(src) {
  if (!fs.existsSync(TARGET + '.orig')) fs.writeFileSync(TARGET + '.orig', src, 'utf8')
}

export function patchVendor() {
  if (!fs.existsSync(TARGET)) throw new Error('找不到 whale-widget.js: ' + TARGET)
  let src = fs.readFileSync(TARGET, 'utf8')
  const applied = []
  const skipped = []
  let touched = false

  // ① 自检闸门
  if (src.indexOf(MARK) >= 0) {
    applied.push('standalone')
  } else if (src.indexOf(ORIGINAL_HEAD) < 0) {
    skipped.push('standalone：没找到原始自检函数（上游可能改过），保持原样')
  } else {
    const next = src.replace(ORIGINAL_HEAD, PATCHED_HEAD)
    if (next !== src) {
      src = next
      touched = true
      applied.push('standalone')
    }
  }

  // ② 点击形变钩子
  if (src.indexOf(TAP_MARK) >= 0) {
    applied.push('tap')
  } else if (src.indexOf(TAP_ORIG) < 0) {
    skipped.push('tap：没找到 SQUISH 定义（上游可能改过），点击幅度退回出厂值')
  } else {
    let next = src.replace(TAP_ORIG, TAP_HEAD)
    next = next.split('body.style.transform = SQUISH').join('body.style.transform = __whaleTapSquish()')
    if (next !== src) {
      src = next
      touched = true
      applied.push('tap')
    } else {
      skipped.push('tap：没找到 SQUISH 的使用处，保持原样')
    }
  }

  if (touched) {
    backupOnce(fs.readFileSync(TARGET, 'utf8'))
    fs.writeFileSync(TARGET, src, 'utf8')
  }
  return { status: touched ? 'patched' : 'already', applied, skipped, file: TARGET }
}

export function isPatched() {
  try {
    return fs.readFileSync(TARGET, 'utf8').indexOf(MARK) >= 0
  } catch (err) {
    return false
  }
}

// 直接运行时自己执行
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  const r = patchVendor()
  console.log(r)
}
