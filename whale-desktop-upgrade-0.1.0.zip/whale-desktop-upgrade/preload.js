// preload.js —— 鼠标穿透的命门：只有指针真的落在鲸鱼/泡泡/菜单上时，窗口才接住鼠标
const { ipcRenderer, contextBridge } = require('electron')

// 挂件里的"三条杠"按钮改成直接开控制中心（旧的微缩菜单已废弃）
try {
  contextBridge.exposeInMainWorld('whaleShell', {
    openControl: (tab) => ipcRenderer.send('whale:open-control', tab || ''),
    // 聊天气泡里的交互（长按变回余额）回报给主进程
    chatEvent: (kind, payload) => ipcRenderer.send('whale:chat-event', kind, payload || null),
    // 挂件上的「锁定」小方框：切锁定 / 收状态
    setLock: (v) => ipcRenderer.send('whale:set-lock', !!v),
    // 记录小方框的位置。锁定后主窗口是穿透的、页面里点不到，主进程会按这个位置浮一颗能点的锁
    reportLockRect: (r) => ipcRenderer.send('whale:lockbtn-rect', r || null),
    // 挂件上的「窥屏」眼睛按钮：挑窗口 / 开关 / 收状态
    pickPeekWindow: () => ipcRenderer.send('whale:peek-pick'),
    setPeek: (v) => ipcRenderer.send('whale:peek-set', !!v),
    getPeekState: () => ipcRenderer.invoke('whale:peek-state'),
    onPeekState: (fn) => {
      try {
        ipcRenderer.on('whale:peek-state', (e, st) => fn(st || {}))
      } catch (err) {}
    },
    onWindowState: (fn) => {
      try {
        // 挂件里的脚本晚一步才挂监听：先把最近一次状态给它补上
        if (lastWinState) fn(lastWinState)
        ipcRenderer.on('whale:window-state', (e, st) => fn(st || {}))
      } catch (err) {}
    },
  })
} catch (err) {}

let ignoring = true // true = 整窗穿透，鼠标事件交给下面的窗口/桌面
let locked = false // true = 锁定（像歌词锁定），页面说啥都不接鼠标
let lastWinState = null // 主进程最近一次下发的 置顶/锁定 状态

function isWidgetElement(el) {
  let node = el
  for (let depth = 0; node && depth < 14; depth++) {
    const cls = typeof node.className === 'string' ? node.className : node.getAttribute && (node.getAttribute('class') || '')
    if (cls && String(cls).indexOf('dshwv') >= 0) return true
    if (node.id && String(node.id).indexOf('dshwv') >= 0) return true
    node = node.parentElement
  }
  return false
}

// 锁定态下唯一能碰的区域：挂件上那颗解锁小方框（留一点余量，手抖也能点中）
function lockHotZone(x, y) {
  try {
    const el = document.querySelector('.dshwv-lockbtn')
    if (!el) return false
    const r = el.getBoundingClientRect()
    if (!r || r.width <= 0 || r.height <= 0) return false
    const pad = 9
    return x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad
  } catch (err) {
    return false
  }
}

function setIgnore(next) {
  if (next === ignoring) return
  ignoring = next
  try {
    ipcRenderer.send('whale:set-ignore', ignoring)
  } catch (err) {}
}

window.addEventListener(
  'mousemove',
  (e) => {
    window.__dbgX = e.clientX
    window.__dbgY = e.clientY
    // 锁定态：只有指针压在解锁小方框上时才接住鼠标，其余一律穿透
    if (locked) {
      setIgnore(!lockHotZone(e.clientX, e.clientY))
      return
    }
    let hot = false
    try {
      const el = document.elementFromPoint(e.clientX, e.clientY)
      hot = isWidgetElement(el)
    } catch (err) {}
    setIgnore(!hot)
  },
  { passive: true }
)

// 指针离开文档（例如飞出屏幕边缘）时恢复穿透，避免窗口一直拦着鼠标
window.addEventListener('mouseleave', () => setIgnore(true))
window.addEventListener('blur', () => setIgnore(true))

// 子元素抢走 mousemove 时兜底：指针彻底离开页面
document.addEventListener(
  'mousemove',
  (e) => {
    if (locked) {
      setIgnore(!lockHotZone(e.clientX, e.clientY))
      return
    }
    if (e.target === document.documentElement || e.target === document.body) setIgnore(true)
  },
  { passive: true }
)

// 主进程告诉我们现在是置顶还是锁定
ipcRenderer.on('whale:window-state', (e, st) => {
  lastWinState = st || {}
  const wasLocked = locked
  locked = !!(st && st.lock)
  if (locked) setIgnore(true)
  if (wasLocked && !locked) {
    // 刚解锁：先按穿透放着，下一次 mousemove 会把交互还回来
    setIgnore(true)
  }
})
