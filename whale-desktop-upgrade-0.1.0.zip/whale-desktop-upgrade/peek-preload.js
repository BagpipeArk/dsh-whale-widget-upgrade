// peek-preload.js —— 窗口选择器（窥屏）的桥
const { ipcRenderer, contextBridge } = require('electron')

contextBridge.exposeInMainWorld('whalePeek', {
  list: () => ipcRenderer.invoke('whale-peek:list'),
  choose: (id, name) => ipcRenderer.send('whale-peek:choose', { id: id, name: name || '' }),
  cancel: () => ipcRenderer.send('whale-peek:cancel'),
})
