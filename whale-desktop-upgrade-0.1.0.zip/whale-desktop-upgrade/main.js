// main.js —— 独立桌面版小鲸鱼（Electron 主进程）
// 结构：Electron 壳（透明窗口 / 置底 / 穿透） + 本地假宿主（复用原 dsh-whale-widget 后端）
const { app, BrowserWindow, ipcMain, screen, Tray, Menu, shell, powerMonitor, desktopCapturer, nativeImage } = require('electron')
const path = require('node:path')
const fs = require('node:fs')
const http = require('node:http')
const { pathToFileURL } = require('node:url')
const { createFlyController } = require('./fly-widget')
const { createChatWidget } = require('./chat-widget')

const ROOT = __dirname
const PORT = Number(process.env.WHALE_PORT || 32168)

// —— 日志落文件：GUI 进程的 stdout 抓不到，只能自己写盘 ——
const LOG_DIR = path.join(ROOT, 'debug-shots')
const LOG_FILE = path.join(LOG_DIR, 'electron.log')
try {
  fs.mkdirSync(LOG_DIR, { recursive: true })
  fs.writeFileSync(LOG_FILE, '')
} catch (err) {}
function flog(...args) {
  const line = args
    .map((a) => {
      if (a instanceof Error) return a.stack || a.message
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a)
        } catch (e) {
          return String(a)
        }
      }
      return String(a)
    })
    .join(' ')
  try {
    fs.appendFileSync(LOG_FILE, line + '\n')
  } catch (err) {}
}
for (const k of ['log', 'warn', 'error']) {
  const orig = console[k].bind(console)
  console[k] = (...a) => {
    flog('[' + k + ']', ...a)
    try {
      orig(...a)
    } catch (e) {}
  }
}

let win = null
let tray = null
let host = null
let bottomTimer = null
let win32 = null
let winState = { pin: false, lock: false }
let lockHotkey = ''
let accountService = null
let settingsWin = null
let flyCtrl = null
let chatWidget = null
let chatBridge = null
let peekCtrl = null
let peekWin = null

// ---------------- Win32：把窗口压到最底层 ----------------
function loadWin32() {
  if (win32) return win32
  try {
    const koffi = require('koffi')
    const user32 = koffi.load('user32.dll')
    win32 = {
      SetWindowPos: user32.func('int __stdcall SetWindowPos(uint64, uint64, int, int, int, int, uint32)'),
    }
  } catch (err) {
    console.warn('[whale] 没能加载 Win32（置底功能将退化为普通窗口）:', err && err.message)
    win32 = null
  }
  return win32
}

const HWND_BOTTOM = 1
const SWP_NOSIZE = 0x0001
const SWP_NOMOVE = 0x0002
const SWP_NOACTIVATE = 0x0010

function hwndOf(win) {
  try {
    const buf = win.getNativeWindowHandle()
    return buf.length === 8 ? buf.readBigUInt64LE(0) : BigInt(buf.readUInt32LE(0))
  } catch (err) {
    return 0n
  }
}

function pushToBottom() {
  if (winState && winState.pin) return // 置顶时不再往底层压
  const w = loadWin32()
  if (!w || !win || win.isDestroyed()) return
  const hwnd = hwndOf(win)
  if (!hwnd) return
  try {
    w.SetWindowPos(hwnd, BigInt(HWND_BOTTOM), 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
  } catch (err) {}
}

// ---------------- 窗口置顶 / 锁定 ----------------
// 置顶 = 一直显示在其他窗口上面（持久，存进 whale-config.json）
// 锁定 = 整窗鼠标穿透（像歌词锁定）：页面再怎么判定"指针落在鲸鱼上"也不接鼠标
function readWinState() {
  const w = readConfig().win || {}
  return { pin: w.pin === true, lock: w.lock === true }
}

function pushWinStateToWidget() {
  if (!win || win.isDestroyed()) return
  try {
    win.webContents.send('whale:window-state', { pin: !!winState.pin, lock: !!winState.lock })
  } catch (err) {}
}

function pushWinStateToControl() {
  try {
    if (controlWin && !controlWin.isDestroyed()) controlWin.webContents.send('ctl:win', Object.assign({}, winState))
  } catch (err) {}
}

function applyWinState() {
  if (!win || win.isDestroyed()) return
  try {
    if (winState.pin) win.setAlwaysOnTop(true, 'screen-saver')
    else win.setAlwaysOnTop(false)
  } catch (err) {}
  // 锁定时强制穿透；解锁先恢复穿透，等页面下一次 mousemove 自己判断
  try {
    win.setIgnoreMouseEvents(true, { forward: true })
  } catch (err) {}
  if (!winState.pin) pushToBottom()
  pushWinStateToWidget()
  syncLockChip()
}

function setWinState(patch) {
  const p = patch || {}
  const next = {
    pin: 'pin' in p ? !!p.pin : !!winState.pin,
    lock: 'lock' in p ? !!p.lock : !!winState.lock,
  }
  winState = next
  writeConfig({ win: next })
  applyWinState()
  pushWinStateToControl()
  refreshTrayMenu()
  return next
}

// ---------------- 窗口 ----------------
function createWindow(url) {
  const { workArea } = screen.getPrimaryDisplay()
  // 窗口比工作区略大，保证贴边时气泡不会被裁掉
  const width = Math.round(workArea.width)
  const height = Math.round(workArea.height)

  win = new BrowserWindow({
    x: workArea.x,
    y: workArea.y,
    width,
    height,
    transparent: true,
    backgroundColor: '#00000000',
    frame: false,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    hasShadow: false,
    alwaysOnTop: false,
    focusable: true,
    show: false,
    acceptFirstMouse: true,
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
      spellcheck: false,
    },
  })

  // 默认整窗穿透；只有指针落在鲸鱼/泡泡/菜单上时才接住鼠标
  win.setIgnoreMouseEvents(true, { forward: true })
  win.setAlwaysOnTop(false)
  // 恢复上次的置顶 / 锁定状态
  winState = readWinState()
  applyWinState()

  win.loadURL(url)

  win.once('ready-to-show', () => {
    win.showInactive()
    pushToBottom()
    setTimeout(pushToBottom, 120)
    setTimeout(pushToBottom, 600)
    setTimeout(pushToBottom, 1500)
  })

  // 每次被激活/置前，都再压回底部
  win.on('focus', () => pushToBottom())
  win.on('blur', () => pushToBottom())
  win.on('show', () => pushToBottom())

  win.webContents.setWindowOpenHandler(({ url: target }) => {
    try {
      shell.openExternal(target)
    } catch (err) {}
    return { action: 'deny' }
  })
  win.webContents.on('will-navigate', (e, target) => {
    if (target !== url) {
      e.preventDefault()
      try {
        shell.openExternal(target)
      } catch (err) {}
    }
  })

  // 持续压底（别的窗口最大化/切前台后仍要待在底层）
  bottomTimer = setInterval(pushToBottom, 1200)

  // 调试：把窗口自身画面截图存盘，方便验证渲染（页面里的 console 也转发到终端）
  win.webContents.on('console-message', (e, level, message, line, sourceId) => {
    flog('[page:' + level + ']', message, sourceId ? '(' + path.basename(String(sourceId)) + ':' + line + ')' : '')
  })
  win.webContents.on('preload-error', (e, p, err) => flog('[preload-error]', p, err))
  win.webContents.on('did-fail-load', (e, code, desc, url) => flog('[did-fail-load]', code, desc, url))
  win.webContents.on('render-process-gone', (e, d) => flog('[render-gone]', d))
  win.webContents.on('unresponsive', () => flog('[unresponsive]'))

  const probePage = async (tag) => {
    try {
      const info = await win.webContents.executeJavaScript(
        `(() => {
          const root = document.querySelector('.dshwv-root');
          const img = document.querySelector('.dshwv-root img');
          const r = root ? root.getBoundingClientRect() : null;
          return {
            bodyLen: document.body ? document.body.innerHTML.length : -1,
            hasRoot: !!root,
            rootCls: root ? String(root.className) : null,
            rootRect: r ? { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) } : null,
            hasImg: !!img,
            imgSrc: img ? img.getAttribute('src') : null,
            dpr: window.devicePixelRatio,
            vw: innerWidth, vh: innerHeight,
            bodyNodes: document.querySelectorAll('[class*="dshwv"]').length,
            lockBtn: (() => {
              const b = document.querySelector('.dshwv-lockbtn');
              if (!b) return null;
              const q = b.getBoundingClientRect();
              return { x: Math.round(q.x), y: Math.round(q.y), w: Math.round(q.width), h: Math.round(q.height) };
            })(),
          };
        })()`,
        true
      )
      flog('[probe:' + tag + ']', info)
    } catch (err) {
      flog('[probe:' + tag + '] ERR', err && err.message)
    }
  }
  win.webContents.on('did-finish-load', () => {
    injectMenuRedirect()
    injectLockButton()
    injectPeekButton()
    pushWinStateToWidget()
    pushTap()
    // 聊天映射的气泡层：外部消息都画在这层里
    setTimeout(() => {
      if (!chatWidget) return
      chatWidget
        .inject()
        .then((ok) => {
          if (ok && chatBridge) chatWidget.applyCfg(chatBridge.getConfig().bubble)
        })
        .catch(() => {})
    }, 1400)
    // 挂件要等 dshwInit 把 .dshwv-body 建出来，晚一点再叠 Live2D 层
    setTimeout(() => {
      pushLive2D().catch((err) => flog('[l2d] push 失败', err && err.message))
    }, 1200)
    setTimeout(() => {
      if (flyCtrl) flyCtrl.push().catch(() => {})
    }, 1600)
  })

  win.webContents.once('did-finish-load', () => {
    setTimeout(() => probePage('2.5s'), 2500)
    setTimeout(() => probePage('8s'), 8000)
  })
  if (process.env.WHALE_SHOT) {
    const shotDir = path.join(ROOT, 'debug-shots')
    try {
      fs.mkdirSync(shotDir, { recursive: true })
    } catch (err) {}
    const take = async (tag) => {
      try {
        const img = await win.webContents.capturePage()
        const file = path.join(shotDir, tag + '.png')
        fs.writeFileSync(file, img.toPNG())
        console.log('[whale] 截图 ->', file)
      } catch (err) {
        console.log('[whale] 截图失败:', err && err.message)
      }
    }
    win.webContents.once('did-finish-load', () => {
      setTimeout(() => take('shot-load'), 2500)
      setTimeout(() => take('shot-8s'), 8000)
    })
  }
}

// 渲染层告知：指针是否落在挂件上
// 排版/穿透调试：记录鼠标穿透状态翻转

ipcMain.on('whale:set-ignore', (event, ignore) => {
  if (!win || win.isDestroyed()) return
  // 页面说了算：锁定态下页面也只会为那颗解锁小方框要鼠标，别的一律穿透
  const want = !!ignore
  try {
    win.setIgnoreMouseEvents(want, { forward: true })
  } catch (err) {}
})

// 挂件 / 托盘 / 快捷键都能切锁定
ipcMain.on('whale:set-lock', (event, v) => {
  setWinState({ lock: !!v })
})

ipcMain.on('whale:set-pin', (event, v) => {
  setWinState({ pin: !!v })
})

ipcMain.handle('ctl:win:get', async () => ({ ok: true, win: Object.assign({}, winState) }))
ipcMain.handle('ctl:win:put', async (event, patch) => ({ ok: true, win: setWinState(patch || {}) }))

ipcMain.on('whale:push-bottom', () => pushToBottom())

// ---------------- 三条杠按钮 -> 控制中心 ----------------
// 挂件自带的微缩菜单已废弃：点三条杠直接开控制中心，菜单不再弹出。
const MENU_REDIRECT_JS = `
(() => {
  if (window.__whaleMenuRedirect) return
  window.__whaleMenuRedirect = true

  function shutMenu() {
    try {
      document.querySelectorAll('.dshwv-menu').forEach(function (m) {
        m.classList.remove('dshwv-menu-open')
      })
      document.querySelectorAll('.dshwv-menu-btn').forEach(function (b) {
        b.classList.remove('dshwv-menu-btn-visible')
      })
    } catch (err) {}
  }

  var lastAt = 0
  function handler(e) {
    var el = e.target
    if (!el || !el.closest) return
    if (!el.closest('.dshwv-menu-btn')) return
    e.preventDefault()
    e.stopPropagation()
    e.stopImmediatePropagation()
    var now = Date.now()
    if (now - lastAt < 350) return
    lastAt = now
    shutMenu()
    try {
      if (window.whaleShell && window.whaleShell.openControl) window.whaleShell.openControl()
    } catch (err) {}
  }

  ['pointerdown', 'mousedown', 'click'].forEach(function (t) {
    document.addEventListener(t, handler, true)
  })
  // 保险：万一有残留的开启态，加载后先收拾干净
  setTimeout(shutMenu, 800)
})()
`

function injectMenuRedirect() {
  if (!win || win.isDestroyed()) return
  win.webContents.executeJavaScript(MENU_REDIRECT_JS, true).catch(() => {})
}

// ---------------- 挂件上的「锁定」小方框 ----------------
function injectLockButton() {
  if (!win || win.isDestroyed()) return
  let src = ''
  try {
    src = fs.readFileSync(path.join(ROOT, 'lock-widget.js'), 'utf8')
  } catch (err) {
    flog('[lock] 注入脚本读取失败:', err && err.message)
    return
  }
  win.webContents
    .executeJavaScript(';(' + src + ')', true)
    .then((r) => {
      if (r !== 'ready' && r !== 'exists') flog('[lock] 注入没有生效:', r)
    })
    .catch((err) => flog('[lock] 注入失败', err && err.message))
}

// ---------------- 挂件上的「窥屏」眼睛 ----------------
function injectPeekButton() {
  if (!win || win.isDestroyed()) return
  let src = ''
  try {
    src = fs.readFileSync(path.join(ROOT, 'peek-widget.js'), 'utf8')
  } catch (err) {
    flog('[peek] 注入脚本读取失败:', err && err.message)
    return
  }
  win.webContents
    .executeJavaScript(';(' + src + ')', true)
    .then((r) => {
      flog('[peek] 注入结果:', r)
      if (r !== 'ready' && r !== 'exists') flog('[peek] 注入没有生效:', r)
      pushPeekState()
    })
    .catch((err) => flog('[peek] 注入失败', err && err.message))
}

function pushPeekState() {
  if (!win || win.isDestroyed()) return
  try {
    win.webContents.send('whale:peek-state', peekCtrl ? peekCtrl.status() : { on: false, live: false })
  } catch (err) {}
}

function openPeekPicker() {
  if (peekWin && !peekWin.isDestroyed()) {
    peekWin.show()
    peekWin.focus()
    return
  }
  peekWin = new BrowserWindow({
    width: 720,
    height: 560,
    minWidth: 560,
    minHeight: 420,
    title: '选择要窥屏的窗口',
    backgroundColor: '#f6f8fd',
    autoHideMenuBar: true,
    alwaysOnTop: true,
    show: false,
    webPreferences: {
      preload: path.join(ROOT, 'peek-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  })
  peekWin.loadFile(path.join(ROOT, 'peek.html'))
  peekWin.once('ready-to-show', () => peekWin.show())
  peekWin.on('closed', () => {
    peekWin = null
  })
  peekWin.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
}

function closePeekPicker() {
  if (peekWin && !peekWin.isDestroyed()) peekWin.close()
  peekWin = null
}

function rememberPeek(patch) {
  const cfg = readConfig()
  writeConfig({ peek: Object.assign({}, cfg.peek || {}, patch) })
}

ipcMain.on('whale:peek-pick', () => openPeekPicker())
ipcMain.on('whale:peek-set', (event, v) => {
  if (!peekCtrl) return
  if (v) {
    openPeekPicker()
    return
  }
  peekCtrl.stop('用户手动关闭')
  rememberPeek({ on: false, sourceId: '', sourceName: '' })
})
ipcMain.handle('whale:peek-state', () => (peekCtrl ? peekCtrl.status() : { on: false, live: false }))
ipcMain.handle('whale-peek:list', async () => {
  if (!peekCtrl) return []
  try {
    return await peekCtrl.listWindows()
  } catch (err) {
    flog('[peek] 列窗口失败:', err && err.message)
    return []
  }
})
ipcMain.on('whale-peek:choose', (event, sel) => {
  const id = sel && sel.id
  const name = (sel && sel.name) || ''
  closePeekPicker()
  if (!peekCtrl || !id) return
  const r = peekCtrl.start(id, name)
  flog('[peek] 选择窗口:', id, name, r && r.ok)
  rememberPeek({ on: true, sourceId: id, sourceName: name })
})
ipcMain.on('whale-peek:cancel', () => closePeekPicker())

ipcMain.on('whale:open-control', (event, tab) => {
  openControl(tab || undefined)
})

// ---------------- 锁定态下那颗能点的「解锁小锁」 ----------------
// 主窗口穿透以后，页面里的按钮自己也点不到了；所以锁定时单独浮一个不穿透的小窗压在上面
const LOCK_CHIP_HTML = `<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;width:100%;height:100%;background:transparent;overflow:hidden;
 -webkit-user-select:none;cursor:pointer;display:flex;align-items:center;justify-content:center}
#c{width:24px;height:24px;border-radius:6px;background:rgba(214,138,32,.95);color:#fff;
 box-shadow:inset 0 0 0 2px rgba(255,255,255,.92),0 2px 6px rgba(0,0,0,.3);
 display:flex;align-items:center;justify-content:center;transition:transform .12s ease,background .12s ease}
body:hover #c{background:#e79a2c;transform:scale(1.08)}
svg{width:15px;height:15px;display:block}
</style></head><body><div id="c">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
<rect x="5" y="11" width="14" height="9" rx="2" fill="currentColor" fill-opacity=".28"/>
<path d="M8.5 11V7.6a3.5 3.5 0 0 1 7 0V11"/></svg>
</div></body></html>`

let lockChip = null
let lockRect = null // 挂件里那颗小方框的页面坐标（css px）

function ensureLockChip() {
  if (lockChip && !lockChip.isDestroyed()) return lockChip
  lockChip = new BrowserWindow({
    width: 32,
    height: 32,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    hasShadow: false,
    focusable: false,
    alwaysOnTop: true,
    show: false,
    webPreferences: {
      preload: path.join(ROOT, 'lock-chip-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
    },
  })
  try {
    lockChip.setAlwaysOnTop(true, 'screen-saver')
  } catch (err) {}
  lockChip.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(LOCK_CHIP_HTML))
  lockChip.on('closed', () => {
    lockChip = null
  })
  return lockChip
}

function placeLockChip() {
  if (!lockChip || lockChip.isDestroyed()) return
  if (!win || win.isDestroyed() || !lockRect) return
  const b = win.getBounds()
  const pad = 3
  try {
    lockChip.setBounds({
      x: Math.round(b.x + lockRect.x - pad),
      y: Math.round(b.y + lockRect.y - pad),
      width: Math.round(lockRect.w + pad * 2),
      height: Math.round(lockRect.h + pad * 2),
    })
  } catch (err) {}
}

function syncLockChip() {
  try {
    if (!winState.lock) {
      if (lockChip && !lockChip.isDestroyed() && lockChip.isVisible()) lockChip.hide()
      return
    }
    if (!lockRect) return // 还不知道小方框在哪儿，等挂件报上来再浮出来
    const c = ensureLockChip()
    placeLockChip()
    if (!c.isVisible()) {
      c.showInactive()
      flog('[lock] 解锁小锁已浮出', JSON.stringify(lockRect))
    }
    c.setAlwaysOnTop(true, 'screen-saver')
  } catch (err) {
    flog('[lock] 小锁出错:', err && (err.stack || err.message))
  }
}

// 挂件把「小方框在页面里的位置」报上来（吸附、翻转、缩放后都会变）
ipcMain.on('whale:lockbtn-rect', (event, r) => {
  if (!r || !(r.w > 0) || !(r.h > 0)) return
  lockRect = { x: r.x, y: r.y, w: r.w, h: r.h }
  flog('[lock] 收到小方框位置', JSON.stringify(lockRect), 'lock=' + winState.lock)
  if (winState.lock) syncLockChip()
})

// 点小锁 = 解锁
ipcMain.on('whale:lock-chip-click', () => {
  if (!winState.lock) return
  flog('[lock] 点小锁解锁')
  setWinState({ lock: false })
})

// 气泡里的长按：变回余额显示，看完自动收起
ipcMain.on('whale:chat-event', (event, kind) => {
  if (kind !== 'longpress') return
  try {
    if (host && host.ctx && typeof host.ctx.emit === 'function') host.ctx.emit('whale:refresh-balance')
  } catch (err) {}
  setTimeout(() => {
    if (chatWidget) chatWidget.clear().catch(() => {})
  }, 7000)
})

ipcMain.on('whale:resize-for', (event, rect) => {
  // 预留：气泡区域需要时精确调整窗口。目前用全屏窗口，先不启用
})

// ---------------- 账号与余额设置窗口 ----------------
function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) {
    settingsWin.show()
    settingsWin.focus()
    return
  }
  settingsWin = new BrowserWindow({
    width: 460,
    height: 640,
    resizable: true,
    minimizable: true,
    maximizable: false,
    fullscreenable: false,
    title: '小鲸鱼 · 账号与余额',
    backgroundColor: '#f7f9ff',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(ROOT, 'settings-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  })
  settingsWin.loadFile(path.join(ROOT, 'settings.html'))
  settingsWin.once('ready-to-show', () => settingsWin.show())
  settingsWin.on('closed', () => {
    settingsWin = null
  })
  settingsWin.webContents.setWindowOpenHandler(({ url: target }) => {
    try {
      shell.openExternal(target)
    } catch (err) {}
    return { action: 'deny' }
  })
}

async function readAccountForUi({ force = false } = {}) {
  const status = accountService ? accountService.status() : { signedIn: false, source: null }
  let balance = null
  if (accountService && status.signedIn) {
    if (force && typeof accountService.invalidate === 'function') accountService.invalidate()
    try {
      const b = await accountService.getBalance({ version: '0.2.1-rc.2' })
      if (b && b.status === 'ready') {
        balance = { value: b.value || [], bonus: b.bonusWallets || [], costs: b.totalCosts || [] }
      } else {
        balance = { error: '平台没有返回余额数据' }
      }
    } catch (err) {
      balance = { error: String((err && err.message) || err) }
    }
  } else if (status.expired) {
    balance = { error: '登录态已失效，请重新填写凭据' }
  }
  return { status, balance }
}

ipcMain.handle('whale-settings:status', async () => readAccountForUi())
ipcMain.handle('whale-settings:refresh', async () => {
  const r = await readAccountForUi({ force: true })
  try {
    if (host && host.ctx) host.ctx.emit && host.ctx.emit('whale:refresh-balance')
  } catch (err) {}
  return r
})
ipcMain.handle('whale-settings:save-token', async (event, token) => {
  if (!accountService) return { ok: false, error: '余额模块未加载' }
  const value = String(token || '').trim()
  if (!value) return { ok: false, error: '凭据为空' }
  try {
    accountService.setManualToken(value)
    const b = await accountService.getBalance({ version: '0.2.1-rc.2' })
    if (b && b.status === 'ready') return { ok: true }
    return { ok: false, error: '凭据保存了，但平台没返回余额' }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})
ipcMain.handle('whale-settings:clear-token', async () => {
  if (!accountService) return { ok: false, error: '余额模块未加载' }
  try {
    accountService.setManualToken('')
    accountService.invalidate && accountService.invalidate()
    return { ok: true }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

// ---------------- 开机自启动 ----------------
function configFile() {
  try {
    return path.join(app.getPath('userData'), 'whale-config.json')
  } catch (err) {
    return path.join(ROOT, 'whale-config.json')
  }
}
function readConfig() {
  try {
    const raw = fs.readFileSync(configFile(), 'utf8')
    return JSON.parse(raw) || {}
  } catch (err) {
    return {}
  }
}
function writeConfig(patch) {
  const next = Object.assign(readConfig(), patch)
  try {
    fs.mkdirSync(path.dirname(configFile()), { recursive: true })
    fs.writeFileSync(configFile(), JSON.stringify(next, null, 2))
  } catch (err) {
    console.warn('[whale] 写配置失败:', err && err.message)
  }
  return next
}
// ---------------- 语音（把气泡念出来 · <CHAR_NAME>音色） ----------------
const TTS_ENDPOINT = 'http://127.0.0.1:32172'

function voiceCfg() {
  const c = readConfig().voice || {}
  const num = (v, def, min, max) => {
    const n = Number(v)
    if (!Number.isFinite(n)) return def
    return Math.max(min, Math.min(max, n))
  }
  return {
    on: c.on !== false,
    volume: num(c.volume, 0.85, 0, 1),
    speed: num(c.speed, 1, 0.5, 2),
    chat: c.chat !== false,
    peek: c.peek !== false,
    talk: c.talk !== false,
    maxChars: num(c.maxChars, 160, 20, 600),
  }
}

// 气泡里那些符号念出来会很怪，先洗干净
function cleanSpeech(text, maxChars) {
  let s = String(text == null ? '' : text)
  s = s.replace(/```[\s\S]*?```/g, ' ')
  s = s.replace(/`([^`]*)`/g, '$1')
  s = s.replace(/!?\[([^\]]*)\]\([^)]*\)/g, '$1')
  s = s.replace(/https?:\/\/\S+/g, ' ')
  s = s.replace(/[*_~#>|]/g, '')
  s = s.replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{2190}-\u{21FF}]/gu, '')
  s = s.replace(/\s+/g, ' ').trim()
  const lim = Number(maxChars) > 0 ? Number(maxChars) : 160
  if (s.length > lim) {
    const cut = s.slice(0, lim)
    const m = Math.max(cut.lastIndexOf('。'), cut.lastIndexOf('！'), cut.lastIndexOf('？'), cut.lastIndexOf('…'))
    s = m > 12 ? cut.slice(0, m + 1) : cut
  }
  return s.trim()
}

const speakQueue = []
let speakBusy = false
let speakWarned = false

// ---------------- 语音聊天（按住热键说话） ----------------
// voice-chat.py 录完音、识别、问完模型，把要说的交给这里：弹气泡 + 按 talk 优先级播报。
// 说话期间窥屏一律闭嘴，压下来的那条等说完再补，绝不插嘴。
const TALK_PORT = Number(process.env.WHALE_UI_PORT || 32174)
let talkBusyUntil = 0
let pendingPeek = null
let peekFlushTimer = null

function schedulePeekFlush() {
  if (peekFlushTimer) clearTimeout(peekFlushTimer)
  const wait = Math.max(0, talkBusyUntil - Date.now()) + 1500
  peekFlushTimer = setTimeout(() => {
    peekFlushTimer = null
    if (!pendingPeek) return
    if (Date.now() < talkBusyUntil) return schedulePeekFlush()
    const msg = pendingPeek
    pendingPeek = null
    flog('[peek] 语音聊完了，补上压着的那句')
    try {
      speakPeekNow(msg)
    } catch (err) {}
  }, wait)
}

function talkHold(ms) {
  const n = Math.max(0, Number(ms) || 0)
  const until = Date.now() + n
  if (until > talkBusyUntil) talkBusyUntil = until
  if (pendingPeek) schedulePeekFlush()
}

function speakPeekNow(msg) {
  const bubble = (readConfig().chat || {}).bubble || {}
  if (!chatWidget) {
    flog('[peek] 没有聊天挂件，气泡发不出去')
    return
  }
  const m2 = Object.assign({}, msg, {
    duration: Math.max(Number(msg.duration) > 0 ? Number(msg.duration) : 20000, estimateBubbleMs(msg && msg.text)),
  })
  flog('[peek] 出气泡：' + String(m2.text || '').slice(0, 30))
  enqueueSpeech(m2.text, 'peek')
  return chatWidget.say(m2, bubble)
}

function startTalkServer() {
  const srv = http.createServer((req, res) => {
    const send = (code, obj) => {
      const body = JSON.stringify(obj)
      res.writeHead(code, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'Access-Control-Allow-Origin': '*',
      })
      res.end(body)
    }
    if (req.method === 'GET') return send(200, { ok: true, talking: Date.now() < talkBusyUntil })
    let raw = ''
    req.on('data', (c) => {
      raw += c
      if (raw.length > 1e6) req.destroy()
    })
    req.on('end', () => {
      let body = {}
      try {
        body = JSON.parse(raw || '{}')
      } catch (err) {}
      const url = String(req.url || '')
      if (url.startsWith('/talk/state')) {
        const st = String(body.state || 'idle')
        if (st === 'listening') talkHold(body.holdMs || 20000)
        else if (st === 'thinking') talkHold(body.holdMs || 25000)
        else talkHold(1200)
        return send(200, { ok: true, until: talkBusyUntil })
      }
      if (url.startsWith('/talk/snapshot')) {
        // 不额外截屏：窥屏本来就一直在抓，直接借它最近那一张
        const peekCfg = readConfig().peek || {}
        if (!peekCfg.on) return send(200, { ok: false, reason: 'peek-off' })
        try {
          const shots = peekCtrl && typeof peekCtrl.recent === 'function' ? peekCtrl.recent(1) : []
          if (!shots.length) return send(200, { ok: false, reason: 'peek-idle' })
          const last = shots[shots.length - 1]
          flog('[talk] 借窥屏刚抓的那张给语音聊天')
          return send(200, { ok: true, dataUrl: last.dataUrl, at: last.at })
        } catch (err) {
          return send(200, { ok: false, error: String((err && err.message) || err) })
        }
      }
      if (url.startsWith('/talk/hint')) {
        // 按键反馈用：只在桌宠上闪一下气泡，不进语音队列、不念出来
        const text = String(body.text || '').trim()
        const ms = Math.max(200, Number(body.ms) || 1200)
        if (chatWidget && text) {
          const bubble = (readConfig().chat || {}).bubble || {}
          chatWidget
            .say(Object.assign({}, { text, from: '', duration: ms }), bubble)
            .catch(() => {})
        }
        return send(200, { ok: true })
      }
      if (url.startsWith('/talk/say')) {
        const text = String(body.text || '').trim()
        if (!text) return send(400, { ok: false, error: '没有 text' })
        talkHold(Number(body.wavMs) || 6000)
        const bubble = (readConfig().chat || {}).bubble || {}
        enqueueSpeech(text, 'talk')
        if (chatWidget) {
          const shown = Object.assign({}, { text, from: '' }, { duration: estimateBubbleMs(text) })
          chatWidget.say(shown, bubble).catch(() => {})
        }
        flog('[talk] 回答：' + text.slice(0, 30))
        return send(200, { ok: true })
      }
      send(404, { ok: false })
    })
  })
  srv.on('error', (err) => flog('[talk] 语音聊天端点没起来: ' + (err && err.message)))
  srv.listen(TALK_PORT, '127.0.0.1', () => flog('[talk] 语音聊天端点: http://127.0.0.1:' + TALK_PORT))
  return srv
}

// 估一下这句话念完大概要多久，气泡就停多久（不然字还没念完气泡先没了）
function estimateBubbleMs(text) {
  const cfg = voiceCfg()
  const n = cleanSpeech(text, 400).length
  if (!n) return 8000
  const sec = n / (4.2 * (cfg.speed || 1)) + 2.5
  return Math.round(Math.min(40000, Math.max(8000, sec * 1000)))
}

function enqueueSpeech(text, scene) {
  const cfg = voiceCfg()
  const say = cleanSpeech(text, cfg.maxChars)
  flog('[voice] 入队 scene=' + scene + ' on=' + cfg.on + ' chat=' + cfg.chat + ' peek=' + cfg.peek + ' len=' + say.length)
  if (!cfg.on) return
  if (scene === 'peek' && !cfg.peek) return
  if (scene === 'chat' && !cfg.chat) return
  if (scene === 'talk' && !cfg.talk) return
  if (!say) return
  if (speakQueue.length >= 3) speakQueue.shift() // 堆太多就丢旧的，别落后太久
  speakQueue.push({ say, scene: scene || 'chat' })
  pumpSpeech()
}

async function pumpSpeech() {
  if (speakBusy) return
  speakBusy = true
  try {
    while (speakQueue.length) {
      const item = speakQueue.shift()
      const say = typeof item === 'string' ? item : item.say
      const scene = (item && item.scene) || 'chat'
      const cfg = voiceCfg()
      try {
        const r = await fetch(TTS_ENDPOINT + '/speak', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: say, volume: cfg.volume, speed: cfg.speed, wait: true, source: scene }),
        })
        const j = await r.json().catch(() => null)
        if (!r.ok) flog('[voice] 播放失败: ' + JSON.stringify(j))
      } catch (err) {
        if (!speakWarned) {
          speakWarned = true
          flog('[voice] 语音服务没连上(32172)，先只显示气泡: ' + (err && err.message))
        }
      }
    }
  } finally {
    speakBusy = false
  }
}

function stopSpeech() {
  speakQueue.length = 0
  try {
    fetch(TTS_ENDPOINT + '/stop', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
  } catch (err) {}
}

ipcMain.handle('ctl:voice:get', async () => voiceCfg())
ipcMain.handle('ctl:voice:put', async (event, patch) => {
  const cur = readConfig().voice || {}
  writeConfig({ voice: Object.assign({}, cur, patch || {}) })
  if (patch && patch.on === false) stopSpeech()
  return { ok: true, voice: voiceCfg() }
})
ipcMain.handle('ctl:voice:test', async (event, text) => {
  const cfg = voiceCfg()
  const say = cleanSpeech(text || '我能说话了，听得见吗？', cfg.maxChars)
  if (!say) return { ok: false, error: '没有可念的内容' }
  stopSpeech()
  try {
    const r = await fetch(TTS_ENDPOINT + '/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: say, volume: cfg.volume, speed: cfg.speed, wait: true }),
    })
    const j = await r.json().catch(() => null)
    return r.ok ? { ok: true, data: j } : { ok: false, error: JSON.stringify(j) }
  } catch (err) {
    return { ok: false, error: '语音服务未启动：' + String((err && err.message) || err) }
  }
})

function autostartEnabled() {
  return readConfig().autostart !== false // 默认开启
}
function applyAutostart(flag) {
  if (process.platform !== 'win32') return
  if (!app.isPackaged) return // 开发模式别把 electron.exe 塞进注册表
  try {
    app.setLoginItemSettings({ openAtLogin: !!flag, path: process.execPath, args: [] })
  } catch (err) {
    console.warn('[whale] 设置开机自启动失败:', err && err.message)
  }
}
ipcMain.handle('whale-settings:get-autostart', async () => ({
  enabled: autostartEnabled(),
  packaged: app.isPackaged,
}))
ipcMain.handle('whale-settings:set-autostart', async (event, flag) => {
  writeConfig({ autostart: !!flag })
  applyAutostart(!!flag)
  return { ok: true, enabled: !!flag }
})

// ---------------- 控制中心（取代原来的微缩菜单） ----------------
let controlWin = null

function hostBase() {
  return host ? 'http://127.0.0.1:' + host.port : ''
}

function widgetEval(script) {
  if (!win || win.isDestroyed()) return Promise.resolve(null)
  return win.webContents.executeJavaScript(script, true).catch(() => null)
}

// 让挂件重读 size.json（挂件用的是「可见性变化 / 打开菜单时」补读，带 2 秒去抖）
function nudgeWidgetResync() {
  const fire = () => widgetEval("document.dispatchEvent(new Event('visibilitychange')); true")
  setTimeout(fire, 60)
  setTimeout(fire, 2400)
}

function openControl(tab) {
  if (controlWin && !controlWin.isDestroyed()) {
    controlWin.show()
    controlWin.focus()
    if (tab) controlWin.webContents.send('ctl:tab', tab)
    return
  }
  controlWin = new BrowserWindow({
    width: 1000,
    height: 680,
    minWidth: 860,
    minHeight: 560,
    title: '鲸鱼娘 · 控制中心',
    backgroundColor: '#f4f7fd',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(ROOT, 'control-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  })
  const base = hostBase()
  if (base) controlWin.loadURL(base + '/control.html')
  else controlWin.loadFile(path.join(ROOT, 'control.html'))
  controlWin.once('ready-to-show', () => controlWin.show())
  controlWin.on('closed', () => {
    controlWin = null
  })
  controlWin.webContents.setWindowOpenHandler(({ url: target }) => {
    try {
      shell.openExternal(target)
    } catch (err) {}
    return { action: 'deny' }
  })
  controlWin.webContents.on('console-message', (e, level, message, line, sourceId) => {
    flog('[ctl:' + level + ']', message, sourceId ? '(' + path.basename(String(sourceId)) + ':' + line + ')' : '')
  })
}

// —— 通用 HTTP 代理：控制中心直接操作宿主上的 /dsh-whale/* 路由 ——
ipcMain.handle('ctl:req', async (event, opts) => {
  const base = hostBase()
  if (!base) return { ok: false, status: 0, json: { ok: false, error: '宿主未就绪' } }
  const method = String((opts && opts.method) || 'GET').toUpperCase()
  const p = String((opts && opts.path) || '/')
  const body = opts && opts.body != null ? JSON.stringify(opts.body) : undefined
  try {
    const r = await fetch(base + p, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body,
    })
    const text = await r.text()
    let json = null
    try {
      json = JSON.parse(text)
    } catch (err) {}
    return { ok: r.ok, status: r.status, json, text: json ? null : text }
  } catch (err) {
    return { ok: false, status: 0, json: { ok: false, error: String((err && err.message) || err) } }
  }
})

ipcMain.handle('ctl:size:get', async () => {
  const base = hostBase()
  if (!base) return {}
  try {
    return await (await fetch(base + '/dsh-whale/size.json', { cache: 'no-store' })).json()
  } catch (err) {
    return {}
  }
})

ipcMain.handle('ctl:size:put', async (event, patch) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  try {
    const cur = await (await fetch(base + '/dsh-whale/size.json', { cache: 'no-store' })).json()
    const next = Object.assign({}, cur, patch || {})
    const r = await fetch(base + '/dsh-whale/size.json', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(next),
    })
    const j = await r.json().catch(() => null)
    if (r.ok) nudgeWidgetResync()
    return { ok: r.ok, size: next, error: j && j.error }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:snap:get', async () => {
  const raw = await widgetEval(
    "(() => { try { return localStorage.getItem('dshw-snap') || '' } catch (e) { return '' } })()"
  )
  try {
    return raw ? JSON.parse(String(raw)) : null
  } catch (err) {
    return null
  }
})

ipcMain.handle('ctl:snap:put', async (event, cfg) => {
  if (!win || win.isDestroyed()) return { ok: false, error: '挂件窗口未就绪' }
  try {
    const payload = JSON.stringify(JSON.stringify(cfg || {}))
    await widgetEval("(() => { try { localStorage.setItem('dshw-snap', " + payload + "); return true } catch (e) { return false } })()")
    setTimeout(() => {
      if (win && !win.isDestroyed()) win.reload()
    }, 220)
    return { ok: true }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

// —— 额度与报警（桌面版扩展，存在自己的配置文件里） ——
function budgetFile() {
  try {
    return path.join(app.getPath('userData'), 'whale-budget.json')
  } catch (err) {
    return path.join(ROOT, 'whale-budget.json')
  }
}
function readBudget() {
  try {
    return JSON.parse(fs.readFileSync(budgetFile(), 'utf8')) || {}
  } catch (err) {
    return {}
  }
}
function writeBudget(patch) {
  const next = Object.assign({}, readBudget(), patch || {})
  try {
    fs.mkdirSync(path.dirname(budgetFile()), { recursive: true })
    fs.writeFileSync(budgetFile(), JSON.stringify(next, null, 2), 'utf8')
  } catch (err) {}
  return next
}
ipcMain.handle('ctl:budget:get', async () => readBudget())
ipcMain.handle('ctl:budget:put', async (event, patch) => ({ ok: true, budget: writeBudget(patch) }))

// —— 各平台每日用量快照（给「使用图表」切换其他平台用） ——
// 宿主（挂件 bundle）只给每个模型「当前余额 + 今日已用」，没有每日历史；
// 这里每 5 分钟采一次，把当天 todayUsage 按天累积成历史，控制中心才能画柱状图。
function apiUsageFile() {
  try {
    return path.join(app.getPath('userData'), 'api-usage-daily.json')
  } catch (err) {
    return path.join(ROOT, 'api-usage-daily.json')
  }
}
function readApiUsage() {
  try {
    const d = JSON.parse(fs.readFileSync(apiUsageFile(), 'utf8'))
    if (d && typeof d === 'object' && d.models) return d
    return { version: 1, models: {} }
  } catch (err) {
    return { version: 1, models: {} }
  }
}
function writeApiUsage(next) {
  try {
    fs.mkdirSync(path.dirname(apiUsageFile()), { recursive: true })
    fs.writeFileSync(apiUsageFile(), JSON.stringify(next, null, 2), 'utf8')
  } catch (err) {}
  return next
}
function dayKeyLocal(t) {
  const d = t || new Date()
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')
}
let apiUsageBusy = false
async function sampleApiUsage() {
  const base = hostBase()
  if (!base || apiUsageBusy) return null
  apiUsageBusy = true
  try {
    const ctl = new AbortController()
    const timer = setTimeout(() => ctl.abort(), 9000)
    const r = await fetch(base + '/dsh-whale/api-models.json', { cache: 'no-store', signal: ctl.signal })
    clearTimeout(timer)
    const data = await r.json()
    const models = (data && Array.isArray(data.models)) ? data.models : []
    const db = readApiUsage()
    db.version = 1
    db.models = db.models || {}
    const now = new Date()
    const today = dayKeyLocal(now)
    const tooOld = dayKeyLocal(new Date(now.getTime() - 130 * 86400000))
    for (const m of models) {
      if (!m || !m.id) continue
      const cur = String(m.currency || 'CNY').toUpperCase()
      const entry = db.models[m.id] || { name: m.name || m.id, currency: cur, days: {} }
      entry.name = m.name || entry.name || m.id
      entry.currency = cur
      entry.builtin = !!m.builtin
      entry.updatedAt = now.getTime()
      if (!entry.days || typeof entry.days !== 'object') entry.days = {}
      // todayUsage 是宿主算出来的「当天累计」（余额观测差 or 会话事件估算），取当天最大值当历史
      const usage = Number(m.todayUsage)
      const amt = Number.isFinite(usage) && usage > 0 ? usage : 0
      const prev = entry.days[today] ? Number(entry.days[today].amount) || 0 : 0
      entry.days[today] = {
        amount: Math.max(prev, amt),
        currency: String(m.todayUsageCurrency || cur).toUpperCase(),
        source: m.usageSource || (m.balanceMode === 'events' ? 'events' : ''),
        observedAt: now.getTime(),
      }
      for (const k of Object.keys(entry.days)) {
        if (String(k) < tooOld) delete entry.days[k]
      }
      db.models[m.id] = entry
    }
    db.sampledAt = now.getTime()
    return writeApiUsage(db)
  } catch (err) {
    return null
  } finally {
    apiUsageBusy = false
  }
}
ipcMain.handle('ctl:api-usage:get', async () => {
  // 打开图表时顺手采一次，保证「今天」这根柱是最新的
  await sampleApiUsage()
  return readApiUsage()
})
setTimeout(() => { sampleApiUsage().catch(() => {}) }, 20000)
setInterval(() => { sampleApiUsage().catch(() => {}) }, 5 * 60 * 1000)

// ---------------- 点击动效（挂件的按压形变幅度 / 速度） ----------------
// 幅度写进挂件的 window.__whaleTap（vendor 已打 [click-tap-patch] 钩子），
// 速度只是 .dshwv-body 的 transition-duration —— 用 CSS 变量注入，不碰 bundle。
function numOr(v, d, min, max) {
  const n = Number(v)
  if (!isFinite(n)) return d
  return Math.max(min, Math.min(max, n))
}

function tapCfg() {
  const c = readConfig().tap || {}
  return {
    on: c.on !== false,
    amp: numOr(c.amp, 0.12, 0, 0.35),
    dur: numOr(c.dur, 0.22, 0.05, 0.9),
  }
}

function pushTap() {
  const c = tapCfg()
  const js =
    '(() => { try {' +
    ' window.__whaleTap = { on: ' + (c.on ? 'true' : 'false') + ', amp: ' + c.amp + ' };' +
    " document.documentElement.style.setProperty('--whale-tap-dur', '" + c.dur + "s');" +
    " if (!document.getElementById('whale-tap-style')) {" +
    "  var st = document.createElement('style'); st.id = 'whale-tap-style';" +
    "  st.textContent = '.dshwv-body{transition:transform var(--whale-tap-dur,.22s) cubic-bezier(.34,1.56,.64,1)}';" +
    '  document.head.appendChild(st);' +
    ' }' +
    ' return true } catch (e) { return false } })()'
  return widgetEval(js)
}

ipcMain.handle('ctl:tap:get', async () => tapCfg())
ipcMain.handle('ctl:tap:put', async (event, patch) => {
  const next = Object.assign({}, tapCfg(), patch || {})
  writeConfig({
    tap: {
      on: next.on !== false,
      amp: numOr(next.amp, 0.12, 0, 0.35),
      dur: numOr(next.dur, 0.22, 0.05, 0.9),
    },
  })
  const cfg = tapCfg()
  await pushTap()
  return { ok: true, tap: cfg }
})

// ---------------- Live2D 形象 ----------------
// 模型放在用户数据目录（不随程序分发），每个模型一个文件夹，里面有 .model3.json。
// 挂件里用 /whale-lib/layer.js 加载 pixi + cubism4 + core，画在一层 canvas 上；
// 原来的 <img> 只是变透明 —— 命中测试和拖拽都挂在它身上，不能摘。
function live2dRoot() {
  let dir
  try {
    dir = path.join(app.getPath('userData'), 'live2d-models')
  } catch (err) {
    dir = path.join(ROOT, 'live2d-models')
  }
  try {
    fs.mkdirSync(dir, { recursive: true })
  } catch (err) {}
  return dir
}

function findModelFiles(dir, depth) {
  const out = []
  if (depth > 3) return out
  let items = []
  try {
    items = fs.readdirSync(dir)
  } catch (err) {
    return out
  }
  for (const name of items) {
    const p = path.join(dir, name)
    let st = null
    try {
      st = fs.statSync(p)
    } catch (err) {
      continue
    }
    if (st.isDirectory()) out.push(...findModelFiles(p, depth + 1))
    else if (/\.model3\.json$/i.test(name)) out.push(p)
  }
  return out
}

function listLive2DModels() {
  const root = live2dRoot()
  const out = []
  let dirs = []
  try {
    dirs = fs.readdirSync(root)
  } catch (err) {
    return out
  }
  for (const id of dirs) {
    const dir = path.join(root, id)
    try {
      if (!fs.statSync(dir).isDirectory()) continue
    } catch (err) {
      continue
    }
    const files = findModelFiles(dir, 0)
    if (!files.length) continue
    // 优先取最浅的那个（多数模型就是 <id>/xxx.model3.json）
    files.sort((a, b) => a.split(path.sep).length - b.split(path.sep).length)
    const modelFile = files[0]
    const rel = path.relative(dir, modelFile).split(path.sep).join('/')
    let groups = []
    let expressions = []
    let cubism = 4
    try {
      const j = JSON.parse(fs.readFileSync(modelFile, 'utf8'))
      const fr = (j && j.FileReferences) || {}
      groups = Object.keys(fr.Motions || {})
      expressions = (fr.Expressions || []).map((x) => (x && x.Name) || '').filter(Boolean)
      if (j && j.Version && Number(j.Version) < 3) cubism = 2
    } catch (err) {}
    out.push({
      id,
      name: id,
      file: rel,
      url: '/whale-l2d/' + encodeURIComponent(id) + '/' + rel.split('/').map(encodeURIComponent).join('/'),
      groups,
      expressions,
      cubism,
    })
  }
  out.sort((a, b) => a.id.localeCompare(b.id))
  return out
}

function live2dCfg() {
  const c = readConfig().live2d || {}
  return {
    on: c.on === true,
    id: typeof c.id === 'string' ? c.id : '',
    scale: numOr(c.scale, 1, 0.3, 3),
    offsetX: numOr(c.offsetX, 0, -1, 1),
    offsetY: numOr(c.offsetY, 0, -1, 1),
    follow: c.follow !== false,
    blink: c.blink !== false,
    idleGroup: typeof c.idleGroup === 'string' ? c.idleGroup : 'Idle',
    // '' / '*' = 在除待机组以外的所有动作组里随机（多数模型每组只有 1 个动作）
    // 'none'   = 不播；'A,B' = 指定多组
    clickGroup: typeof c.clickGroup === 'string' ? c.clickGroup : '*',
    clickExpr: c.clickExpr === true,
    speed: numOr(c.speed, 1, 0.2, 2.5),
  }
}

async function pushLive2D() {
  if (!win || win.isDestroyed()) return { ok: false, error: '挂件窗口未就绪' }
  const cfg = live2dCfg()
  if (!cfg.on) {
    await widgetEval('(() => { try { if (window.__whaleL2D) window.__whaleL2D.stop() } catch (e) {} return true })()')
    return { ok: true, running: false }
  }
  const models = listLive2DModels()
  const model = models.find((m) => m.id === cfg.id) || models[0]
  if (!model) return { ok: false, error: '还没有导入任何 Live2D 模型' }

  const loaded = await widgetEval(
    'new Promise((res) => { if (window.__whaleL2D) return res(true);' +
      " var s = document.createElement('script'); s.src = '/whale-lib/layer.js';" +
      ' s.onload = function () { res(!!window.__whaleL2D) }; s.onerror = function () { res(false) };' +
      ' document.head.appendChild(s) })'
  )
  if (!loaded) return { ok: false, error: '渲染脚本没加载上' }

  const payload = JSON.stringify(
    Object.assign({}, cfg, {
      url: model.url,
      modelId: model.id,
      idleGroup: cfg.idleGroup || (model.groups.includes('Idle') ? 'Idle' : model.groups[0] || ''),
    })
  )
  const r = await widgetEval('window.__whaleL2D.apply(' + payload + ')')
  flog('[l2d] apply ->', r)
  return r && typeof r === 'object' ? r : { ok: false, error: '渲染层没有返回结果' }
}

ipcMain.handle('ctl:l2d:state', async () => ({
  cfg: live2dCfg(),
  models: listLive2DModels(),
  dir: live2dRoot(),
}))

ipcMain.handle('ctl:l2d:put', async (event, patch) => {
  const next = Object.assign({}, live2dCfg(), patch || {})
  writeConfig({
    live2d: {
      on: next.on === true,
      id: String(next.id || ''),
      scale: numOr(next.scale, 1, 0.3, 3),
      offsetX: numOr(next.offsetX, 0, -1, 1),
      offsetY: numOr(next.offsetY, 0, -1, 1),
      follow: next.follow !== false,
      blink: next.blink !== false,
      idleGroup: String(next.idleGroup || ''),
      clickGroup: String(next.clickGroup == null ? '*' : next.clickGroup),
      clickExpr: next.clickExpr === true,
      speed: numOr(next.speed, 1, 0.2, 2.5),
    },
  })
  const result = await pushLive2D()
  return { ok: true, cfg: live2dCfg(), result }
})

ipcMain.handle('ctl:l2d:import', async () => {
  const dir = await pickFile({
    title: '选择 Live2D 模型文件夹（里面要有 .model3.json）',
    properties: ['openDirectory'],
  })
  if (!dir) return { ok: false, cancelled: true }
  try {
    const files = findModelFiles(dir, 0)
    if (!files.length) return { ok: false, error: '这个文件夹里没找到 .model3.json' }
    const base = path.basename(dir).replace(/[\\/:*?"<>|]/g, '_').slice(0, 24) || 'model'
    const root = live2dRoot()
    let id = base
    let n = 1
    while (fs.existsSync(path.join(root, id))) {
      id = base + '-' + n
      n += 1
    }
    fs.cpSync(dir, path.join(root, id), { recursive: true })
    return { ok: true, id, models: listLive2DModels() }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:l2d:delete', async (event, id) => {
  const name = String(id || '')
  if (!name) return { ok: false, error: '缺少模型 id' }
  const root = live2dRoot()
  const dir = path.join(root, name)
  if (!path.resolve(dir).startsWith(path.resolve(root) + path.sep)) return { ok: false, error: '路径不合法' }
  try {
    fs.rmSync(dir, { recursive: true, force: true })
    const cfg = live2dCfg()
    if (cfg.id === name) writeConfig({ live2d: Object.assign({}, cfg, { id: '', on: false }) })
    await pushLive2D()
    return { ok: true, models: listLive2DModels() }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:l2d:refresh', async () => {
  const r = await pushLive2D()
  return { ok: true, models: listLive2DModels(), result: r }
})

// —— 角色改名 ——
ipcMain.handle('ctl:role-rename', async (event, payload) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  const id = String((payload && payload.id) || '')
  const name = String((payload && payload.name) || '').trim().slice(0, 20)
  if (!id || !name) return { ok: false, error: '参数不完整' }
  try {
    const dir = path.join(host.home, 'whale-roles')
    const file = path.join(dir, 'roles.json')
    const raw = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : { version: 1, roles: [] }
    const role = (raw.roles || []).find((r) => r && r.id === id)
    if (!role) return { ok: false, error: '没找到这个角色' }
    role.name = name
    fs.writeFileSync(file, JSON.stringify(raw, null, 2), 'utf8')
    const list = await (await fetch(base + '/dsh-whale/roles.json', { cache: 'no-store' })).json()
    return { ok: true, roles: list.roles }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

// —— 文件选择 + 导入 ——
function pickFile(options) {
  return new Promise((resolve) => {
    const parent = controlWin && !controlWin.isDestroyed() ? controlWin : win
    const { dialog } = require('electron')
    dialog
      .showOpenDialog(parent, options)
      .then((r) => resolve(r && !r.canceled && r.filePaths && r.filePaths[0] ? r.filePaths[0] : null))
      .catch(() => resolve(null))
  })
}

function sniffRoleFormat(file, buf) {
  const ext = path.extname(file).toLowerCase()
  if (ext === '.gif' || (buf.length > 6 && buf.slice(0, 3).toString() === 'GIF')) return 'gif'
  if (ext === '.apng') return 'apng'
  // PNG 里的 acTL 块 = APNG
  try {
    if (buf.includes(Buffer.from('acTL'))) return 'apng'
  } catch (err) {}
  return 'png'
}

ipcMain.handle('ctl:import-role', async (event, payload) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  const file = await pickFile({
    title: '选择角色图片',
    filters: [{ name: '图片', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'apng'] }],
  })
  if (!file) return { ok: false, cancelled: true }
  try {
    const buf = fs.readFileSync(file)
    if (buf.length > 20 * 1024 * 1024) return { ok: false, error: '图片超过 20MB' }
    const format = sniffRoleFormat(file, buf)
    const ext = path.extname(file).toLowerCase()
    const mime =
      ext === '.gif' || format === 'gif' ? 'image/gif'
        : ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg'
          : ext === '.webp' ? 'image/webp'
            : 'image/png'
    const dataUrl = 'data:' + mime + ';base64,' + buf.toString('base64')
    const name =
      (payload && payload.name ? String(payload.name) : path.basename(file, path.extname(file))).slice(0, 20) || '新角色'

    const body = { name, image: dataUrl }
    if (format === 'gif' || format === 'apng') body.format = format
    const r = await fetch(base + '/dsh-whale/roles.json', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    const j = await r.json().catch(() => null)
    if (!r.ok || !j || j.ok === false) return { ok: false, error: (j && j.error) || '保存失败' }

    // 替换模式：导入成功后删掉旧角色
    if (payload && payload.replaceId && payload.replaceId !== 'default') {
      try {
        await fetch(base + '/dsh-whale/role-delete.json', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: payload.replaceId }),
        })
      } catch (err) {}
    }
    const list = await (await fetch(base + '/dsh-whale/roles.json', { cache: 'no-store' })).json()
    return { ok: true, roles: list.roles, format }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:import-audio', async (event, payload) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  const file = await pickFile({
    title: '选择音频片段',
    filters: [{ name: '音频', extensions: ['wav'] }],
  })
  if (!file) return { ok: false, cancelled: true }
  try {
    const buf = fs.readFileSync(file)
    if (buf.length > 8 * 1024 * 1024) return { ok: false, error: '音频超过 8MB' }
    const dataUrl = 'data:audio/wav;base64,' + buf.toString('base64')
    const name = (payload && payload.name ? String(payload.name) : path.basename(file, path.extname(file))).slice(0, 40) || '未命名音频'
    const r = await fetch(base + '/dsh-whale/audio.json', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'upload-fragment', name, audio: dataUrl }),
    })
    const j = await r.json().catch(() => null)
    if (!r.ok || !j || j.ok === false) return { ok: false, error: (j && j.error) || '保存失败' }
    return { ok: true, audio: j }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.on('ctl:pick-image', () => {})
ipcMain.on('ctl:pick-audio', () => {})

ipcMain.handle('ctl:widget:reload', async () => {
  if (win && !win.isDestroyed()) win.reload()
  return { ok: true }
})

// 控制中心里点选形象 → 真正让挂件切过去。
// 挂件的当前形象只认自己 origin 的 localStorage['dshw-role']，控制窗口改不了别人的
// storage，所以这里在挂件窗口里写一次再 reload，挂件启动时按它渲染。
ipcMain.handle('ctl:role-apply', async (event, id) => {
  const rid = String(id || '').trim()
  if (!rid) return { ok: false, error: 'bad id' }
  if (!win || win.isDestroyed()) return { ok: false, error: 'widget window not ready' }
  try {
    await win.webContents.executeJavaScript(
      "(function(){try{localStorage.setItem('dshw-role'," +
        JSON.stringify(rid) +
        ")}catch(e){}})()",
      true
    )
    win.reload()
    return { ok: true }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:widget:focus', async () => {
  if (!win || win.isDestroyed()) return { ok: false }
  try {
    win.setAlwaysOnTop(true, 'screen-saver')
    win.showInactive()
  } catch (err) {}
  setTimeout(() => applyWinState(), 900)
  return { ok: true }
})

ipcMain.handle('ctl:open-external', async (event, url) => {
  try {
    await shell.openExternal(String(url || ''))
    return { ok: true }
  } catch (err) {
    return { ok: false }
  }
})

ipcMain.handle('ctl:quit', async () => {
  app.isQuitting = true
  app.quit()
  return { ok: true }
})

// ---------------- 聊天映射（外部 agent -> 挂件气泡） ----------------
function mergeDeep(base, patch) {
  const out = Object.assign({}, base)
  for (const k of Object.keys(patch || {})) {
    const v = patch[k]
    if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object') {
      out[k] = mergeDeep(base[k], v)
    } else if (v !== undefined) {
      out[k] = v
    }
  }
  return out
}

ipcMain.handle('ctl:chat:get', async () => {
  let widget = null
  try {
    widget = chatWidget ? await chatWidget.state() : null
  } catch (err) {}
  return {
    ok: true,
    cfg: chatBridge ? chatBridge.getConfig() : readConfig().chat || {},
    status: chatBridge ? chatBridge.status() : { running: false, error: '桥还没启动' },
    history: chatBridge ? chatBridge.history(30) : [],
    widget,
  }
})

ipcMain.handle('ctl:chat:put', async (event, patch) => {
  const cur = readConfig().chat || {}
  writeConfig({ chat: mergeDeep(cur, patch || {}) })
  if (!chatBridge) return { ok: false, error: '桥还没启动' }
  const r = await chatBridge.apply()
  try {
    if (chatWidget) await chatWidget.applyCfg(chatBridge.getConfig().bubble)
  } catch (err) {}
  return Object.assign({ ok: true }, r)
})

// 走完整链路推一条（进历史、走气泡），控制中心「发一条试试」用
ipcMain.handle('ctl:chat:test', async (event, payload) => {
  if (!chatBridge) return { ok: false, error: '桥还没启动' }
  const text = String((payload && payload.text) || '').trim() || '测试一下，这边能收到喔。'
  const from = String((payload && payload.from) || '').trim() || '本地测试'
  const r = chatBridge.push({ text, from, channel: 'control' })
  return Object.assign({ ok: !!r.ok, error: r.error || '' }, r)
})

ipcMain.handle('ctl:chat:clear', async () => {
  if (chatBridge) chatBridge.clear()
  try {
    if (chatWidget) await chatWidget.clear()
  } catch (err) {}
  return { ok: true }
})

// 手动触发一次「反向拉取」
ipcMain.handle('ctl:chat:poll', async () => {
  if (!chatBridge) return { ok: false, error: '桥还没启动' }
  try {
    await chatBridge.pollOnce()
    return { ok: true }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:chat:history', async () => ({
  ok: true,
  items: chatBridge ? chatBridge.history(50) : [],
}))

// —— 额度/余量报警：主进程每 60 秒看一眼，超了就发系统通知（每天每类只响一次） ——
const alertState = { day: '', overDay: false, overMonth: false, low: false }
function notify(title, body, openUrl) {
  try {
    const { Notification } = require('electron')
    if (!Notification.isSupported()) return
    const n = new Notification({ title, body, silent: false })
    if (openUrl) {
      n.on('click', () => {
        try {
          shell.openExternal(openUrl)
        } catch (err) {}
      })
    }
    n.show()
  } catch (err) {}
}
// 报警通知点一下就跳 DeepSeek 官方：余额不足 → 充值页；超预算 → 用量页
const DS_TOPUP_URL = 'https://platform.deepseek.com/top_up'
const DS_USAGE_URL = 'https://platform.deepseek.com/usage'
async function budgetTick() {
  const base = hostBase()
  if (!base) return
  const b = readBudget()
  if (b.warnOn === false && b.overOn === false) return
  try {
    const rec = await (await fetch(base + '/dsh-whale/usage-records.json', { cache: 'no-store' })).json()
    const todayRec = (rec && rec.today) || {}
    const today = Number(todayRec.amount != null ? todayRec.amount : todayRec.total || 0)
    const days = (rec && rec.all && rec.all.days) || []
    const now = new Date()
    const ym = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0')
    let monthSum = 0
    for (const d of days) {
      const ds = String(d.day || d.date || '')
      if (ds.slice(0, 7) === ym) monthSum += Number(d.amount != null ? d.amount : d.total || 0)
    }
    const dayKey = now.toISOString().slice(0, 10)
    if (alertState.day !== dayKey) {
      alertState.day = dayKey
      alertState.overDay = false
      alertState.overMonth = false
      alertState.low = false
    }
    const daily = Number(b.daily || 0)
    const monthly = Number(b.monthly || 0)
    const warnPct = Number(b.warnPercent == null ? 20 : b.warnPercent)

    if (b.overOn !== false && daily > 0 && today > daily && !alertState.overDay) {
      alertState.overDay = true
      notify('今日额度已超', '今天已用 ¥' + today.toFixed(2) + '，超过计划额度 ¥' + daily.toFixed(2), DS_USAGE_URL)
    }
    if (b.overOn !== false && monthly > 0 && monthSum > monthly && !alertState.overMonth) {
      alertState.overMonth = true
      notify('本月额度已超', '本月已用 ¥' + monthSum.toFixed(2) + '，超过额度 ¥' + monthly.toFixed(2), DS_USAGE_URL)
    }
    if (b.warnOn !== false && monthly > 0) {
      const leftPct = ((monthly - monthSum) / monthly) * 100
      if (leftPct <= warnPct && !alertState.low) {
        alertState.low = true
        notify('本月额度快用完了', '剩余 ¥' + Math.max(0, monthly - monthSum).toFixed(2) + '（约 ' + Math.max(0, leftPct).toFixed(0) + '%）', DS_TOPUP_URL)
      }
    }
  } catch (err) {}
}
setInterval(budgetTick, 60000)

// ---------------- 托盘 ----------------
function createTray() {
  let iconPath = path.join(ROOT, 'vendor', 'whale-widget', 'assets', 'DSniang1.png')
  if (!fs.existsSync(iconPath)) iconPath = path.join(ROOT, 'vendor', 'whale-widget', 'icon.png')
  let image = null
  try {
    const { nativeImage } = require('electron')
    image = nativeImage.createFromPath(iconPath).resize({ width: 20, height: 20 })
  } catch (err) {}
  try {
    tray = new Tray(image || undefined)
  } catch (err) {
    tray = null
    return
  }
  refreshTrayMenu()
  tray.setToolTip('小鲸鱼（独立桌面版）')
  tray.on('double-click', () => openControl())
}

function buildTrayMenu() {
  return Menu.buildFromTemplate([
    {
      label: '唤到最前（临时）',
      click: () => {
        if (!win || win.isDestroyed()) return
        win.showInactive()
        try {
          win.setAlwaysOnTop(true, 'screen-saver')
        } catch (err) {}
        setTimeout(() => applyWinState(), 900)
      },
    },
    {
      label: '窗口置顶（一直显示在最上层）',
      type: 'checkbox',
      checked: !!winState.pin,
      click: (item) => setWinState({ pin: !!item.checked }),
    },
    {
      label: '锁定（只留解锁小方框能点）',
      type: 'checkbox',
      checked: !!winState.lock,
      click: (item) => setWinState({ lock: !!item.checked }),
    },
    { label: '重新载入', click: () => win && win.reload() },
    { label: '控制中心…', click: () => openControl() },
    { label: '账号与余额…', click: () => openSettings() },
    {
      label: '开机自启动',
      type: 'checkbox',
      checked: autostartEnabled(),
      click: (item) => {
        writeConfig({ autostart: !!item.checked })
        applyAutostart(!!item.checked)
      },
    },
    { type: 'separator' },
    {
      label: '退出',
      click: () => {
        app.isQuitting = true
        app.quit()
      },
    },
  ])
}

function refreshTrayMenu() {
  if (!tray) return
  try {
    tray.setContextMenu(buildTrayMenu())
  } catch (err) {}
}

// ---------------- 启动 ----------------
async function boot() {
  // 置顶 / 锁定：恢复上次的状态
  winState = readWinState()

  // 自检时临时把聊天映射打开（正常启动不动用户配置，跑完还原）
  let chatCfgPrev = null
  if (process.env.WHALE_CHAT_TEST) {
    chatCfgPrev = readConfig().chat || {}
    if (!chatCfgPrev.on) writeConfig({ chat: Object.assign({}, chatCfgPrev, { on: true }) })
  }
  const shimPath = path.join(ROOT, 'server', 'host-shim.mjs')
  const { startHost } = await import(pathToFileURL(shimPath).href)

  // 余额来源：本机有 DSH 登录态就只读复用；别人拿到软件就在「账号与余额」里填自己的 API Key
  let account = null
  try {
    const webBalancePath = path.join(ROOT, 'server', 'web-balance.mjs')
    if (fs.existsSync(webBalancePath)) {
      const mod = await import(pathToFileURL(webBalancePath).href)
      if (typeof mod.createAccountService === 'function') {
        account = mod.createAccountService({ log: (s) => console.log(s) })
        accountService = account
        const st = account.status()
        console.log(
          '[whale] 余额来源: ' + (st.signedIn ? st.source + ' @ ' + st.origin : '未配置（可在托盘「账号与余额」里填）')
        )
      }
    }
  } catch (err) {
    console.warn('[whale] 网页余额模块未启用:', err && err.message)
  }

  host = await startHost({ port: PORT, account, live2dDir: live2dRoot(), onLog: (s) => console.log(s) })
  console.log('[whale] 宿主就绪:', host.url)

  // 聊天映射：挂件侧的执行器要先建好（createWindow 的 did-finish-load 里就要注入气泡层）
  chatWidget = createChatWidget({ widgetEval, flog })

  createWindow(host.url)

  // 再起接收端：外部 agent（AstrBot / DSH / GPT / Claude / 自建）POST 过来就弹气泡
  try {
    const chatPath = path.join(ROOT, 'server', 'chat-bridge.mjs')
    const { startChatBridge } = await import(pathToFileURL(chatPath).href)
    chatBridge = await startChatBridge({
      getConfig: () => readConfig().chat || {},
      onMessage: (msg) => {
        const bubble = (readConfig().chat || {}).bubble || {}
        enqueueSpeech(msg && msg.text, 'chat')
        // 气泡和语音同步：字多就停久一点
        const shown = Object.assign({}, msg, { duration: estimateBubbleMs(msg && msg.text) })
        chatWidget.say(shown, bubble).catch(() => {})
      },
      onLog: (s) => console.log(s),
    })
  } catch (err) {
    console.warn('[whale] 聊天映射没起来:', err && err.message)
  }

  // 窥屏：只盯用户选中的那一个窗口，抓到的图交给分析端点，回来的话弹气泡
  try {
    const peekPath = path.join(ROOT, 'server', 'peek.mjs')
    const { createPeek } = await import(pathToFileURL(peekPath).href)
    peekCtrl = createPeek({
      desktopCapturer,
      getConfig: () => readConfig().peek || {},
      onSay: (msg) => {
        if (Date.now() < talkBusyUntil) {
          pendingPeek = msg
          flog('[peek] 语音聊天中，先压着不说话')
          schedulePeekFlush()
          return
        }
        return speakPeekNow(msg)
      },
      onState: () => pushPeekState(),
      log: (s) => console.log(s),
    })
    // 上次退出时还在窥屏、并且窗口 id 对得上 → 自动接上
    const peekCfg = readConfig().peek || {}
    if (peekCfg.on && peekCfg.sourceId) {
      const r = peekCtrl.start(peekCfg.sourceId, peekCfg.sourceName)
      flog('[peek] 恢复上次的窥屏:', r && r.ok, peekCfg.sourceName)
    }
  } catch (err) {
    console.warn('[whale] 窥屏模块没起来:', err && err.message)
  }

  try {
    startTalkServer()
  } catch (err) {
    console.warn('[whale] 语音聊天端点没起来:', err && err.message)
  }

  createTray()

  // 锁定之后总得留条后路：Ctrl+Alt+L 随时切回（被占用就换下一个）
  try {
    const { globalShortcut } = require('electron')
    const toggleLock = () => setWinState({ lock: !winState.lock })
    for (const acc of ['Control+Alt+L', 'Control+Shift+Alt+L', 'Control+Alt+K']) {
      let ok = false
      try {
        ok = globalShortcut.register(acc, toggleLock)
      } catch (err) {
        ok = false
      }
      if (ok) {
        lockHotkey = acc
        flog('[lock] 锁定快捷键:', acc)
        break
      }
    }
    if (!lockHotkey) flog('[lock] 锁定快捷键都没注册上，只能用托盘或控制中心解锁')
  } catch (err) {
    flog('[lock] 注册快捷键失败', err && err.message)
  }

  // 闲置自动飞行：1 分钟无输入 -> 飞 10 秒 -> 落回原位 -> 重新计时
  flyCtrl = createFlyController({
    powerMonitor,
    widgetEval,
    flog,
    gifPath: path.join(ROOT, 'fly.gif'),
    test: !!process.env.WHALE_FLY_TEST,
  })
  flyCtrl.start()

  // 调试用：聊天映射全链路（HTTP 推一条 -> 气泡画出来 -> 截图）
  if (process.env.WHALE_CHAT_TEST) {
    setTimeout(async () => {
      const line = (tag, v) => console.log('[chat-test] ' + tag + ' -> ' + (typeof v === 'string' ? v : JSON.stringify(v)))
      try {
        const st = chatBridge ? chatBridge.status() : null
        line('status', st)
        if (!st || !st.running) throw new Error('桥没有监听：' + ((st && st.error) || 'null'))
        const base = st.url
        await new Promise((r) => setTimeout(r, 2200))
        line('注入', await widgetEval('window.__whaleChat ? "ok" : "missing"'))
        line('health', (await fetch(base + '/chat/health')).status)

        const r1 = await fetch(base + '/chat/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: (process.env.WHALE_CHAT_SAY || '<USER_TITLE>，第一次用这个气泡跟你说话——我在这边按一下，你那边就亮起来啦。').slice(0, 300),
            from: process.env.WHALE_CHAT_FROM || '<CHAR_NAME>',
          }),
        })
        line('通用 push', r1.status + ' ' + (await r1.text()))
        await new Promise((r) => setTimeout(r, 1000))
        line('气泡状态', await widgetEval('window.__whaleChat ? window.__whaleChat.state() : "no"'))
        fs.writeFileSync(path.join(ROOT, 'debug-shots', 'chat-bubble.png'), (await win.webContents.capturePage()).toPNG())

        const r2 = await fetch(base + '/chat/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            post_type: 'message',
            message_type: 'private',
            raw_message: '群友格式也能直接吃进来。',
            sender: { nickname: '测试群友' },
            user_id: 123456,
          }),
        })
        line('OneBot 上报体', r2.status + ' ' + (await r2.text()))
        await new Promise((r) => setTimeout(r, 900))
        line('气泡状态2', await widgetEval('window.__whaleChat ? window.__whaleChat.state() : "no"'))
        fs.writeFileSync(path.join(ROOT, 'debug-shots', 'chat-bubble-onebot.png'), (await win.webContents.capturePage()).toPNG())

        line('历史', chatBridge.history(5))
        line('纯文本入参', await (async () => {
          const r3 = await fetch(base + '/chat/push', {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain' },
            body: '纯文本也能推',
          })
          return r3.status + ' ' + (await r3.text())
        })())

        // —— 交互：长文本 -> 点一下放大 -> 再点缩回 -> 长按变回余额 ——
        const longText =
          '这一条是故意写长的，用来试气泡放不下的时候会怎么样。' +
          '字多了气泡当然装不下，所以停的时间要跟着变长一点，最多二十秒。' +
          '如果还想看全，就点一下气泡，它会放大展开；再点一下就缩回去。' +
          '要是长按一秒，它就让位给余额，看完自己收起来。'
        await fetch(base + '/chat/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: longText, from: '<CHAR_NAME>' }),
        })
        await new Promise((r) => setTimeout(r, 700))
        line('长文本状态', await widgetEval('window.__whaleChat ? window.__whaleChat.state() : "no"'))
        fs.writeFileSync(path.join(ROOT, 'debug-shots', 'chat-bubble-long.png'), (await win.webContents.capturePage()).toPNG())

        const clickSay = (down) =>
          widgetEval(
            "(function(){var s=document.querySelector('.dshwv-chat-say');if(!s)return 'no-say';var r=s.getBoundingClientRect();" +
              'var o={bubbles:true,cancelable:true,pointerId:1,isPrimary:true,button:0,buttons:1,clientX:r.x+r.width/2,clientY:r.y+r.height/2};' +
              "s.dispatchEvent(new PointerEvent('pointerdown',o));" +
              (down ? "return 'down'" : "s.dispatchEvent(new PointerEvent('pointerup',o));return 'ok'") +
              '})()'
          )
        line('点一下', await clickSay(false))
        await new Promise((r) => setTimeout(r, 500))
        line('点击后', await widgetEval('window.__whaleChat ? window.__whaleChat.state() : "no"'))
        fs.writeFileSync(path.join(ROOT, 'debug-shots', 'chat-bubble-zoom.png'), (await win.webContents.capturePage()).toPNG())
        line('再点一下', await clickSay(false))
        await new Promise((r) => setTimeout(r, 500))
        line('缩回后', await widgetEval('window.__whaleChat ? window.__whaleChat.state() : "no"'))

        line('按住', await clickSay(true))
        await new Promise((r) => setTimeout(r, 1300))
        line('长按后', await widgetEval('window.__whaleChat ? window.__whaleChat.state() : "no"'))
        await new Promise((r) => setTimeout(r, 1500))
        line('余额收尾', await widgetEval('window.__whaleChat ? window.__whaleChat.state() : "no"'))
      } catch (err) {
        console.log('[chat-test] 失败:', (err && err.message) || err)
      }
      // 把配置还原成测试前的样子
      try {
        if (chatCfgPrev && !chatCfgPrev.on) writeConfig({ chat: chatCfgPrev })
      } catch (err) {}
      setTimeout(() => app.quit(), 500)
    }, 4500)
  }

  // 调试用：只看「其他 → 资源管理」这一页渲染出了什么
  if (process.env.WHALE_RES_TEST) {
    setTimeout(() => {
      openControl()
      setTimeout(async () => {
        try {
          await controlWin.webContents.executeJavaScript(
            "(() => { window.__errs = []; window.addEventListener('error', (e) => window.__errs.push(String(e.message))); return true })()"
          )
          await controlWin.webContents.executeJavaScript(
            "(() => { const t = [...document.querySelectorAll('#tabs .tab')].find((x) => x.dataset.tab === 'misc'); if (t) t.click(); return true })()"
          )
          await new Promise((r) => setTimeout(r, 600))
          await controlWin.webContents.executeJavaScript(
            "(() => { const b = [...document.querySelectorAll('#subnav .subnav-item')].find((x) => /资源/.test(x.textContent)); if (b) b.click(); return true })()"
          )
          await new Promise((r) => setTimeout(r, 2500))
          flog(
            '[res-test] panel >>>\n' +
              (await controlWin.webContents.executeJavaScript(
                "(() => { const p = document.querySelector('#panel'); return p ? p.innerText : 'NO PANEL' })()"
              )) +
              '\n[res-test] errs=' +
              (await controlWin.webContents.executeJavaScript('JSON.stringify(window.__errs)'))
          )
          const img = await controlWin.webContents.capturePage()
          fs.writeFileSync(path.join(ROOT, 'debug-shots', 'res-panel.png'), img.toPNG())
        } catch (err) {
          flog('[res-test] 失败:', err && err.message)
        }
        setTimeout(() => app.quit(), 400)
      }, 2400)
    }, 1500)
  }

  // 调试用：窗口置顶 / 锁定（主进程状态 + 控制中心面板 + 挂件上的小方框）
  if (process.env.WHALE_WIN_TEST) {
    setTimeout(() => {
      openControl()
      setTimeout(async () => {
        const js = (code) => controlWin.webContents.executeJavaScript(code)
        try {
          flog('[win-test] 初始 state=' + JSON.stringify(winState) + ' isOnTop=' + win.isAlwaysOnTop())
          flog('[win-test] pin.put=' + JSON.stringify(await js("window.whaleCtl.putWin({pin:true})")))
          await new Promise((r) => setTimeout(r, 600))
          flog('[win-test] 置顶后 isOnTop=' + win.isAlwaysOnTop() + ' state=' + JSON.stringify(winState))
          flog('[win-test] lock.put=' + JSON.stringify(await js("window.whaleCtl.putWin({lock:true})")))
          await new Promise((r) => setTimeout(r, 700))
          flog(
            '[win-test] 锁定后 state=' +
              JSON.stringify(winState) +
              ' btn=' +
              (await widgetEval(
                "(() => { var b = document.querySelector('.dshwv-lockbtn'); return b ? (b.className + ' | ' + b.title + ' | ' + b.getBoundingClientRect().top) : 'no-btn' })()"
              ))
          )
          await js("(() => { const t = [...document.querySelectorAll('#tabs .tab')].find((x) => x.dataset.tab === 'misc'); if (t) t.click(); return true })()")
          await new Promise((r) => setTimeout(r, 700))
          await js("(() => { const b = [...document.querySelectorAll('#subnav .subnav-item')].find((x) => /窗口/.test(x.textContent)); if (b) b.click(); return true })()")
          await new Promise((r) => setTimeout(r, 1500))
          flog('[win-test] 面板 >>>\n' + (await js("document.querySelector('#panel').innerText")))
          fs.writeFileSync(path.join(ROOT, 'debug-shots', 'win-panel.png'), (await controlWin.webContents.capturePage()).toPNG())
          fs.writeFileSync(path.join(ROOT, 'debug-shots', 'win-widget.png'), (await win.webContents.capturePage()).toPNG())
          flog('[win-test] 复位=' + JSON.stringify(await js("window.whaleCtl.putWin({pin:false, lock:false})")))
          await new Promise((r) => setTimeout(r, 500))
          flog('[win-test] 复位后 state=' + JSON.stringify(winState) + ' isOnTop=' + win.isAlwaysOnTop())
        } catch (err) {
          flog('[win-test] 失败:', err && err.message)
        }
        setTimeout(() => app.quit(), 500)
      }, 2600)
    }, 1600)
  }

  // 调试用：点击动效 + Live2D 全链路（改配置 → 挂件里真的画出来）
  if (process.env.WHALE_L2D_TEST) {
    setTimeout(() => {
      openControl()
      setTimeout(async () => {
        const js = (code) => controlWin.webContents.executeJavaScript(code)
        const probe = () =>
          widgetEval(
            "(() => { const r = window.__whaleL2D ? window.__whaleL2D.status() : null; const c = document.querySelector('.whale-l2d-canvas'); const img = document.querySelector('.dshwv-img'); return { l2d: r, canvas: c ? { w: c.width, h: c.height, css: c.clientWidth + 'x' + c.clientHeight } : null, imgHidden: img ? img.className : null, tap: window.__whaleTap || null, durVar: getComputedStyle(document.documentElement).getPropertyValue('--whale-tap-dur') } })()"
          )
        try {
          await new Promise((r) => setTimeout(r, 800))
          // ① 点击动效
          await js("(() => { const t = [...document.querySelectorAll('#tabs .tab')].find((x) => x.dataset.tab === 'role'); if (t) t.click(); return 1 })()")
          await new Promise((r) => setTimeout(r, 400))
          await js("(() => { const b = [...document.querySelectorAll('#subnav .subnav-item')].find((x) => /点击动效/.test(x.textContent)); if (b) b.click(); return 1 })()")
          await new Promise((r) => setTimeout(r, 900))
          flog('[l2d-test] tap panel >>>\n' + (await js("(() => document.querySelector('#panel').innerText)()")))
          const tapRes = await js("window.whaleCtl.putTap({ amp: 0.25, dur: 0.4 })")
          flog('[l2d-test] putTap ->', tapRes)
          await new Promise((r) => setTimeout(r, 400))
          flog('[l2d-test] widget after tap ->', JSON.stringify(await probe()))
          await js("window.whaleCtl.putTap({ amp: 0.12, dur: 0.22 })")

          // ② Live2D
          await js("(() => { const b = [...document.querySelectorAll('#subnav .subnav-item')].find((x) => /Live2D/.test(x.textContent)); if (b) b.click(); return 1 })()")
          await new Promise((r) => setTimeout(r, 1200))
          flog('[l2d-test] l2d panel >>>\n' + (await js("(() => document.querySelector('#panel').innerText)()")))
          const putRes = await js("window.whaleCtl.putLive2D({ on: true, id: 'ds-whale-girl' })")
          flog('[l2d-test] putLive2D ->', putRes)
          await new Promise((r) => setTimeout(r, 7000))
          flog('[l2d-test] widget after l2d ->', JSON.stringify(await probe()))
          // 关掉再看一眼：<img> 要回来、canvas 要收干净
          await js("window.whaleCtl.putLive2D({ on: false })")
          await new Promise((r) => setTimeout(r, 1200))
          flog('[l2d-test] widget after off ->', JSON.stringify(await probe()))
          await js("window.whaleCtl.putLive2D({ on: true, id: 'ds-whale-girl', scale: 1.2 })")
          await new Promise((r) => setTimeout(r, 6000))
          flog('[l2d-test] widget after re-on ->', JSON.stringify(await probe()))
          // 点一下：确认按压形变真的走了 __whaleTapSquish（amp=0.25 时 scaleY 应当是 0.75）
          const squish = await widgetEval(
            "new Promise((res) => { const img = document.querySelector('.dshwv-img'); const body = document.querySelector('.dshwv-body'); const r = img.getBoundingClientRect(); const x = r.x + r.width / 2, y = r.y + r.height / 2; const fire = (t) => document.dispatchEvent(new PointerEvent(t, { clientX: x, clientY: y, bubbles: true, cancelable: true, pointerId: 1, isPrimary: true, button: 0, buttons: 1 })); fire('pointerdown'); const out = { at: body.style.transform, tap: window.__whaleTap }; setTimeout(() => { fire('pointerup'); out.after = body.style.transform; res(out) }, 120); })"
          )
          flog('[l2d-test] squish ->', JSON.stringify(squish))
          const shot = await win.webContents.capturePage()
          fs.writeFileSync(path.join(ROOT, 'debug-shots', 'l2d-widget.png'), shot.toPNG())
          const shot2 = await controlWin.webContents.capturePage()
          fs.writeFileSync(path.join(ROOT, 'debug-shots', 'l2d-panel.png'), shot2.toPNG())
        } catch (err) {
          flog('[l2d-test] 失败:', err && err.message)
        }
        setTimeout(() => app.quit(), 500)
      }, 2600)
    }, 1200)
  }

  // 调试用：Live2D v2 —— 视线坐标、点击动作多样性、播放速度
  if (process.env.WHALE_L2D_TEST2) {
    setTimeout(() => {
      setTimeout(async () => {
        const probe = () => widgetEval('(() => (window.__whaleL2D ? window.__whaleL2D.status() : null))()')
        try {
          const base = live2dCfg()
          writeConfig({ live2d: Object.assign({}, base, { on: true, id: base.id || 'ds-whale-girl', speed: 1, clickGroup: '*', clickExpr: true }) })
          await pushLive2D()
          await new Promise((r) => setTimeout(r, 7000))
          flog('[l2d2] status ->', JSON.stringify(await probe()))

          // ① 视线：画布正中应当「看正前方」；左上/右下应当分别朝左上/右下
          const focusTest = await widgetEval(
            '(() => {' +
              ' const c = document.querySelector(".whale-l2d-canvas"); if (!c) return "no-canvas";' +
              ' const r = c.getBoundingClientRect();' +
              ' const fc = () => { const i = window.__whaleL2D; const s = i.status(); return s.focus; };' +
              ' const fire = (x, y) => document.dispatchEvent(new PointerEvent("pointermove", { clientX: x, clientY: y, bubbles: true, pointerId: 1, isPrimary: true }));' +
              ' const out = {};' +
              ' fire(r.left + r.width / 2, r.top + r.height / 2); out.center = fc();' +
              ' fire(r.left + r.width * 0.08, r.top + r.height * 0.08); out.leftTop = fc();' +
              ' fire(r.left + r.width * 0.92, r.top + r.height * 0.92); out.rightBottom = fc();' +
              ' fire(r.left + r.width / 2, r.top + r.height / 2); out.back = fc();' +
              ' return JSON.stringify({ rect: { l: Math.round(r.left), t: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) }, out: out });' +
              '})()'
          )
          flog('[l2d2] focus ->', focusTest)

          // ② 点击：连点 6 次，看看抽到的动作组是不是不止一个
          const groups = []
          for (let i = 0; i < 6; i++) {
            await widgetEval(
              '(() => {' +
                ' const c = document.querySelector(".whale-l2d-canvas"); const r = c.getBoundingClientRect();' +
                ' const s = window.__whaleL2D.status(); const box = s.box || { x: 0, y: 0, w: r.width, h: r.height };' +
                ' const x = r.left + box.x + box.w * (0.3 + 0.4 * Math.random());' +
                ' const y = r.top + box.y + box.h * (0.3 + 0.4 * Math.random());' +
                ' const fire = (t) => document.dispatchEvent(new PointerEvent(t, { clientX: x, clientY: y, bubbles: true, cancelable: true, pointerId: 1, isPrimary: true, button: 0, buttons: 1 }));' +
                ' fire("pointerdown"); setTimeout(() => fire("pointerup"), 30); return 1' +
                '})()'
            )
            await new Promise((r) => setTimeout(r, 700))
            const st = await probe()
            const last = st && st.clickLog && st.clickLog.length ? st.clickLog[st.clickLog.length - 1] : null
            groups.push(last ? last.g + (last.ok ? '' : '(fail)') : '(none)')
          }
          flog('[l2d2] clicks ->', JSON.stringify(groups), 'distinct=', new Set(groups).size)

          // ③ 播放速度
          writeConfig({ live2d: Object.assign({}, live2dCfg(), { speed: 1.8 }) })
          await pushLive2D()
          await new Promise((r) => setTimeout(r, 600))
          flog(
            '[l2d2] speed ->',
            await widgetEval('(() => JSON.stringify({ ticker: PIXI.Ticker.shared.speed, status: window.__whaleL2D.status().speed }))()')
          )

          // 恢复成一个合理的默认：速度 1、点击在全部动作组里随机、不强制换表情
          writeConfig({
            live2d: Object.assign({}, live2dCfg(), { on: true, speed: 1, clickGroup: '*', clickExpr: false, blink: true, follow: true }),
          })
          await pushLive2D()
          await new Promise((r) => setTimeout(r, 500))
          flog('[l2d2] final ->', JSON.stringify(await probe()))
        } catch (err) {
          flog('[l2d2] 失败:', err && err.message)
        }
        setTimeout(() => app.quit(), 400)
      }, 4000)
    }, 1200)
  }

  // 调试用：只看控制中心「角色库 → Live2D 形象」这一页渲染出了什么
  if (process.env.WHALE_L2D_PANEL_TEST) {
    setTimeout(() => {
      openControl()
      setTimeout(async () => {
        const js = (code) => controlWin.webContents.executeJavaScript(code)
        try {
          await js("(() => { window.__errs = []; window.addEventListener('error', (e) => window.__errs.push(String(e.message))); return 1 })()")
          await js("(() => { const t = [...document.querySelectorAll('#tabs .tab')].find((x) => x.dataset.tab === 'role'); if (t) t.click(); return 1 })()")
          await new Promise((r) => setTimeout(r, 500))
          await js("(() => { const b = [...document.querySelectorAll('#subnav .subnav-item')].find((x) => /Live2D/.test(x.textContent)); if (b) b.click(); return 1 })()")
          await new Promise((r) => setTimeout(r, 1200))
          flog('[l2d-panel] >>>\n' + (await js("(() => { const p = document.querySelector('#panel'); return p ? p.innerText : 'NO PANEL' })()")))
          flog('[l2d-panel] errs=' + (await js('JSON.stringify(window.__errs)')))
        } catch (err) {
          flog('[l2d-panel] 失败:', err && err.message)
        }
        setTimeout(() => app.quit(), 300)
      }, 2200)
    }, 1200)
  }

  // 调试用：点一次「删除」走完整链路，确认按钮真的能改数据
  if (process.env.WHALE_RES_DEL_TEST) {
    setTimeout(() => {
      openControl()
      setTimeout(async () => {
        const js = (code) => controlWin.webContents.executeJavaScript(code)
        try {
          await js("(() => { const t = [...document.querySelectorAll('#tabs .tab')].find((x) => x.dataset.tab === 'misc'); if (t) t.click(); return 1 })()")
          await new Promise((r) => setTimeout(r, 500))
          await js("(() => { const b = [...document.querySelectorAll('#subnav .subnav-item')].find((x) => /资源/.test(x.textContent)); if (b) b.click(); return 1 })()")
          await new Promise((r) => setTimeout(r, 2000))
          const clicked = await js(
            "(() => { const rows = [...document.querySelectorAll('#panel .restitem')]; const row = rows.find((r) => /测试泡泡/.test(r.textContent)); if (!row) return 'no-row'; const btn = [...row.querySelectorAll('button')].find((b) => /删除/.test(b.textContent)); if (!btn) return 'no-btn'; btn.click(); return 'clicked' })()"
          )
          await new Promise((r) => setTimeout(r, 500))
          const confirmed = await js(
            "(() => { const b = [...document.querySelectorAll('#modal .btn.primary')].pop(); if (!b) return 'no-modal'; b.click(); return 'confirmed' })()"
          )
          await new Promise((r) => setTimeout(r, 1500))
          const list = await js(
            "(() => fetch('/dsh-whale/bubble-imgs.json', { cache: 'no-store' }).then((r) => r.json()).then((d) => JSON.stringify((d.images || []).map((i) => i.name))))()"
          )
          flog('[res-del] ' + clicked + ' / ' + confirmed + ' / 剩余泡泡图=' + list)
        } catch (err) {
          flog('[res-del] 失败:', err && err.message)
        }
        setTimeout(() => app.quit(), 400)
      }, 2400)
    }, 1500)
  }

  // 调试用：直接拉起设置窗口并截图，验证账号模块的 UI 链路
  // 调试用：只测「使用图表」页的平台切换
  if (process.env.WHALE_CHART_TEST) {
    setTimeout(() => {
      openControl()
      setTimeout(async () => {
        const shot = async (name) => {
          const img = await controlWin.webContents.capturePage()
          fs.writeFileSync(path.join(ROOT, 'debug-shots', name), img.toPNG())
        }
        try {
          await controlWin.webContents.executeJavaScript(
            "(() => { window.__errs = []; window.addEventListener('error', (e) => window.__errs.push(String(e.message))); return true })()"
          )
          await controlWin.webContents.executeJavaScript(
            "(() => { const t = [...document.querySelectorAll('#tabs .tab')].find((x) => x.dataset.tab === 'ledger'); if (t) t.click(); return true })()"
          )
          await new Promise((r) => setTimeout(r, 800))
          await controlWin.webContents.executeJavaScript(
            "(() => { const b = [...document.querySelectorAll('#subnav .subnav-item')].find((x) => /图表/.test(x.textContent)); if (b) b.click(); return true })()"
          )
          await new Promise((r) => setTimeout(r, 1600))
          await shot('chart-deepseek.png')
          const txt1 = await controlWin.webContents.executeJavaScript("(() => document.querySelector('#panel').innerText)()")
          const switched = await controlWin.webContents.executeJavaScript(
            "(() => { const s = document.querySelector('#panel select'); if (!s || s.options.length < 2) return 'NO_OPTION:' + (s ? s.options.length : -1); s.value = s.options[1].value; s.dispatchEvent(new Event('change')); return s.options[1].textContent })()"
          )
          await new Promise((r) => setTimeout(r, 1800))
          await shot('chart-other.png')
          const txt2 = await controlWin.webContents.executeJavaScript("(() => document.querySelector('#panel').innerText)()")
          const errs = await controlWin.webContents.executeJavaScript('JSON.stringify(window.__errs)')
          flog(
            '[chart-test] switched=' + switched +
              '\n[chart-test] deepseek >>>\n' + txt1 +
              '\n[chart-test] other >>>\n' + txt2 +
              '\n[chart-test] usage-file >>>\n' + JSON.stringify(readApiUsage()).slice(0, 1600) +
              '\n[chart-test] errs=' + errs
          )
        } catch (err) {
          flog('[chart-test] 失败:', err)
        }
      }, 2400)
    }, 1500)
  }

  if (process.env.WHALE_CONTROL_TEST) {
    setTimeout(() => {
      openControl()
      setTimeout(async () => {
        try {
          const specs = [
            { t: 'role', subs: 3 },
            { t: 'sound', subs: 4 },
            { t: 'ledger', subs: 4 },
            { t: 'misc', subs: 3 },
          ]
          for (const spec of specs) {
            controlWin.webContents.send('ctl:tab', spec.t)
            await new Promise((r) => setTimeout(r, 700))
            for (let i = 0; i < spec.subs; i++) {
              await controlWin.webContents.executeJavaScript(
                "(() => { const b = document.querySelectorAll('#subnav .subnav-item')[" + i + "]; if (b) b.click(); return true })()"
              )
              await new Promise((r) => setTimeout(r, 700))
              const img = await controlWin.webContents.capturePage()
              fs.writeFileSync(path.join(ROOT, 'debug-shots', 'control-' + spec.t + '-' + i + '.png'), img.toPNG())
            }
          }
          console.log('[whale] 控制中心截图已保存')

          // 实测：写 size.json（scale）后挂件是否真的跟着变
          try {
            const probeSize = () =>
              win.webContents.executeJavaScript(
                "(() => { const r = document.querySelector('.dshwv-root'); if (!r) return null; const b = r.getBoundingClientRect(); return { w: Math.round(b.width), h: Math.round(b.height) } })()"
              )
            const before = await probeSize()
            const base0 = hostBase()
            const cur = await (await fetch(base0 + '/dsh-whale/size.json')).json()
            await fetch(base0 + '/dsh-whale/size.json', {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(Object.assign({}, cur, { scale: 1.8 })),
            })
            nudgeWidgetResync()
            await new Promise((r) => setTimeout(r, 3200))
            const after = await probeSize()
            await fetch(base0 + '/dsh-whale/size.json', {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(Object.assign({}, cur, { scale: cur.scale })),
            })
            nudgeWidgetResync()
            flog('[ctl-test] scale 1.5 -> 1.8 :', JSON.stringify(before), '->', JSON.stringify(after))
          } catch (err) {
            flog('[ctl-test] 尺寸实测失败:', err && err.message)
          }
        } catch (err) {
          console.log('[whale] 控制中心截图失败:', err && err.message)
        }
      }, 2200)
    }, 1500)
  }

  if (process.env.WHALE_SETTINGS_TEST) {
    setTimeout(() => {
      openSettings()
      setTimeout(async () => {
        try {
          const img = await settingsWin.webContents.capturePage()
          fs.writeFileSync(path.join(ROOT, 'debug-shots', 'settings.png'), img.toPNG())
          console.log('[whale] 设置页截图已保存')
        } catch (err) {
          console.log('[whale] 设置页截图失败:', err && err.message)
        }
      }, 2600)
    }, 1200)
  }
}

app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion')

app.whenReady().then(() => {
  applyAutostart(autostartEnabled())
  boot().catch((err) => {
    console.error('[whale] 启动失败:', err && (err.stack || err.message))
  })
})

app.on('window-all-closed', () => {
  app.quit()
})

app.on('before-quit', () => {
  if (bottomTimer) clearInterval(bottomTimer)
  try {
    if (chatBridge) chatBridge.close()
  } catch (err) {}
  try {
    if (peekCtrl) peekCtrl.dispose()
  } catch (err) {}
  try {
    if (host) host.close()
  } catch (err) {}
})
