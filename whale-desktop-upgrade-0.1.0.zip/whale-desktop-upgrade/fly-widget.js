'use strict'
// 闲置自动飞行：连续 1 分钟全系统无键鼠输入 -> 换成飞行形象在窗口内飞 10 秒 -> 落回原位，落地后重新计时。
// 飞行期间一有输入就加速飞回原位。主进程负责读系统空闲（powerMonitor），页面负责动画。
const fs = require('node:fs')
const path = require('node:path')

const NORMAL = { idleSec: 60, durationMs: 10000, speed: 250 }
const TEST = { idleSec: 6, durationMs: 6000, speed: 250 }

function createFlyController(opts) {
  const { powerMonitor, widgetEval, flog } = opts
  const C = Object.assign({}, opts.test ? TEST : NORMAL, opts.tune || {})
  const gifPath = opts.gifPath
  let injected = false
  let phase = 'idle' // idle | fly | return
  let startedAt = 0
  let lastLandAt = 0
  let pollTimer = null
  let loopTimer = null
  let dataUrl = ''

  function readGif() {
    if (dataUrl) return dataUrl
    try {
      const buf = fs.readFileSync(gifPath)
      // 按文件头嗅探 mime：RIFF/WEBP -> image/webp，GIF8 -> image/gif
      const head = buf.slice(0, 12).toString('latin1')
      const mime = head.startsWith('RIFF') && head.includes('WEBP') ? 'image/webp' : 'image/gif'
      dataUrl = 'data:' + mime + ';base64,' + buf.toString('base64')
    } catch (err) {
      flog('[fly] 读飞行动画失败', err && err.message)
      dataUrl = ''
    }
    return dataUrl
  }

  async function push() {
    injected = false
    const url = readGif()
    if (!url) return false
    let src = ''
    try {
      src = fs.readFileSync(path.join(__dirname, 'fly-inject.js'), 'utf8')
    } catch (err) {
      flog('[fly] 注入脚本读取失败', err && err.message)
      return false
    }
    await widgetEval('window.__whaleFlyGif=' + JSON.stringify(url) + '; true')
    const r = await widgetEval(';(' + src + ')')
    injected = r === 'ready' || r === 'exists'
    flog('[fly] 注入 ->', r)
    return injected
  }

  async function stateOf() {
    const s = await widgetEval('window.__whaleFly ? window.__whaleFly.state() : ""')
    if (!s) return null
    try {
      return JSON.parse(s)
    } catch (err) {
      return null
    }
  }

  async function beginFlight() {
    if (!injected && !(await push())) return
    const r = await widgetEval(
      'window.__whaleFly ? window.__whaleFly.start(null, {speed:' + C.speed + '}) : "no"'
    )
    if (r !== 'ok') {
      flog('[fly] 起飞没成功:', r)
      return
    }
    phase = 'fly'
    startedAt = Date.now()
    flog('[fly] 起飞 idle=', powerMonitor.getSystemIdleTime() + 's')
    if (pollTimer) clearInterval(pollTimer)
    pollTimer = setInterval(poll, 400)
  }

  async function poll() {
    const st = await stateOf()
    if (!st) return
    if (st.phase === 'fly') {
      if (powerMonitor.getSystemIdleTime() < 1) {
        await widgetEval('window.__whaleFly.home(true)')
        phase = 'return'
        flog('[fly] 检测到操作 -> 加速回位')
      } else if (Date.now() - startedAt >= C.durationMs) {
        await widgetEval('window.__whaleFly.home(false)')
        phase = 'return'
        flog('[fly] 飞满时长 -> 降落')
      }
    } else if (st.phase === 'done') {
      if (pollTimer) clearInterval(pollTimer)
      pollTimer = null
      phase = 'idle'
      lastLandAt = Date.now()
      flog('[fly] 降落完成，重新计时')
    }
  }

  function tick() {
    if (phase !== 'idle') return
    if (Date.now() - lastLandAt < C.idleSec * 1000) return
    if (powerMonitor.getSystemIdleTime() < C.idleSec) return
    beginFlight().catch((err) => flog('[fly] 起飞异常', err && err.message))
  }

  return {
    push,
    start() {
      if (loopTimer) return
      lastLandAt = Date.now()
      loopTimer = setInterval(tick, 1000)
      flog('[fly] 闲置飞行已开启', C)
    },
    stop() {
      if (loopTimer) clearInterval(loopTimer)
      if (pollTimer) clearInterval(pollTimer)
      loopTimer = null
      pollTimer = null
    },
    status() {
      return { phase, injected, lastLandAt }
    }
  }
}

module.exports = { createFlyController }
