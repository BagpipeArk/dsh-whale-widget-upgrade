@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo 没找到 node，请先安装 Node.js 18+：
  echo   https://nodejs.org
  pause
  exit /b 1
)

if not exist "vendor\whale-widget\assets\whale-widget.js" (
  echo 还没有挂件本体。先运行一次 install.ps1：
  echo   powershell -ExecutionPolicy Bypass -File install.ps1 -HostDir "已经装好的鲸鱼娘目录"
  pause
  exit /b 1
)

if not exist "node_modules\electron\dist\electron.exe" (
  echo 首次启动，正在安装依赖 electron / koffi ...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo 依赖安装失败，检查网络后重试。
    pause
    exit /b 1
  )
)

echo 正在拉起本地服务（缺 python 就只跑界面）...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0whale.ps1" start -NoWidget

echo 启动界面...
start "" "%~dp0node_modules\electron\dist\electron.exe" "%~dp0"
exit /b 0
