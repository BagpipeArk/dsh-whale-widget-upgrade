// peek.js —— 窗口选择器：列出所有窗口缩略图，点一个就开始窥屏
(function () {
  var grid = document.getElementById('grid')
  var hint = document.getElementById('hint')
  var countEl = document.getElementById('count')
  var loading = false

  function setHint(text) {
    hint.textContent = text || ''
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]
    })
  }

  function choose(item) {
    setHint('已选择：' + (item.name || item.id) + '，正在开始…')
    try {
      window.whalePeek.choose(item.id, item.name)
    } catch (err) {}
  }

  function render(list) {
    grid.innerHTML = ''
    if (!list || !list.length) {
      setHint('没扫到可用的窗口，先把要陪你看的窗口打开再点刷新')
      countEl.textContent = ''
      return
    }
    list.forEach(function (item) {
      var card = document.createElement('div')
      card.className = 'card'
      card.title = item.name || ''
      var imgHtml = item.thumb
        ? '<img class="thumb" src="' + item.thumb + '" alt="" />'
        : '<div class="thumb"></div>'
      card.innerHTML =
        imgHtml +
        '<div class="meta"><span class="name">' +
        esc(item.name || item.id) +
        '</span><span class="app">' +
        esc(item.app || '') +
        '</span></div>'
      card.addEventListener('click', function () {
        choose(item)
      })
      grid.appendChild(card)
    })
    countEl.textContent = '共 ' + list.length + ' 个窗口'
    setHint('')
  }

  async function load() {
    if (loading) return
    loading = true
    setHint('正在扫描窗口…')
    try {
      var list = await window.whalePeek.list()
      render(list)
    } catch (err) {
      setHint('扫描失败：' + String((err && err.message) || err))
    } finally {
      loading = false
    }
  }

  document.getElementById('refresh').addEventListener('click', load)
  document.getElementById('cancel').addEventListener('click', function () {
    try {
      window.whalePeek.cancel()
    } catch (err) {}
  })
  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      try {
        window.whalePeek.cancel()
      } catch (err) {}
    }
  })

  load()
})()
