﻿# 鲸鱼娘 · 桌面增强升级包 0.1.0

> ## ⚠️ 先看这里：本包已脱敏，程序**不完整**，装之前必须先按本文配置
>
> 发布前做过自动脱敏，账号、本机路径、称呼、角色名、世界观名词都换成了 `<...>` 占位符。
> **直接解压就装是跑不起来的**：语音人格是空壳、音色 provider id 不存在、示例路径对不上你机器，
> 表现为"界面能开但不会说话 / 一开口服务报错"。
>
> 只有一条正确顺序：
> 1. 解压到一个有写权限的目录（别放在 `Program Files`）
> 2. **先对照 [第 7 节 占位符表](#7-隐私与占位符)，把 `<...>` 改成你自己机器上的真实值**
> 3. 再执行 `install.ps1`
>
> 想先跑起来的最小集合：`<CHAR_NAME>` `<CHAR_ALIAS>` `<USER_TITLE>` `<WORLD_SERIES>` `<WORLD_PLACE>` `<WORLD_SCHOOL>` `<WORLD_DEPT>` `<WORLD_THREAT>` `<TTS_PROVIDER_ID>`。

**依附鲸鱼娘本体运行的升级包**，和 `dsh-whale-widget-upgrade` 是同一路数：
包里**没有 exe**、**没有挂件本体**（`vendor\whale-widget` 连同图标全部取自已装的那份），
装完靠 Node + Electron 跑起来。本体一升级，重跑一次安装就能跟上。

> 一句话：**没有装鲸鱼娘本体，这个包装了也不会出现鲸鱼。**
> 想独立运行、不依赖任何已装环境，用完整包 `WhaleDesktop-*-win-x64.zip`。

---

## 1. 前提

| 必须 / 可选 | 东西 | 说明 |
| --- | --- | --- |
| 必须 | 已安装的鲸鱼娘本体 | 判定标准：目录里有 `main.js` 和 `vendor\whale-widget\assets\whale-widget.js` |
| 必须 | Node.js 18+ | https://nodejs.org ，装完 `node -v` 能出结果 |
| 可选 | Python 3.12 + 依赖 | 语音识别 / 朗读 / 窥屏 / 语音聊天要它；缺了只有气泡界面 |
| 可选 | GPT-SoVITS | 出声用（`api_v2.py` 起在 9880） |
| 可选 | 参考音色 `ref.wav` | 合成音色，缺失就没声音 |

---

## 2. 安装

> 前提：**第 7 节的占位符已经替换成你机器上的真实值**。

```powershell
# 1) 解压到一个有写权限的目录（别放进 Program Files）
# 2) 在本目录执行（会自动找已装的本体）
powershell -ExecutionPolicy Bypass -File install.ps1

# 找不到本体，就手动指定一下
powershell -ExecutionPolicy Bypass -File install.ps1 -HostDir "D:\你装鲸鱼娘的目录"

# 只自检，不动任何文件
powershell -ExecutionPolicy Bypass -File install.ps1 -Check
```

`install.ps1` 干这几件事：

1. 找本体：参数 `-HostDir` → 环境变量 `WHALE_HOST_DIR` → 正在运行的 WhaleDesktop 进程 → 桌面快捷方式 → 常见安装位置 → 包的同级目录；
2. 把本体的 `vendor\whale-widget` 镜像到本包（**本体目录一个字节都不动**）；
3. 顺手机镜像 `node_modules\koffi`，缺了就靠 `npm install` 补；
4. 生成 `paths.json`，把语音服务的 python / 模型 / 音色指向本体（本体有 `venv`、`models`、`ref\ref.wav` 时）；
5. 给镜像出来的挂件打补丁（独立桌面版必需，否则界面里一条鲸鱼都不会出现）；
6. `npm install` 装 electron / koffi；
7. 自检并打印结论。

装完双击 **`start.cmd`**：先拉起本地 python 服务，再打开 electron 界面。

---

## 3. 和完整包的区别

| | 升级包（本包） | 完整包 |
| --- | --- | --- |
| 体积 | 约 1 MB（不含依赖） | 约 105 MB |
| 自带 exe | ✗ | ✓ |
| 自带挂件本体 | ✗ 从本体取 | ✓ |
| 需要 Node | ✓ | ✗ |
| 需要已装本体 | ✓ | ✗ |
| 首次启动 | 等 npm 装 electron | 解压即用 |
| 适合谁 | 已经装过鲸鱼娘、想更新功能的人 | 第一次用的人 |

两边**代码是同一份**：`main.js`、`control.js`、`server\*.mjs`、`server\*.py` 完全一致，
只是启动方式不同。用哪个都不会影响另一个。

---

## 4. 包里都有什么

```
whale-desktop-upgrade-0.1.0\
├─ install.ps1          找本体 / 取挂件 / 装依赖 / 自检
├─ start.cmd            一键启动（服务 + 界面）
├─ whale.ps1            服务启停（start / stop / status / check）
├─ package.json         electron / koffi 依赖声明，whaleUpgrade.mode = attach
├─ paths.example.json   配置模板（install.ps1 会直接生成 paths.json）
├─ fetch-models.ps1     下载语音识别模型
├─ requirements.txt     python 依赖
├─ main.js              主进程
├─ preload.js / *_preload.js
├─ control.html / control.css / control.js     控制中心
├─ settings.html / settings-preload.js         设置页
├─ chat-inject.js / chat-widget.js             气泡
├─ fly-inject.js / fly-widget.js / fly.gif     飞行
├─ lock-widget.js / peek.*                     锁定与窥屏窗口
├─ web\live2d\          Live2D 形象层
├─ server\              python 服务 + 本地假宿主（host-shim / chat-bridge / web-balance）
├─ build\icon.ico
└─ vendor\              ← 空着，install.ps1 从本体镜像进来
```

---

## 5. 语音服务怎么接到本体上

`install.ps1` 会生成一份 `paths.json`，默认复用本体的资源：

```json
{
  "python": "<本体>\venv\Scripts\pythonw.exe",
  "WHALE_STT_MODEL_DIR": "<本体>\models",
  "WHALE_REF_AUDIO": "<本体>\ref\ref.wav",
  "gsvDir": "",
  "voiceHotkey": "`"
}
```

- 想用自己的一套：改 `paths.json` 或设环境变量（环境变量优先）。
- 本体没有 `venv` 时 `python` 会留空，退回系统 `pythonw.exe`。
- 服务端口与完整包一致：32168 主进程、32170 窥屏、32171 识别、32172 朗读、32173 语音聊天、32174 界面。

---

## 6. 常见问题

**「没找到已装的鲸鱼娘本体」**
本体必须带 `vendor\whale-widget\assets\whale-widget.js`。只装过 DSH 插件、没装桌宠本体的话，
用 `-HostDir` 指到插件目录也能取（只要是 `dsh-whale-widget` 的结构）。

**界面起来了，但没有鲸鱼**
补丁没打上。重跑 `node server/patch-vendor.mjs`，看输出里 `applied` 有没有 `standalone` 和 `tap`。
上游改过源码时补丁可能跳过，这时界面会一直等输入框。

**没有声音**
先看 32172 和 9880 在不在（`whale.ps1 status`）。GSV 没起、`ref.wav` 缺失、
参考文本和音频对不上，都会导致 400 静默失败。

**端口被占**
本包和完整包端口一样，两个别同时开。要么 `whale.ps1 stop` 停掉旧的，要么设 `WHALE_PORT` 换端口。

**npm install 很慢**
走代理或换镜像：`npm config set registry https://registry.npmmirror.com`。

---

## 7. 隐私与占位符

打包时做过自动脱敏：账号、本机路径、称呼、角色名、作品名词都换成了 `<...>` 占位符。
把下表按需要替换成自己的内容即可：

| 占位符 | 原来是什么 | 出现在哪 |
| --- | --- | --- |
| `<CHAR_NAME>` | 角色本名 | `server\voice-chat.py` 的 `SYSTEM_PROMPT`、控制中心文案 |
| `<CHAR_ALIAS>` | 角色艺名 | 同上 |
| `<USER_TITLE>` | 角色对使用者的固定称呼 | 同上、气泡默认文案 |
| `<WORLD_SERIES>` | 作品名 | 人格提示词、识别 `prompt` |
| `<WORLD_PLACE>` `<WORLD_SCHOOL>` `<WORLD_DEPT>` | 世界观地名 / 学院名 | 同上 |
| `<WORLD_THREAT>` | 世界观敌人名 | 同上 |
| `<TTS_PROVIDER_ID>` | 原作者的音色 provider id | `server\tts_server.py` 读音色参数用；换成自己的 id，或设环境变量 `WHALE_TTS_PROVIDER_ID` |
| `<USER_NAME>` | 作者的 Windows 用户名 | 路径示例 |
| `<QQ_MAIN>` `<QQ_SENIOR>` | 作者的两个 QQ | 仅说明文本，不影响运行 |
| `<ASTRBOT_INSTANCE_ID>` | AstrBot 实例 UUID | 路径示例 |

**不在包里**：`vendor\whale-widget`（从本体取）、`node_modules`（npm 装）、`ref.wav`、
`models`、`paths.json`、日志、缓存、录音、截图。

---

## 8. 版本

- `0.1.0` —— 首个升级包形态：气泡聊天、余额用量、听电脑说话、窥屏吐槽、语音朗读、按住说话的语音聊天；
  依附本体取挂件，语音服务复用本体的 python / 模型 / 音色。
