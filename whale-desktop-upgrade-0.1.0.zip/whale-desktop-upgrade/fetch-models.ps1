# 下载 STT 模型（faster-whisper small / int8）。可选，大小约 460MB。
# 用法： powershell -ExecutionPolicy Bypass -File fetch-models.ps1
# 国内建议保持默认镜像；官方源把 -NoMirror 传进来即可。

param([switch]$NoMirror)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:WHALE_HOME = $Root
if ($NoMirror) { Remove-Item Env:HF_ENDPOINT -ErrorAction SilentlyContinue }
else { $env:HF_ENDPOINT = "https://hf-mirror.com" }

$target = Join-Path $Root "models"
New-Item -ItemType Directory -Force -Path $target | Out-Null
Write-Host "[whale] HF_ENDPOINT = $($env:HF_ENDPOINT)"
Write-Host "[whale] target      = $target"

$candidates = @(
  (Join-Path $Root "venv\Scripts\python.exe"),
  (Join-Path $Root "tools\python\python.exe")
)
$python = $null
foreach ($c in $candidates) { if (Test-Path $c) { $python = $c; break } }
if (-not $python) { $python = (Get-Command python.exe -ErrorAction SilentlyContinue).Source }
if (-not $python) { Write-Host "[whale] no python.exe found"; exit 1 }
Write-Host "[whale] python      = $python"

$code = @"
import os, sys
from faster_whisper import WhisperModel
target = sys.argv[1]
model = WhisperModel("Systran/faster-whisper-small", device="cpu", compute_type="int8", download_root=target)
print("model ready:", model)
"@
& $python -c $code $target
if ($LASTEXITCODE -ne 0) { Write-Host "[whale] download failed, check network / HF_ENDPOINT"; exit 1 }
Write-Host "[whale] done. model dir: $target"
