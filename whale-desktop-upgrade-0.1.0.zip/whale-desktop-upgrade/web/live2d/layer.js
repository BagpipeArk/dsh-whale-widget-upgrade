// layer.js —— 挂件里的 Live2D 渲染层
//
// 设计要点（都是踩过坑才这么写的）：
// ① 不碰 vendor bundle 的内部状态：只往 .dshwv-body 里塞一层 canvas，定位与 .dshwv-img 完全一致。
//    挂件自己的 alpha 凸包命中测试、拖拽、翻转全部照旧 —— 因为它们作用在 <img> 上。
// ② <img> 只是「变透明」，不是 display:none：命中测试和拖拽挂在它身上，拿掉就点不动了。
// ③ 任何一步失败都不许把鲸鱼娘弄没：catch 里一律先把 <img> 还原。
// ④ 库是懒加载的（core → pixi → display，顺序不能换）：不用 Live2D 的人一分钱都不付。
;(function () {
  if (window.__whaleL2D) return

  var LIB_BASE = '/whale-lib/'
  var SCRIPTS = ['live2dcubismcore.min.js', 'pixi.min.js', 'live2d-display.cubism4.min.js']
  var IMG_CLS = 'whale-l2d-hidden'
  var CANVAS_CLS = 'whale-l2d-canvas'

  var state = {
    cfg: null,          // 最近一次 apply 的配置
    canvas: null,
    app: null,
    model: null,
    modelKey: '',       // 当前加载的 url（换模型时对比）
    idleKey: '',        // 当前待机动作组（换组要重载模型）
    loading: false,
    libs: false,
    followBound: false,
    clickBound: false,
    observer: null,
  }

  function log() {
    var args = Array.prototype.slice.call(arguments)
    try {
      console.log.apply(console, ['[whale-l2d]'].concat(args))
    } catch (err) {}
  }

  function bodyEl() {
    return document.querySelector('.dshwv-root .dshwv-body') || document.querySelector('.dshwv-body')
  }
  function imgEl() {
    return document.querySelector('.dshwv-root .dshwv-img') || document.querySelector('.dshwv-img')
  }

  function injectStyle() {
    if (document.getElementById('whale-l2d-style')) return
    var st = document.createElement('style')
    st.id = 'whale-l2d-style'
    st.textContent = [
      '.' + CANVAS_CLS + '{position:absolute;right:0;bottom:0;width:59.45%;height:59.45%;pointer-events:none;z-index:0;display:block}',
      '.dshwv-img.' + IMG_CLS + '{opacity:0 !important}',
    ].join('\n')
    document.head.appendChild(st)
  }

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script')
      s.src = src
      s.async = false
      s.onload = function () { resolve(true) }
      s.onerror = function () { reject(new Error('脚本加载失败：' + src)) }
      document.head.appendChild(s)
    })
  }

  function ensureLibs() {
    if (state.libs || (window.PIXI && window.PIXI.live2d && window.Live2DCubismCore)) {
      state.libs = true
      return Promise.resolve(true)
    }
    var chain = Promise.resolve()
    SCRIPTS.forEach(function (f) {
      chain = chain.then(function () { return loadScript(LIB_BASE + f) })
    })
    return chain.then(function () {
      if (!window.PIXI || !window.PIXI.live2d) throw new Error('PIXI / live2d 没挂上')
      try {
        if (PIXI.live2d.Live2DModel && PIXI.live2d.Live2DModel.registerTicker) {
          PIXI.live2d.Live2DModel.registerTicker(PIXI.Ticker)
        }
      } catch (err) {}
      state.libs = true
      return true
    })
  }

  function showImg(on) {
    var img = imgEl()
    if (!img) return
    if (on) img.classList.remove(IMG_CLS)
    else img.classList.add(IMG_CLS)
  }

  function destroyModel() {
    if (state.model) {
      try {
        if (state.model.parent) state.model.parent.removeChild(state.model)
      } catch (err) {}
      try { state.model.destroy() } catch (err) {}
      state.model = null
    }
    state.modelKey = ''
    state.idleKey = ''
  }

  function teardown() {
    destroyModel()
    if (state.observer) {
      try { state.observer.disconnect() } catch (err) {}
      state.observer = null
    }
    if (state.app) {
      try { state.app.destroy(true, { children: true }) } catch (err) {}
      state.app = null
    }
    if (state.canvas) {
      try { state.canvas.remove() } catch (err) {}
      state.canvas = null
    }
    showImg(true)
  }

  function layout() {
    var cfg = state.cfg || {}
    var canvas = state.canvas
    if (!canvas || !state.app || !state.model) return
    var parent = bodyEl()
    if (!parent) return
    var bw = parent.clientWidth || 1
    var bh = parent.clientHeight || 1
    var w = Math.max(1, Math.round(bw * 0.5945))
    var h = Math.max(1, Math.round(bh * 0.5945))
    try { state.app.renderer.resize(w, h) } catch (err) {}

    var m = state.model
    var scale = Number(cfg.scale)
    if (!isFinite(scale) || scale <= 0) scale = 1
    var baseH = m.height || 1 // 当前缩放下的高度
    var curScale = m.scale.y || 1
    // 目标：模型高度 = 画布高度 × scale
    var target = (h / (baseH / curScale)) * scale
    if (isFinite(target) && target > 0) m.scale.set(target)

    var ox = Number(cfg.offsetX) || 0
    var oy = Number(cfg.offsetY) || 0
    var hasAnchor = m.anchor && m.anchor.set
    try {
      if (hasAnchor) m.anchor.set(0.5, 1)
    } catch (err) { hasAnchor = false }
    if (hasAnchor) {
      m.x = w * 0.5 + ox * w
      m.y = h + oy * h
    } else {
      m.x = (w - m.width) * 0.5 + ox * w
      m.y = h - m.height + oy * h
    }
  }

  function applyCommon(cfg) {
    var m = state.model
    if (!m) return
    var im = m.internalModel
    if (im) {
      // 眨眼：库里是 `null == this.eyeBlink || this.eyeBlink.updateParameters(...)`，
      // 所以置 null 就是「不眨」，不会抛错。
      if (cfg.blink === false) {
        try { im.eyeBlink = null } catch (err) {}
      }
    }
    if (!cfg.follow) {
      // 关掉跟随：把视线固定回画布中心，之后不再响应鼠标
      try { m.focus((state.canvas.clientWidth || 1) / 2, (state.canvas.clientHeight || 1) / 2) } catch (err) {}
    }
  }

  function bindFollow() {
    if (state.followBound) return
    state.followBound = true
    document.addEventListener(
      'pointermove',
      function (e) {
        var cfg = state.cfg
        if (!cfg || !cfg.follow || !state.model) return
        try { state.model.focus(e.clientX, e.clientY) } catch (err) {}
      },
      true
    )
  }

  function bindClickMotion() {
    if (state.clickBound) return
    state.clickBound = true
    // 捕捉阶段挂在 document 上：挂件自己的 pressDown/pressUp 也在这条链路上，互不影响
    document.addEventListener(
      'pointerdown',
      function (e) {
        var cfg = state.cfg
        if (!cfg || !cfg.clickGroup || !state.model) return
        var t = e.target
        if (!t || !t.closest) return
        // 只认鲸鱼自己（含那层透明 img / canvas 区域）
        if (!t.closest('.dshwv-img') && !t.closest('.dshwv-body')) return
        try {
          var groups = (state.model.internalModel && state.model.internalModel.motionManager && state.model.internalModel.motionManager.definitions) || {}
          var list = groups[cfg.clickGroup]
          var n = list && list.length ? list.length : 0
          state.model.motion(cfg.clickGroup, n > 1 ? Math.floor(Math.random() * n) : 0)
        } catch (err) {}
      },
      true
    )
  }

  function loadModel(cfg) {
    var url = cfg.url
    if (!url) return Promise.resolve(false)
    var idleKey = cfg.idleGroup || 'Idle'
    if (state.modelKey === url && state.model && state.idleKey === idleKey) {
      layout()
      applyCommon(cfg)
      return Promise.resolve(true)
    }
    state.loading = true
    destroyModel()
    return PIXI.live2d.Live2DModel.from(url, {
      autoInteract: false,
      autoUpdate: true,
      idleMotionGroup: cfg.idleGroup || 'Idle',
    })
      .then(function (model) {
        state.model = model
        state.modelKey = url
        state.idleKey = cfg.idleGroup || 'Idle'
        var stage = state.app.stage
        stage.removeChildren()
        stage.addChild(model)
        layout()
        applyCommon(cfg)
        state.loading = false
        log('模型已加载', url)
        return true
      })
      .catch(function (err) {
        state.loading = false
        log('模型加载失败', String((err && err.message) || err))
        showImg(true)
        return false
      })
  }

  function ensureCanvas() {
    var parent = bodyEl()
    if (!parent) throw new Error('还没找到挂件容器')
    if (!state.canvas) {
      var canvas = document.createElement('canvas')
      canvas.className = CANVAS_CLS
      parent.appendChild(canvas)
      state.canvas = canvas
      var w = Math.max(1, Math.round((parent.clientWidth || 1) * 0.5945))
      var h = Math.max(1, Math.round((parent.clientHeight || 1) * 0.5945))
      state.app = new PIXI.Application({
        view: canvas,
        width: w,
        height: h,
        backgroundAlpha: 0,
        antialias: true,
        autoDensity: true,
        resolution: window.devicePixelRatio || 1,
        powerPreference: 'low-power',
      })
    }
    if (!state.observer && window.ResizeObserver) {
      state.observer = new ResizeObserver(function () { layout() })
      state.observer.observe(parent)
    }
  }

  function apply(cfg) {
    state.cfg = Object.assign({}, state.cfg || {}, cfg || {})
    var c = state.cfg
    if (!c.on || !c.url) {
      teardown()
      log('已关闭 Live2D 层')
      return Promise.resolve({ ok: true, running: false })
    }
    injectStyle()
    return ensureLibs()
      .then(function () {
        ensureCanvas()
        bindFollow()
        bindClickMotion()
        showImg(false)
        return loadModel(c)
      })
      .then(function (ok) {
        if (ok) layout()
        return { ok: !!ok, running: !!ok }
      })
      .catch(function (err) {
        log('启动失败', String((err && err.message) || err))
        teardown()
        return { ok: false, error: String((err && err.message) || err) }
      })
  }

  window.__whaleL2D = {
    apply: apply,
    stop: function () { teardown(); return { ok: true } },
    layout: layout,
    status: function () {
      return {
        on: !!(state.cfg && state.cfg.on),
        running: !!state.model,
        loading: state.loading,
        key: state.modelKey,
      }
    },
  }
})()
