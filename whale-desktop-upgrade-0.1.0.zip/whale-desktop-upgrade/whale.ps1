param(
  [Parameter(Position = 0)][string]$Action = "start",
  [switch]$NoWidget
)

# WhaleDesktop launcher / cleaner.
#   powershell -ExecutionPolicy Bypass -File whale.ps1 start
#   ... stop | restart | status | check
# ASCII-only output on purpose: safe under Windows PowerShell 5.1 with any code page.

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:WHALE_HOME = $Root
if (-not $env:WHALE_LOG_DIR) { $env:WHALE_LOG_DIR = $Root }

# ---- optional local paths (see paths.example.json) ----
$cfgPath = Join-Path $Root "paths.json"
$cfg = @{}
if (Test-Path $cfgPath) {
  try {
    $raw = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $raw.PSObject.Properties | ForEach-Object { $cfg[$_.Name] = $_.Value }
  } catch {
    Write-Host "[whale] paths.json parse error, ignored: $($_.Exception.Message)"
  }
}

# point the python services at a local astrbot config copy when there is one
$localAstrbot = Join-Path $Root "astrbot.json"
if (-not $env:ASTRBOT_CONFIG) {
  if ($cfg.ContainsKey("astrbotConfig") -and $cfg["astrbotConfig"]) { $env:ASTRBOT_CONFIG = [string]$cfg["astrbotConfig"] }
  elseif (Test-Path $localAstrbot) { $env:ASTRBOT_CONFIG = $localAstrbot }
}
foreach ($k in @("WHALE_GSV_URL", "WHALE_REF_AUDIO", "WHALE_STT_MODEL_DIR")) {
  if ($cfg.ContainsKey($k) -and $cfg[$k]) { Set-Item -Path "env:$k" -Value ([string]$cfg[$k]) }
}

$SERVICES = @(
  @{ Name = "PEEK 32170"; Port = 32170; Script = "server\peek-analyzer.py" },
  @{ Name = "STT  32171"; Port = 32171; Script = "server\stt_server.py" },
  @{ Name = "TTS  32172"; Port = 32172; Script = "server\tts_server.py" },
  @{ Name = "VOICE 32173"; Port = 32173; Script = "server\voice-chat.py" }
)

function Get-WhalePython {
  $candidates = @()
  if ($cfg.ContainsKey("python") -and $cfg["python"]) { $candidates += [string]$cfg["python"] }
  if ($env:WHALE_PY) { $candidates += $env:WHALE_PY }
  $candidates += (Join-Path $Root "venv\Scripts\pythonw.exe")
  $candidates += (Join-Path $Root "tools\python\pythonw.exe")
  foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { return $c } }
  $found = Get-Command pythonw.exe -ErrorAction SilentlyContinue
  if ($found) { return $found.Source }
  return $null
}

function Get-PythonProcs {
  Get-CimInstance Win32_Process -Filter "Name like '%python%'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -like "*.py*" }
}

function Get-ScriptProcs([string]$script) {
  $leaf = Split-Path $script -Leaf
  Get-PythonProcs | Where-Object { $_.CommandLine -like "*$leaf*" }
}

function Get-ScriptInstances([string]$script) {
  # venv 的 pythonw.exe 是个转发壳，会再拉起真正的解释器（components\python\py312\pythonw.exe），
  # 所以每个服务天然是「壳 + 实体」两个进程。这里只数顶层壳，避免看起来重复。
  $procs = @(Get-ScriptProcs $script)
  if ($procs.Count -le 1) { return $procs }
  $ids = $procs | ForEach-Object { $_.ProcessId }
  return @($procs | Where-Object { $ids -notcontains $_.ParentProcessId })
}

function Test-Port([int]$port) {
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $iar = $client.BeginConnect("127.0.0.1", $port, $null, $null)
    if (-not $iar.AsyncWaitHandle.WaitOne(700)) { return $false }
    $client.EndConnect($iar)
    return $true
  } catch { return $false } finally { $client.Close() }
}

function Stop-Service([string]$script) {
  $procs = Get-ScriptProcs $script
  if (-not $procs) { return 0 }
  $n = 0
  foreach ($p in $procs) {
    try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; $n++ } catch {}
  }
  return $n
}

function Start-Detached([string]$exe, [string]$argsLine, [string]$cwd) {
  # WMI 创建：父进程是 WmiPrvSE，彻底脱离当前终端/任务作业，不会被 Ctrl+C 或会话结束带走
  try {
    $cmd = "`"$exe`" $argsLine"
    $res = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
      CommandLine      = $cmd
      CurrentDirectory = $cwd
    } -ErrorAction Stop
    if ($res.ReturnValue -eq 0) { return $true }
  } catch {}
  try {
    Start-Process -FilePath $exe -ArgumentList $argsLine -WorkingDirectory $cwd -WindowStyle Hidden | Out-Null
    return $true
  } catch { return $false }
}

function Start-One($svc, $python) {
  $port = $svc.Port
  $script = $svc.Script
  $killed = Stop-Service $script
  if ($killed -gt 0) {
    Write-Host ("[whale] {0}: cleaned {1} stale process(es)" -f $svc.Name, $killed)
    Start-Sleep -Milliseconds 400
  }
  if (Test-Port $port) {
    Write-Host ("[whale] {0}: port busy, skipped (someone else holds it)" -f $svc.Name)
    return
  }
  if (-not $python) {
    Write-Host ("[whale] {0}: no pythonw found. Put one in venv\Scripts or set python in paths.json" -f $svc.Name)
    return
  }
  $full = Join-Path $Root $script
  if (-not (Test-Path $full)) {
    Write-Host ("[whale] {0}: missing {1}" -f $svc.Name, $full)
    return
  }
  $ok = Start-Detached $python "`"$full`"" $Root
  if (-not $ok) { Write-Host ("[whale] {0}: launch failed" -f $svc.Name); return }
  for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Milliseconds 500
    if (Test-Port $port) { Write-Host ("[whale] {0}: up" -f $svc.Name); return }
  }
  Write-Host ("[whale] {0}: NOT listening after 30s, check the log in {1}" -f $svc.Name, $Root)
}

function Start-Gsv {
  if (Test-Port 9880) { Write-Host "[whale] GPT-SoVITS 9880: already up"; return }
  $dir = $null
  if ($cfg.ContainsKey("gsvDir") -and $cfg["gsvDir"]) { $dir = [string]$cfg["gsvDir"] }
  if (-not $dir) { Write-Host "[whale] GPT-SoVITS 9880: down (voice synthesis will fail; set gsvDir in paths.json)"; return }
  $runtime = Join-Path $dir "runtime\python.exe"
  if (-not (Test-Path $runtime)) { Write-Host "[whale] GPT-SoVITS: runtime\python.exe not found under $dir"; return }
  Push-Location $dir
  $null = Start-Detached $runtime "api_v2.py -a 127.0.0.1 -p 9880" $dir
  Pop-Location
  for ($i = 0; $i -lt 120; $i++) { Start-Sleep -Milliseconds 500; if (Test-Port 9880) { Write-Host "[whale] GPT-SoVITS 9880: up"; return } }
  Write-Host "[whale] GPT-SoVITS 9880: still loading or failed (first start can take a while)"
}

function Get-WidgetExe {
  # 开发目录是 release\WhaleDesktop\WhaleDesktop.exe，发布包是平铺的 WhaleDesktop.exe
  foreach ($c in @((Join-Path $Root "WhaleDesktop.exe"), (Join-Path $Root "release\WhaleDesktop\WhaleDesktop.exe"))) {
    if (Test-Path $c) { return $c }
  }
  return $null
}

function Start-Widget {
  $exe = Get-WidgetExe
  $running = Get-Process -Name WhaleDesktop -ErrorAction SilentlyContinue
  if ($running) { Write-Host "[whale] widget already running"; return }
  if ($exe) {
    $null = Start-Detached $exe "" $Root
    Write-Host "[whale] widget launched"
  } else {
    Write-Host "[whale] widget exe not found: $exe"
  }
}

function Show-Status {
  $python = Get-WhalePython
  Write-Host ("[whale] home   = {0}" -f $Root)
  Write-Host ("[whale] python = {0}" -f $(if ($python) { $python } else { "(not found)" }))
  foreach ($svc in $SERVICES) {
    $procs = Get-ScriptInstances $svc.Script
    $n = @($procs).Count
    $up = Test-Port $svc.Port
    $health = "-"
    if ($up) {
      try {
        $h = Invoke-RestMethod -Uri ("http://127.0.0.1:{0}/health" -f $svc.Port) -TimeoutSec 2
        $health = "ok"
      } catch { $health = "listening, /health not available" }
    }
    Write-Host ("[whale] {0}  procs={1}  port={2}  {3}" -f $svc.Name, $n, $(if ($up) { "open" } else { "closed" }), $health)
  }
  $gsv = if (Test-Port 9880) { "up" } else { "down" }
  $widget = if (Get-Process -Name WhaleDesktop -ErrorAction SilentlyContinue) { "running" } else { "stopped" }
  Write-Host ("[whale] GPT-SoVITS 9880 = {0}   widget = {1}" -f $gsv, $widget)
}

function Invoke-Check {
  Write-Host "[whale] ---- self check ----"
  $python = Get-WhalePython
  if ($python) {
    $exe = $python -replace "pythonw\.exe$", "python.exe"
    if (-not (Test-Path $exe)) { $exe = $python }
    $probe = @(
      "import faster_whisper, ctranslate2, av, numpy; print('stt deps ok:', faster_whisper.__version__, ctranslate2.__version__, av.__version__)",
      "import pyaudiowpatch; print('loopback ok')"
    )
    foreach ($code in $probe) {
      $out = & $exe -c $code 2>&1
      if ($LASTEXITCODE -eq 0) { Write-Host ("[whale] OK   " + ($out -join " ")) }
      else { Write-Host ("[whale] FAIL " + ($code.Split(';')[0]) + " -> " + (($out | Select-Object -First 1) -join "")) }
    }
  } else { Write-Host "[whale] FAIL no pythonw found" }

  $model = $env:WHALE_STT_MODEL_DIR
  if (-not $model) { $model = Join-Path $Root "models" }
  $snap = Get-ChildItem $model -Recurse -Filter "model.bin" -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($snap) { Write-Host ("[whale] OK   stt model: " + $snap.FullName) }
  else { Write-Host ("[whale] FAIL stt model missing under {0} (run fetch-models.ps1)" -f $model) }

  $ref = $env:WHALE_REF_AUDIO
  if (-not $ref) { $ref = Join-Path $Root "ref\ref.wav" }
  if (Test-Path -LiteralPath $ref) { Write-Host ("[whale] OK   ref audio: " + $ref) }
  else { Write-Host ("[whale] WARN ref audio missing: {0} (voice will fail)" -f $ref) }

  $ac = $env:ASTRBOT_CONFIG
  if ($ac -and (Test-Path -LiteralPath $ac)) { Write-Host ("[whale] OK   model config: " + $ac) }
  else { Write-Host "[whale] WARN no astrbot.json / ASTRBOT_CONFIG - peek analysis needs a model endpoint" }

  if (Test-Port 9880) { Write-Host "[whale] OK   GPT-SoVITS 9880 up" } else { Write-Host "[whale] WARN GPT-SoVITS 9880 down - no voice" }
  Show-Status
}

function Invoke-Start {
  $python = Get-WhalePython
  Write-Host ("[whale] home   = {0}" -f $Root)
  Write-Host ("[whale] python = {0}" -f $(if ($python) { $python } else { "(not found)" }))
  Start-Gsv
  foreach ($svc in $SERVICES) { Start-One $svc $python }
  if (-not $NoWidget) { Start-Widget }
  Write-Host "[whale] done. logs: tts.log / stt.log / peek-analyzer.log"
}

switch ($Action.ToLower()) {
  "start" { Invoke-Start }
  "stop" {
    foreach ($svc in $SERVICES) {
      $n = Stop-Service $svc.Script
      Write-Host ("[whale] {0}: stopped {1}" -f $svc.Name, $n)
    }
  }
  "restart" {
    foreach ($svc in $SERVICES) { $null = Stop-Service $svc.Script }
    Start-Sleep -Milliseconds 600
    Invoke-Start
  }
  "status" { Show-Status }
  "check" { Invoke-Check }
  "widget" { Start-Widget }
  default { Write-Host "usage: whale.ps1 start|stop|restart|status|check|widget [-NoWidget]" }
}
