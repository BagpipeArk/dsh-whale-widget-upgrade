// peek-widget.js —— 挂件上的「窥屏」眼睛按钮（挂在锁定小方框下面）
// 点一下：没开 → 弹出窗口选择器，选一个窗口开始窥屏；已开 → 关掉窥屏
// 开启后主进程每 10 秒抓一张那个窗口的画面，攒 45~90 秒一起交给 AI，AI 回话走气泡
(function () {
  if (window.__whalePeekBtn) return 'exists'
  window.__whalePeekBtn = true

  var STYLE_ID = 'dshwv-peek-style'
  var CSS = [
    '.dshwv-peekbtn{position:fixed;right:6px;top:calc(40.55% + 68px);width:26px;height:26px;padding:0;',
    'border:none;border-radius:6px;background:rgba(32,49,112,.72);color:#fff;cursor:pointer;',
    'display:flex;align-items:center;justify-content:center;z-index:500;pointer-events:auto;',
    'opacity:.42;transition:opacity .15s ease,background .15s ease,transform .15s ease}',
    '.dshwv-peekbtn:hover{opacity:1;background:#203170;transform:scale(1.06)}',
    '.dshwv-peekbtn.dshwv-peekbtn-on{opacity:1;background:rgba(74,132,214,.92)}',
    '.dshwv-peekbtn.dshwv-peekbtn-live{opacity:1;background:rgba(52,178,124,.95);animation:dshwv-peek-breathe 2.4s ease-in-out infinite}',
    '@keyframes dshwv-peek-breathe{0%,100%{box-shadow:0 0 0 0 rgba(52,178,124,.55)}50%{box-shadow:0 0 0 5px rgba(52,178,124,0)}}',
    '.dshwv-peekbtn svg{display:block;width:15px;height:15px}',
    '.dshwv-peekbtn-ghost{opacity:0 !important;pointer-events:none !important}'
  ].join('\n')

  var ICON_EYE =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12Z"/>' +
    '<circle cx="12" cy="12" r="2.6"/></svg>'
  var ICON_EYE_LIVE =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12Z"/>' +
    '<circle cx="12" cy="12" r="2.6" fill="currentColor"/></svg>'

  var state = { on: false, live: false, sourceName: '' }
  var locked = false
  var btn = null

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return
    var st = document.createElement('style')
    st.id = STYLE_ID
    st.textContent = CSS
    ;(document.head || document.documentElement).appendChild(st)
  }

  function label() {
    if (!state.on) return '窥屏：点一下先选要陪你看的窗口（只看那一个窗口，别的不看）'
    if (!state.live) return '窥屏已开启，正在等这个窗口的画面…（点一下关闭）'
    return '正在陪你看：' + (state.sourceName || '那个窗口') + '（10 秒一张，攒一会儿说一句；点一下关闭）'
  }

  function paint() {
    if (!btn) return
    var cls = 'dshwv-peekbtn'
    if (state.on && state.live) cls += ' dshwv-peekbtn-on dshwv-peekbtn-live'
    else if (state.on) cls += ' dshwv-peekbtn-on'
    if (locked) cls += ' dshwv-peekbtn-ghost'
    btn.className = cls
    btn.innerHTML = state.live ? ICON_EYE_LIVE : ICON_EYE
    btn.setAttribute('aria-pressed', state.on ? 'true' : 'false')
    btn.title = label()
  }

  function place() {
    if (!btn) return
    var lock = document.querySelector('.dshwv-lockbtn')
    if (lock) {
      var r = lock.getBoundingClientRect()
      if (r.width > 0 && r.height > 0) {
        btn.style.left = Math.round(r.left) + 'px'
        btn.style.top = Math.round(r.top + r.height + 6) + 'px'
        btn.style.right = 'auto'
        return
      }
    }
    btn.style.left = 'auto'
    btn.style.right = '6px'
    btn.style.top = 'calc(40.55% + 68px)'
  }

  function sync(st) {
    if (!st) return
    if ('on' in st) state.on = !!st.on
    if ('live' in st) state.live = !!st.live
    if ('sourceName' in st) state.sourceName = String(st.sourceName || '')
    paint()
  }

  function mount() {
    if (btn && btn.isConnected) return btn
    ensureStyle()
    var b = document.createElement('button')
    b.type = 'button'
    b.className = 'dshwv-peekbtn'
    b.addEventListener(
      'click',
      function (e) {
        e.preventDefault()
        e.stopPropagation()
        try {
          if (!window.whaleShell) return
          if (state.on) {
            if (window.whaleShell.setPeek) window.whaleShell.setPeek(false)
          } else if (window.whaleShell.pickPeekWindow) {
            window.whaleShell.pickPeekWindow()
          }
        } catch (err) {}
      },
      true
    )
    ;(document.body || document.documentElement).appendChild(b)
    btn = b
    paint()
    place()
    return b
  }

  mount()

  setInterval(function () {
    if (!btn || !btn.isConnected) mount()
    place()
  }, 800)

  try {
    if (window.whaleShell) {
      if (window.whaleShell.onPeekState) {
        window.whaleShell.onPeekState(function (st) {
          sync(st)
        })
      }
      if (window.whaleShell.onWindowState) {
        window.whaleShell.onWindowState(function (st) {
          locked = !!(st && st.lock)
          paint()
        })
      }
      if (window.whaleShell.getPeekState) {
        Promise.resolve(window.whaleShell.getPeekState())
          .then(function (st) {
            sync(st)
          })
          .catch(function () {})
      }
    }
  } catch (err) {}

  return 'ready'
})()
