// chat-widget.js —— 「聊天映射」在挂件侧的执行器
// 主进程负责收 HTTP（server/chat-bridge.mjs），这里负责把消息真正画到鲸鱼头顶。
const fs = require('node:fs')
const path = require('node:path')

function createChatWidget(opts) {
  const widgetEval = opts.widgetEval
  const flog = opts.flog || (() => {})
  let injected = false
  let lastError = ''

  async function inject() {
    let src = ''
    try {
      src = fs.readFileSync(path.join(__dirname, 'chat-inject.js'), 'utf8')
    } catch (err) {
      lastError = '注入脚本读取失败: ' + (err && err.message)
      return false
    }
    const r = await widgetEval(';(' + src + ')')
    injected = r === 'ready' || r === 'exists'
    if (!injected) lastError = '注入没有生效: ' + String(r)
    return injected
  }

  /** 把气泡外观配置推给页面（改了字号/时长要立刻生效） */
  async function applyCfg(bubbleCfg) {
    const c = bubbleCfg || {}
    const payload = {
      baseDuration: Number(c.baseDuration) > 0 ? Number(c.baseDuration) : 4000,
      perChar: Number(c.perChar) >= 0 ? Number(c.perChar) : 80,
      maxDuration: Number(c.maxDuration) > 0 ? Number(c.maxDuration) : 20000,
      maxChars: Number(c.maxChars) >= 0 ? Number(c.maxChars) : 0,
      showFrom: c.showFrom !== false,
      scale: Number(c.scale) > 0 ? Number(c.scale) : 1
    }
    await widgetEval('window.__whaleChat && window.__whaleChat.cfg(' + JSON.stringify(payload) + ')')
    return payload
  }

  /** 显示一条消息 */
  async function say(msg, bubbleCfg) {
    if (!msg || !String(msg.text || '').trim()) return false
    if (!injected) {
      const ok = await inject()
      if (!ok) {
        await new Promise((r0) => setTimeout(r0, 400))
      }
    }
    if (bubbleCfg) await applyCfg(bubbleCfg)
    const payload = {
      text: String(msg.text),
      from: msg.from ? String(msg.from) : '',
      duration: Number(msg.duration) > 0 ? Number(msg.duration) : 0
    }
    const call = () =>
      widgetEval('window.__whaleChat ? window.__whaleChat.push(' + JSON.stringify(payload) + ') : "no-layer"')
    // 气泡挂在挂件自己的 DOM 上：刚启动那会儿可能还没建好，给它几次机会
    for (let i = 0; i < 4; i++) {
      if (!injected) {
        const ok = await inject()
        if (!ok) {
          await new Promise((r1) => setTimeout(r1, 400))
          continue
        }
      }
      const r = await call()
      if (r === 'ok') return true
      lastError = '气泡没有画出来: ' + String(r)
      if (r === 'no-dom' || r === 'no-layer') {
        injected = false
        await new Promise((r2) => setTimeout(r2, 350))
        continue
      }
      flog('[chat] ' + lastError)
      return false
    }
    flog('[chat] ' + lastError)
    return false
  }

  async function clear() {
    await widgetEval('window.__whaleChat && window.__whaleChat.clear()')
    return true
  }

  async function state() {
    const s = await widgetEval('window.__whaleChat ? window.__whaleChat.state() : ""')
    if (!s) return null
    try {
      return JSON.parse(s)
    } catch (err) {
      return null
    }
  }

  return {
    inject,
    applyCfg,
    say,
    clear,
    state,
    isInjected: () => injected,
    lastError: () => lastError
  }
}

module.exports = { createChatWidget }
