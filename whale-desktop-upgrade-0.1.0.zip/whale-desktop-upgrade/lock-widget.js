// lock-widget.js —— 挂件上的「锁定」小方框（像音乐软件的歌词锁定）
// 点一下：锁定 → 整窗鼠标穿透，怎么点都碰不到挂件；再点一下（或者在控制中心/托盘解锁）恢复
(function () {
  if (window.__whaleLockBtn) return 'exists'
  window.__whaleLockBtn = true

  var STYLE_ID = 'dshwv-lock-style'
  var CSS = [
    '.dshwv-lockbtn{position:fixed;right:6px;top:calc(40.55% + 38px);width:26px;height:26px;padding:0;',
    'border:none;border-radius:6px;background:rgba(32,49,112,.72);color:#fff;cursor:pointer;',
    'display:flex;align-items:center;justify-content:center;z-index:500;pointer-events:auto;',
    'opacity:.42;transition:opacity .15s ease,background .15s ease,transform .15s ease}',
    '.dshwv-lockbtn:hover{opacity:1;background:#203170;transform:scale(1.06)}',
    '.dshwv-lockbtn.dshwv-lockbtn-on{opacity:1;background:rgba(214,138,32,.92)}',
    '.dshwv-lockbtn svg{display:block;width:15px;height:15px}',
    '.dshwv-lockbtn .dshwv-lockbox{display:flex;width:100%;height:100%;align-items:center;',
    'justify-content:center;border-radius:6px;box-shadow:inset 0 0 0 2px rgba(255,255,255,.5)}',
    '.dshwv-lockbtn-on .dshwv-lockbox{box-shadow:inset 0 0 0 2px rgba(255,255,255,.92)}',
    '.dshwv-lockbtn-ghost{opacity:0 !important;pointer-events:none !important}'
  ].join('\n')

  var ICON_OFF =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="5" y="11" width="14" height="9" rx="2"/>' +
    '<path d="M8.5 11V7.6a3.5 3.5 0 0 1 6.7-1.4"/></svg>'
  var ICON_ON =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
    '<rect x="5" y="11" width="14" height="9" rx="2" fill="currentColor" fill-opacity=".28"/>' +
    '<path d="M8.5 11V7.6a3.5 3.5 0 0 1 7 0V11"/></svg>'

  var locked = false
  var btn = null

  function ensureStyle() {
    if (document.getElementById(STYLE_ID)) return
    var st = document.createElement('style')
    st.id = STYLE_ID
    st.textContent = CSS
    ;(document.head || document.documentElement).appendChild(st)
  }

  function paint() {
    if (!btn) return
    // 锁定后页面自己点不到了：方框变透明，由主进程那颗真正能点的小锁顶上它的位置
    btn.className = 'dshwv-lockbtn' + (locked ? ' dshwv-lockbtn-on dshwv-lockbtn-ghost' : '')
    btn.innerHTML = '<span class="dshwv-lockbox">' + (locked ? ICON_ON : ICON_OFF) + '</span>'
    btn.setAttribute('aria-pressed', locked ? 'true' : 'false')
    btn.title = locked
      ? '已锁定：鼠标只有落在这一小块上才点得到，再点一下就解锁（控制中心「其他 → 窗口与吸附」或托盘菜单也能解锁）'
      : '锁定：锁定后鼠标怎么点都碰不到挂件，只有这颗小方框还能点开'
  }

  function place() {
    if (!btn) return
    var m = document.querySelector('.dshwv-menu-btn')
    if (m) {
      var r = m.getBoundingClientRect()
      if (r.width > 0 && r.height > 0) {
        btn.style.left = Math.round(r.left) + 'px'
        btn.style.top = Math.round(r.top + r.height + 6) + 'px'
        btn.style.right = 'auto'
        report()
        return
      }
    }
    btn.style.left = 'auto'
    btn.style.right = '6px'
    btn.style.top = 'calc(40.55% + 38px)'
    report()
  }

  // 把方框位置报给主进程：锁定后它要在同一个地方浮一颗能点的小锁
  var lastRect = ''
  function report() {
    if (!btn || !btn.isConnected) return
    try {
      var r = btn.getBoundingClientRect()
      if (!r || r.width <= 0 || r.height <= 0) return
      var sig = Math.round(r.left) + ',' + Math.round(r.top) + ',' + Math.round(r.width)
      if (sig === lastRect) return
      lastRect = sig
      if (window.whaleShell && window.whaleShell.reportLockRect) {
        window.whaleShell.reportLockRect({
          x: r.left,
          y: r.top,
          w: r.width,
          h: r.height
        })
      }
    } catch (err) {}
  }

  function sync(st) {
    locked = !!(st && st.lock)
    paint()
  }

  function mount() {
    if (btn && btn.isConnected) return btn
    ensureStyle()
    var b = document.createElement('button')
    b.type = 'button'
    b.className = 'dshwv-lockbtn'
    b.addEventListener(
      'click',
      function (e) {
        e.preventDefault()
        e.stopPropagation()
        // 先画好再通知主进程：锁定的瞬间整窗就穿透了，来不及再改样式
        var next = !locked
        sync({ lock: next })
        try {
          if (window.whaleShell && window.whaleShell.setLock) window.whaleShell.setLock(next)
        } catch (err) {}
      },
      true
    )
    ;(document.body || document.documentElement).appendChild(b)
    btn = b
    paint()
    place()
    return b
  }

  mount()

  // 窗口/挂件位置会变（吸附、缩放），按钮跟着菜单按钮走
  setInterval(function () {
    if (!btn || !btn.isConnected) mount()
    place()
  }, 800)

  // 主进程是唯一真相：控制中心、托盘改了状态这边也跟着变
  try {
    if (window.whaleShell && window.whaleShell.onWindowState) {
      window.whaleShell.onWindowState(function (st) {
        sync(st)
      })
    }
  } catch (err) {}

  return 'ready'
})()
