(function () {
  if (window.__whaleFly) return 'exists'
  var S = {
    active: false,
    phase: null,
    root: null,
    img: null,
    baseTf: '',
    baseInlineTf: '',
    origTransition: '',
    origSrc: '',
    origImgStyle: '',
    x: 0,
    y: 0,
    tx: 0,
    ty: 0,
    hx: 0,
    hy: 0,
    limL: 0,
    limT: 0,
    limR: 0,
    limB: 0,
    speed: 250,
    retFast: 700,
    retSlow: 260,
    bob: 10,
    bobT: 0,
    bobAmt: 0,
    raf: 0,
    last: 0,
    nextTargetAt: 0,
    fast: false,
    flyScale: 0.85, // 飞行时缩小一圈：窗口尺寸贴着鲸鱼，放大就会被裁边
    err: ''
  }

  function put(v, a, b) {
    return v < a ? a : v > b ? b : v
  }

  function dist() {
    var dx = S.tx - S.x
    var dy = S.ty - S.y
    return Math.sqrt(dx * dx + dy * dy)
  }

  function paint() {
    if (!S.root) return
    S.root.style.transform =
      S.baseTf + ' translate3d(' + S.x.toFixed(1) + 'px,' + (S.y + S.bobAmt).toFixed(1) + 'px,0)'
  }

  function pickTarget(now) {
    S.tx = put(Math.random() * (S.limR - S.limL) + S.limL, S.limL, S.limR)
    S.ty = put(Math.random() * (S.limB - S.limT) + S.limT, S.limT, S.limB)
    S.nextTargetAt = now + 1400 + Math.random() * 1400
  }

  function step(dt, sp) {
    var dx = S.tx - S.x
    var dy = S.ty - S.y
    var d = Math.sqrt(dx * dx + dy * dy)
    if (d < 0.5) return
    var v = Math.min(d, sp * dt)
    S.x += (dx / d) * v
    S.y += (dy / d) * v
  }

  function restore() {
    try {
      if (S.img) {
        if (S.origImgStyle) S.img.setAttribute('style', S.origImgStyle)
        else S.img.removeAttribute('style')
        if (S.origSrc != null) S.img.setAttribute('src', S.origSrc)
      }
    } catch (e) {}
    try {
      if (S.root) {
        S.root.style.transform = S.baseInlineTf
        S.root.style.transition = S.origTransition
      }
    } catch (e) {}
  }

  function frame(now) {
    if (!S.active) return
    var dt = S.last ? Math.min(0.05, (now - S.last) / 1000) : 0.016
    S.last = now
    if (S.phase === 'fly') {
      if (now >= S.nextTargetAt || dist() < 20) pickTarget(now)
      step(dt, S.speed)
      S.bobT += dt * 3.0
      S.bobAmt = Math.sin(S.bobT) * S.bob
    } else if (S.phase === 'return') {
      S.tx = S.hx
      S.ty = S.hy
      S.bobAmt = 0
      var sp = S.fast ? S.retFast : S.retSlow
      if (dist() <= sp * dt + 1) {
        S.x = S.hx
        S.y = S.hy
        S.phase = 'done'
        S.active = false
        paint()
        restore()
        return
      }
      step(dt, sp)
    }
    paint()
    S.raf = requestAnimationFrame(frame)
  }

  window.__whaleFly = {
    start: function (url, opt) {
      try {
        if (S.active) return 'busy'
        var root = document.querySelector('.dshwv-root')
        var img = root && (root.querySelector('img') || document.querySelector('.dshwv-img'))
        if (!root || !img) return 'no-dom'
        var r = root.getBoundingClientRect()
        var vw = window.innerWidth
        var vh = window.innerHeight
        S.root = root
        S.img = img
        S.baseInlineTf = root.style.transform || ''
        // 用计算后的 transform（含 .dshwv-left 的 scaleX(-1)），逐帧改写时才不会丢掉朝向
        try {
          var cs = getComputedStyle(root)
          S.baseTf = cs && cs.transform && cs.transform !== 'none' ? cs.transform : S.baseInlineTf
        } catch (e) {
          S.baseTf = S.baseInlineTf
        }
        // 飞行是逐帧 transform，CSS 的 transition .3s 会让画面滞后，飞行期间关掉
        S.origTransition = root.style.transition || ''
        root.style.transition = 'none'
        S.origSrc = img.getAttribute('src')
        S.origImgStyle = img.getAttribute('style') || ''
        var ir = img.getBoundingClientRect()
        var fw = Math.round((ir.width || r.width) * S.flyScale)
        var fh = Math.round((ir.height || r.height) * S.flyScale)
        // 安全钳：飞行图绝不能超出窗口，否则边缘会被裁掉
        var maxW = Math.max(32, vw - 8)
        var maxH = Math.max(32, vh - 8)
        if (fw > maxW) { fh = Math.round(fh * maxW / fw); fw = maxW }
        if (fh > maxH) { fw = Math.round(fw * maxH / fh); fh = maxH }
        img.style.width = fw + 'px'
        img.style.height = fh + 'px'
        img.style.maxWidth = 'none'
        img.style.objectFit = 'contain'
        img.style.transformOrigin = 'center center'
        img.setAttribute('src', url || window.__whaleFlyGif)
        // 命中遮罩（clip-path 凸包）是按「当前角色图」算的，飞行图是另一张、
        // 内容更满，套上去会把头顶/翅膀裁掉一块。飞行期间先松开，restore() 会
        // 用 S.origImgStyle 整体还原（含 clip-path）。
        img.style.clipPath = 'none'
        img.style.webkitClipPath = 'none'
        S.limL = -r.left + 8
        S.limR = vw - r.right - 8
        S.limT = -r.top + 8
        S.limB = vh - r.bottom - 8
        if (S.limR < S.limL) {
          var m = (S.limL + S.limR) / 2
          S.limL = m
          S.limR = m
        }
        if (S.limB < S.limT) {
          var m2 = (S.limT + S.limB) / 2
          S.limT = m2
          S.limB = m2
        }
        if (opt && opt.speed) S.speed = opt.speed
        S.x = 0
        S.y = 0
        S.hx = 0
        S.hy = 0
        S.bobT = 0
        S.bobAmt = 0
        S.fast = false
        S.last = 0
        S.nextTargetAt = 0
        S.phase = 'fly'
        S.active = true
        S.err = ''
        paint()
        if (S.raf) cancelAnimationFrame(S.raf)
        S.raf = requestAnimationFrame(frame)
        return 'ok'
      } catch (e) {
        S.err = String((e && e.message) || e)
        return 'err:' + S.err
      }
    },
    home: function (fast) {
      if (!S.active || S.phase !== 'fly') return 'idle'
      S.phase = 'return'
      S.fast = !!fast
      return 'ok'
    },
    state: function () {
      return JSON.stringify({
        phase: S.phase,
        active: S.active,
        x: Math.round(S.x),
        y: Math.round(S.y),
        err: S.err
      })
    },
    stop: function () {
      S.active = false
      if (S.raf) cancelAnimationFrame(S.raf)
      S.raf = 0
      S.phase = null
      restore()
      return 'ok'
    }
  }
  return 'ready'
})()
