﻿param(
  [string]$HostDir = "",
  [switch]$SkipInstall,
  [switch]$Check
)

# 鲸鱼娘 · 桌面增强升级包 —— 安装 / 自检
# 依附已装的鲸鱼娘本体运行：本包不带 exe，挂件本体（vendor\whale-widget）从本体目录里取。
#
#   powershell -ExecutionPolicy Bypass -File install.ps1
#   powershell -ExecutionPolicy Bypass -File install.ps1 -HostDir "D:\WhaleDesktop"
#   powershell -ExecutionPolicy Bypass -File install.ps1 -Check        # 只自检，不动文件
#   powershell -ExecutionPolicy Bypass -File install.ps1 -SkipInstall  # 不跑 npm install

$ErrorActionPreference = 'Stop'
Set-Location -Path $PSScriptRoot

$script:bad = 0
function Say([string]$t, [string]$c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Ok([string]$t) { Say ('  [OK]   ' + $t) 'Green' }
function Tip([string]$t) { Say ('  [注意] ' + $t) 'Yellow' }
function Bad([string]$t) { Say ('  [缺失] ' + $t) 'Red'; $script:bad++ }

Say '===== 鲸鱼娘 · 桌面增强升级包 =====' 'Cyan'
Say ('包目录：' + $PSScriptRoot)
Say '依附本体运行：本包不含 exe，挂件本体与图标从已装的鲸鱼娘目录里取。'
Say ''

# ---------- 1. Node ----------
# 优先找 node.exe 本体：某些环境 PATH 里只有 node.ps1 / node.cmd 之类的转发壳，
# 那些壳在中文用户名的机器上容易因为编码问题直接失败。
$nodeCmd = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $nodeCmd) { $nodeCmd = Get-Command node -ErrorAction SilentlyContinue }
$nodeExe = ''
$nodeVer = ''
if ($nodeCmd) {
  $nodeExe = [string]$nodeCmd.Source
  try { $nodeVer = [string]((& $nodeExe -v 2>$null) -join '') } catch { $nodeVer = '' }
}
if ($nodeVer) { Ok ('Node ' + $nodeVer) } else { Bad 'Node 跑不起来，请装 Node.js 18+（https://nodejs.org）' }

# ---------- 2. 找已装的本体 ----------
function Test-AppDir([string]$dir) {
  if (-not $dir) { return $false }
  try {
    if (-not (Test-Path -LiteralPath (Join-Path $dir 'main.js'))) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $dir 'vendor\whale-widget\assets\whale-widget.js'))) { return $false }
    return $true
  } catch { return $false }
}

function Get-ShortcutTargets {
  $out = @()
  try {
    $ws = New-Object -ComObject WScript.Shell
    foreach ($d in @((Join-Path $env:USERPROFILE 'Desktop'), (Join-Path $env:PUBLIC 'Desktop'))) {
      if (-not (Test-Path -LiteralPath $d)) { continue }
      foreach ($f in (Get-ChildItem -LiteralPath $d -Filter '*.lnk' -ErrorAction SilentlyContinue)) {
        try {
          $t = $ws.CreateShortcut($f.FullName).TargetPath
          if ($t -and ($t -match '(?i)whale')) { $out += $t }
        } catch {}
      }
    }
  } catch {}
  return $out
}

function Find-AppDir {
  $cands = New-Object System.Collections.ArrayList
  if ($HostDir) { [void]$cands.Add($HostDir) }
  if ($env:WHALE_HOST_DIR) { [void]$cands.Add($env:WHALE_HOST_DIR) }
  foreach ($p in (Get-Process WhaleDesktop -ErrorAction SilentlyContinue | Select-Object -First 1)) {
    if ($p.Path) { [void]$cands.Add((Split-Path -Parent $p.Path)) }
  }
  foreach ($t in (Get-ShortcutTargets)) { [void]$cands.Add((Split-Path -Parent $t)) }
  $parent = Split-Path -Parent $PSScriptRoot
  foreach ($guess in @(
      (Join-Path $parent 'WhaleDesktop-0.1.0-win-x64'),
      (Join-Path $env:LOCALAPPDATA 'Programs\WhaleDesktop'),
      (Join-Path $env:ProgramFiles 'WhaleDesktop'),
      'D:\WhaleDesktop\release\WhaleDesktop',
      'D:\WhaleDesktop'
    )) { [void]$cands.Add($guess) }
  try {
    foreach ($d in (Get-ChildItem -LiteralPath $parent -Directory -Filter 'WhaleDesktop*' -ErrorAction SilentlyContinue)) {
      [void]$cands.Add($d.FullName)
    }
  } catch {}

  $tried = @()
  foreach ($c in $cands) {
    if (-not $c) { continue }
    $c = [string]$c
    if (-not (Test-Path -LiteralPath $c)) { continue }
    foreach ($probe in @($c, (Join-Path $c 'resources\app'))) {
      if ($tried -contains $probe) { continue }
      $tried += $probe
      if (Test-AppDir $probe) { return $probe }
    }
  }
  return ''
}

$appDir = Find-AppDir
$hostRoot = ''
if ($appDir) {
  Ok ('找到本体：' + $appDir)
  $hostRoot = Split-Path -Parent (Split-Path -Parent $appDir)
} else {
  Bad '没找到已装的鲸鱼娘本体（判定条件：有 main.js 且有 vendor\whale-widget\assets\whale-widget.js）'
  Say '       先装完整版 WhaleDesktop，或用参数指定：install.ps1 -HostDir "D:\WhaleDesktop"' 'Yellow'
}

# ---------- 3. 取挂件本体 ----------
$vendorDst = Join-Path $PSScriptRoot 'vendor\whale-widget'
$vendorSrc = ''
if ($appDir) { $vendorSrc = Join-Path $appDir 'vendor\whale-widget' }
if (($vendorSrc -ne '') -and (Test-Path -LiteralPath $vendorSrc)) {
  if ($Check) {
    Ok ('挂件本体可取自：' + $vendorSrc)
  } else {
    if (Test-Path -LiteralPath $vendorDst) { Remove-Item -LiteralPath $vendorDst -Recurse -Force }
    New-Item -ItemType Directory -Path (Split-Path -Parent $vendorDst) -Force | Out-Null
    Copy-Item -LiteralPath $vendorSrc -Destination $vendorDst -Recurse -Force
    Ok '挂件本体已镜像到 vendor\whale-widget（本体目录一个字节都不动）'
  }
} elseif (-not $Check) {
  Tip '取不到挂件本体：程序能起，但没有鲸鱼本体'
}

# ---------- 4. koffi（窗口置底用的原生模块） ----------
$koffiDst = Join-Path $PSScriptRoot 'node_modules\koffi'
if (-not (Test-Path -LiteralPath (Join-Path $koffiDst 'package.json'))) {
  $koffiSrc = ''
  foreach ($c in @((Join-Path $appDir 'node_modules\koffi'), (Join-Path $hostRoot 'node_modules\koffi'))) {
    if ($c -and (Test-Path -LiteralPath (Join-Path $c 'package.json'))) { $koffiSrc = $c; break }
  }
  if (($koffiSrc -ne '') -and (-not $Check)) {
    New-Item -ItemType Directory -Path (Split-Path -Parent $koffiDst) -Force | Out-Null
    if (Test-Path -LiteralPath $koffiDst) { Remove-Item -LiteralPath $koffiDst -Recurse -Force }
    Copy-Item -LiteralPath $koffiSrc -Destination $koffiDst -Recurse -Force
    Ok ('koffi 取自本体：' + $koffiSrc)
  }
}

# ---------- 5. paths.json（语音服务复用本体的 python / 模型 / 音色） ----------
$pathsFile = Join-Path $PSScriptRoot 'paths.json'
if (Test-Path -LiteralPath $pathsFile) {
  Tip '已有 paths.json，保留不动'
} elseif ((-not $Check) -and $hostRoot) {
  $pyw = Join-Path $hostRoot 'venv\Scripts\pythonw.exe'
  $modelDir = Join-Path $hostRoot 'models'
  $refWav = Join-Path $hostRoot 'ref\ref.wav'
  $cfg = [ordered]@{
    '_说明' = '由 install.ps1 生成：语音服务默认复用本体的 python / 模型 / 音色；想独立就改成自己的路径。'
    'python' = $(if (Test-Path -LiteralPath $pyw) { $pyw } else { '' })
    'astrbotConfig' = ''
    'gsvDir' = ''
    'WHALE_GSV_URL' = ''
    'WHALE_REF_AUDIO' = $(if (Test-Path -LiteralPath $refWav) { $refWav } else { '' })
    'WHALE_STT_MODEL_DIR' = $(if (Test-Path -LiteralPath $modelDir) { $modelDir } else { '' })
    'voiceHotkey' = '`'
  }
  ($cfg | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $pathsFile -Encoding UTF8
  Ok ('paths.json 已生成（指向本体 ' + $hostRoot + '）')
}

# ---------- 6. 挂件补丁（独立桌面版必需） ----------
$vendorFile = Join-Path $vendorDst 'assets\whale-widget.js'
if ((-not $Check) -and $nodeCmd -and (Test-Path -LiteralPath $vendorFile)) {
  Say '-- 打挂件补丁 --' 'Cyan'
  $patchOk = $false
  try {
    & $nodeExe (Join-Path $PSScriptRoot 'server\patch-vendor.mjs')
    $patchOk = ($LASTEXITCODE -eq 0)
  } catch { $patchOk = $false }
  if ($patchOk) { Ok '补丁完成（自检闸门 + 点击形变）' } else { Tip '补丁没打上，界面可能一直不显示鲸鱼' }
}

# ---------- 7. 依赖 ----------
if ($Check) {
  Say '（-Check：跳过 npm install）' 'Gray'
} elseif ($SkipInstall) {
  Tip '跳过 npm install（-SkipInstall）'
} else {
  $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
  if (-not $npm) { $npm = Get-Command npm -ErrorAction SilentlyContinue }
  if (-not $npm) {
    Bad '没有 npm（装 Node.js 时自带），无法安装 electron'
  } else {
    Say '-- 安装 electron / koffi（首次约 100MB+，耐心等） --' 'Cyan'
    $npmOk = $false
    try {
      & $npm.Source install --no-audit --no-fund
      $npmOk = ($LASTEXITCODE -eq 0)
    } catch { $npmOk = $false }
    if ($npmOk) { Ok '依赖安装完成' } else { Bad '依赖安装失败，检查网络后重试' }
  }
}

# ---------- 8. 自检 ----------
Say ''
Say '-- 自检 --' 'Cyan'
if ($nodeCmd) { Ok 'node 可用' } else { Bad 'node 不可用' }
if (Test-Path -LiteralPath $vendorFile) {
  Ok 'vendor\whale-widget 就绪'
} elseif ($Check -and $vendorSrc -and (Test-Path -LiteralPath $vendorSrc)) {
  Ok 'vendor\whale-widget 将在正式安装时从本体镜像'
} else {
  Bad 'vendor\whale-widget 缺失（先装本体，再用 -HostDir 指一下）'
}
if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'node_modules\electron\dist\electron.exe')) {
  Ok 'electron 已安装'
} else { Tip 'electron 未安装（npm install 会装；start.cmd 首次也会自动装）' }
if (Test-Path -LiteralPath (Join-Path $koffiDst 'package.json')) { Ok 'koffi 就绪（窗口置底可用）' } else { Tip 'koffi 缺失：窗口置底退化，其它功能照常' }

$pywPath = ''
if (Test-Path -LiteralPath $pathsFile) {
  try { $pywPath = [string]((Get-Content -LiteralPath $pathsFile -Raw -Encoding UTF8) | ConvertFrom-Json).python } catch {}
}
if ((-not $pywPath) -and $hostRoot) { $pywPath = Join-Path $hostRoot 'venv\Scripts\pythonw.exe' }
if ($pywPath -and (Test-Path -LiteralPath $pywPath)) {
  Ok ('python 运行时：' + $pywPath)
} elseif ($hostRoot -and (Test-Path -LiteralPath (Join-Path $hostRoot 'venv\Scripts\pythonw.exe'))) {
  Ok ('python 运行时将从本体的 venv 复用：' + (Join-Path $hostRoot 'venv\Scripts\pythonw.exe'))
} else {
  Tip '没有可用的 python 运行时：语音识别 / 朗读 / 窥屏 / 语音聊天起不来（气泡界面仍可跑）'
}

$modelHint = ''
if (Test-Path -LiteralPath $pathsFile) {
  try { $modelHint = [string]((Get-Content -LiteralPath $pathsFile -Raw -Encoding UTF8) | ConvertFrom-Json).WHALE_STT_MODEL_DIR } catch {}
}
if ($modelHint -and (Test-Path -LiteralPath $modelHint)) {
  Ok ('识别模型目录：' + $modelHint)
} elseif ($hostRoot -and (Test-Path -LiteralPath (Join-Path $hostRoot 'models'))) {
  Ok ('识别模型将从本体的 models 复用')
} else {
  Tip '识别模型缺失：听电脑说话 / 语音聊天不可用（fetch-models.ps1 或复用本体 models）'
}

$port = 32168
$busy = $false
try {
  $client = New-Object System.Net.Sockets.TcpClient
  $iar = $client.BeginConnect('127.0.0.1', $port, $null, $null)
  if ($iar.AsyncWaitHandle.WaitOne(600)) { $client.EndConnect($iar); $busy = $true }
  $client.Close()
} catch {}
if ($busy) { Tip ('端口 ' + $port + ' 已被占用（可能已经有一个实例在跑）') } else { Ok ('端口 ' + $port + ' 空闲') }

# ---------- 9. 结论 ----------
Say ''
if ($script:bad -gt 0) {
  Say ('有 ' + $script:bad + ' 项必须处理（见上面的 [缺失]）。') 'Yellow'
} else {
  Say '就绪。启动：双击 start.cmd，或在本目录执行 npm start' 'Green'
}
if (-not $Check) {
  Say 'start.cmd 会先拉起本地 python 服务，再打开 electron 界面。' 'Gray'
}
