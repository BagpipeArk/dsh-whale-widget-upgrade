// settings-preload.js —— 设置窗口专用（和挂件的穿透 preload 分开，避免互相干扰）
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('whaleSettings', {
  accountStatus: () => ipcRenderer.invoke('whale-settings:status'),
  refresh: () => ipcRenderer.invoke('whale-settings:refresh'),
  saveToken: (token) => ipcRenderer.invoke('whale-settings:save-token', token),
  clearToken: () => ipcRenderer.invoke('whale-settings:clear-token'),
  getAutostart: () => ipcRenderer.invoke('whale-settings:get-autostart'),
  setAutostart: (flag) => ipcRenderer.invoke('whale-settings:set-autostart', flag),
})
