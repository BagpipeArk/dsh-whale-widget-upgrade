﻿# 小鲸鱼 · 桌面增强升级包 —— 安装 / 自检
# 依附原插件 dsh-whale-widget 运行；脚本只做检查与依赖安装，不动原插件。
param(
  [string]$PluginDir = "",
  [switch]$SkipInstall
)

$ErrorActionPreference = 'Stop'
Set-Location -Path $PSScriptRoot

function Say($text, $color = 'Gray') { Write-Host $text -ForegroundColor $color }

Say "===== 小鲸鱼 · 桌面增强升级包 =====" Cyan
Say "目录：$PSScriptRoot"

# 1) Node
$nodeCmd = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCmd) {
  Say "没有找到 node，请先安装 Node.js 18 或更高版本。" Red
  exit 1
}
Say ("Node：" + (& node -v))

# 2) 原插件目录（可选）
if ($PluginDir -ne "") {
  $resolved = Resolve-Path -Path $PluginDir -ErrorAction SilentlyContinue
  if (-not $resolved) { Say "指定的原插件目录不存在：$PluginDir" Red; exit 1 }
  $env:WHALE_PLUGIN_DIR = $resolved.Path
  Say "原插件目录（手动指定）：$($env:WHALE_PLUGIN_DIR)" Gray
}

# 3) 首次自检：确认原插件能被找到
Write-Host ""
Say "-- 环境自检 --" Cyan
& node server/doctor.mjs
$doctorOk = ($LASTEXITCODE -eq 0)

# 4) 依赖
if (-not $SkipInstall) {
  Write-Host ""
  Say "-- 安装依赖（electron / koffi） --" Cyan
  $npmCmd = Get-Command npm.cmd -ErrorAction SilentlyContinue
  if (-not $npmCmd) { $npmCmd = Get-Command npm -ErrorAction SilentlyContinue }
  if (-not $npmCmd) {
    Say "没有找到 npm，跳过依赖安装。请自行安装 electron 与 koffi 后重试。" Yellow
  } else {
    & $npmCmd.Source install --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { Say "依赖安装失败，请检查网络后重试。" Red; exit 1 }
  }
  Write-Host ""
  Say "-- 安装后再检一次 --" Cyan
  & node server/doctor.mjs
  $doctorOk = ($LASTEXITCODE -eq 0)
}

Write-Host ""
if ($doctorOk) {
  Say "就绪。启动方式：" Green
  Say "  1) npm start" Gray
  Say "  2) 或双击 start.cmd" Gray
} else {
  Say "还有需要注意的项目，见上面自检结果。" Yellow
  Say "如果提示原插件缺失：先装原插件，或用 -PluginDir 指定它的目录。" Gray
}
