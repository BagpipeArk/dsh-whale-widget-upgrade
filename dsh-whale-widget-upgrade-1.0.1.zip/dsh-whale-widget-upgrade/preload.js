// preload.js —— 鼠标穿透的命门：只有指针真的落在鲸鱼/泡泡/菜单上时，窗口才接住鼠标
const { ipcRenderer, contextBridge } = require('electron')

// 挂件里的"三条杠"按钮改成直接开控制中心（旧的微缩菜单已废弃）
try {
  contextBridge.exposeInMainWorld('whaleShell', {
    openControl: (tab) => ipcRenderer.send('whale:open-control', tab || ''),
  })
} catch (err) {}

let ignoring = true // true = 整窗穿透，鼠标事件交给下面的窗口/桌面

function isWidgetElement(el) {
  let node = el
  for (let depth = 0; node && depth < 14; depth++) {
    const cls = typeof node.className === 'string' ? node.className : node.getAttribute && (node.getAttribute('class') || '')
    if (cls && String(cls).indexOf('dshwv') >= 0) return true
    if (node.id && String(node.id).indexOf('dshwv') >= 0) return true
    node = node.parentElement
  }
  return false
}

function setIgnore(next) {
  if (next === ignoring) return
  ignoring = next
  try {
    ipcRenderer.send('whale:set-ignore', ignoring)
  } catch (err) {}
}

window.addEventListener(
  'mousemove',
  (e) => {
    let hot = false
    try {
      const el = document.elementFromPoint(e.clientX, e.clientY)
      hot = isWidgetElement(el)
    } catch (err) {}
    setIgnore(!hot)
  },
  { passive: true }
)

// 指针离开文档（例如飞出屏幕边缘）时恢复穿透，避免窗口一直拦着鼠标
window.addEventListener('mouseleave', () => setIgnore(true))
window.addEventListener('blur', () => setIgnore(true))

// 子元素抢走 mousemove 时兜底：指针彻底离开页面
document.addEventListener(
  'mousemove',
  (e) => {
    if (e.target === document.documentElement || e.target === document.body) setIgnore(true)
  },
  { passive: true }
)
