﻿@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo 没找到 node，请先安装 Node.js 18+ & pause & exit /b 1)
if not exist "node_modules\electron" (
  echo 首次启动，正在安装依赖...
  call npm install --no-audit --no-fund || (echo 依赖安装失败 & pause & exit /b 1)
)
start "" "node_modules\electron\dist\electron.exe" .
