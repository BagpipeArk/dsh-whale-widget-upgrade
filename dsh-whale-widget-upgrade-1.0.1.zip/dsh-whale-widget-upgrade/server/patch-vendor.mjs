// patch-vendor.mjs —— 对上游 widget.js 做两处「外部够不着、只能改源码」的补丁
//
// ① 自检闸门：[standalone-patch]
//    assets/whale-widget.js 启动时会探测 #root 里是否存在 DSH composer 输入区，
//    探测不到就无限等待、一行 DOM 都不碰 —— 独立窗口里没有 DSH 界面，于是永远不出现。
//    做法：把 dshwIsChatRoot() 改成直接返回 true。
//
// ② 点击形变：[click-tap-patch]
//    出厂的按压形变写死成 SQUISH = 'scaleY(0.88) scaleX(1.05)'，而 SQUISH 在 IIFE 闭包里，
//    外部拿不到（实测 typeof 全 undefined）。控制中心要能调「点击的运动幅度」，
//    所以把**读取处**改成走一个外部可写的钩子：window.__whaleTap = { on, amp }。
//
// ⚠️ 升级包里**不碰原插件目录**：补丁只打在 plugin-locator 造出来的缓存镜像上
//    （见 plugin-locator.mjs 的 prepareMirror）。两个补丁都是幂等的，重复执行安全。
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const MARK = '[standalone-patch]'
const ORIGINAL_HEAD = `function dshwIsChatRoot(r) {
  if (!r || !r.querySelector) return false`

const PATCHED_HEAD = `function dshwIsChatRoot(r) {
  // ${MARK} 独立窗口：没有 DSH 聊天界面，自检直接放行（原判据保留在下方，不再使用）
  return true
  // eslint-disable-next-line no-unreachable
  if (!r || !r.querySelector) return false`

const TAP_MARK = '[click-tap-patch]'
const TAP_ORIG = `var SQUISH = 'scaleY(0.88) scaleX(1.05)'`
const TAP_HEAD = `var __whaleTapSquish = function () {
  // ${TAP_MARK} 点击形变幅度：amp = 压扁量（0~0.35），由控制中心写入 window.__whaleTap
  try {
    var c = window.__whaleTap
    if (c && c.on === false) return 'scaleY(1) scaleX(1)'
    var a = c && isFinite(Number(c.amp)) ? Math.max(0, Math.min(0.35, Number(c.amp))) : 0.12
    return 'scaleY(' + (1 - a).toFixed(3) + ') scaleX(' + (1 + a * 0.55).toFixed(3) + ')'
  } catch (err) { return SQUISH }
}
var SQUISH = 'scaleY(0.88) scaleX(1.05)'`

/** 目录 → 挂件脚本路径；也可以直接传脚本路径 */
export function widgetFileOf(dirOrFile) {
  const p = path.resolve(String(dirOrFile || ''))
  return p.toLowerCase().endsWith('.js') ? p : path.join(p, 'assets', 'whale-widget.js')
}

/**
 * 给指定挂件脚本打补丁（就地修改）。
 * @param {string} dirOrFile 插件目录，或 assets/whale-widget.js 的路径
 */
export function patchVendor(dirOrFile) {
  const file = widgetFileOf(dirOrFile)
  if (!fs.existsSync(file)) throw new Error('找不到 whale-widget.js: ' + file)
  let src = fs.readFileSync(file, 'utf8')
  const applied = []
  const skipped = []
  let touched = false

  // ① 自检闸门
  if (src.indexOf(MARK) >= 0) {
    applied.push('standalone')
  } else if (src.indexOf(ORIGINAL_HEAD) < 0) {
    skipped.push('standalone：没找到原始自检函数（上游可能改过），保持原样')
  } else {
    const next = src.replace(ORIGINAL_HEAD, PATCHED_HEAD)
    if (next !== src) {
      src = next
      touched = true
      applied.push('standalone')
    }
  }

  // ② 点击形变钩子
  if (src.indexOf(TAP_MARK) >= 0) {
    applied.push('tap')
  } else if (src.indexOf(TAP_ORIG) < 0) {
    skipped.push('tap：没找到 SQUISH 定义（上游可能改过），点击幅度退回出厂值')
  } else {
    let next = src.replace(TAP_ORIG, TAP_HEAD)
    next = next.split('body.style.transform = SQUISH').join('body.style.transform = __whaleTapSquish()')
    if (next !== src) {
      src = next
      touched = true
      applied.push('tap')
    } else {
      skipped.push('tap：没找到 SQUISH 的使用处，保持原样')
    }
  }

  if (touched) fs.writeFileSync(file, src, 'utf8')
  return { status: touched ? 'patched' : 'already', applied, skipped, file }
}

/** 补丁是否已在（目录或文件都行） */
export function isPatched(dirOrFile) {
  try {
    return fs.readFileSync(widgetFileOf(dirOrFile), 'utf8').indexOf(MARK) >= 0
  } catch (err) {
    return false
  }
}

// 直接运行时：node server/patch-vendor.mjs [插件目录]
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  const { locatePlugin, prepareMirror } = await import('./plugin-locator.mjs')
  const plugin = locatePlugin({ explicit: process.argv[2] })
  if (!plugin) {
    console.error('找不到原插件 dsh-whale-widget，请先用 WHALE_PLUGIN_DIR 指定它的目录')
    process.exit(1)
  }
  const mirror = prepareMirror({ plugin })
  console.log('镜像：', mirror.dir, mirror.reused ? '(复用)' : '(新建)')
  console.log(patchVendor(mirror.dir))
}
