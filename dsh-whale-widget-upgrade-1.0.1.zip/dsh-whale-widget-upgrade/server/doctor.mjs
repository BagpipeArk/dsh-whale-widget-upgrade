// doctor.mjs —— 升级包自检：原插件在不在、镜像和补丁状态、依赖、端口
// 用法：node server/doctor.mjs [--json] [插件目录]
import fs from 'node:fs'
import net from 'node:net'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  PLUGIN_NAME, defaultHome, defaultCacheRoot, locatePlugin, prepareMirror, describe,
} from './plugin-locator.mjs'
import { isPatched, widgetFileOf } from './patch-vendor.mjs'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const wantJson = process.argv.includes('--json')
const explicit = process.argv.slice(2).find((a) => !a.startsWith('--'))

const report = { ok: true, checks: [] }
function check(name, ok, detail) {
  report.checks.push({ name, ok: !!ok, detail: String(detail == null ? '' : detail) })
  if (!ok) report.ok = false
  return ok
}

// ① 原插件
const home = defaultHome()
const plugin = locatePlugin({ explicit, home })
check(
  '原插件 ' + PLUGIN_NAME,
  !!plugin,
  plugin ? `v${plugin.version} @ ${plugin.dir}` : '未找到（先用 dsh 装上原插件，或用 WHALE_PLUGIN_DIR 指定目录）',
)

// ② 镜像 + 补丁
let mirror = null
if (plugin) {
  try {
    mirror = prepareMirror({ plugin, cacheRoot: defaultCacheRoot(home) })
    check('运行镜像', true, mirror.dir + (mirror.reused ? '（复用）' : '（新建）'))
    const file = widgetFileOf(mirror.dir)
    check('挂件补丁', isPatched(mirror.dir), file)
  } catch (err) {
    check('运行镜像', false, err && err.message)
  }
}

// ③ 依赖
for (const dep of ['electron', 'koffi']) {
  const dir = path.join(ROOT, 'node_modules', dep)
  let ok = fs.existsSync(dir)
  if (dep === 'electron' && !ok) {
    // 开发目录里 electron 也可能只在 devDependencies 树中
    ok = fs.existsSync(path.join(ROOT, 'node_modules', '.bin', 'electron.cmd'))
  }
  check('依赖 ' + dep, ok, ok ? '已安装' : '未安装（在本目录执行 npm install）')
}

// ④ 数据目录
try {
  fs.mkdirSync(defaultCacheRoot(home), { recursive: true })
  fs.accessSync(defaultCacheRoot(home), fs.constants.W_OK)
  check('数据目录可写', true, defaultCacheRoot(home))
} catch (err) {
  check('数据目录可写', false, (err && err.message) || '不可写')
}

// ⑤ 端口
const port = Number(process.env.WHALE_PORT || 32168)
const busy = await new Promise((resolve) => {
  const s = net.createServer()
  s.once('error', () => resolve(true))
  s.once('listening', () => s.close(() => resolve(false)))
  s.listen(port, '127.0.0.1')
})
check('端口 ' + port + ' 可用', !busy, busy ? '已被占用（可能已经有一个实例在跑）' : '空闲')

if (wantJson) {
  console.log(JSON.stringify(report, null, 2))
} else {
  console.log('小鲸鱼升级包 · 环境自检')
  console.log('  数据目录: ' + home)
  console.log('  包目录  : ' + ROOT)
  for (const c of report.checks) console.log(`  [${c.ok ? '正常' : '注意'}] ${c.name} — ${c.detail}`)
  console.log(report.ok ? '\n全部就绪，可以 npm start 了。' : '\n有需要处理的项目（见上）。')
}

process.exit(report.ok ? 0 : 1)
