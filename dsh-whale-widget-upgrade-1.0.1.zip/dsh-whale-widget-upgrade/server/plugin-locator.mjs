// plugin-locator.mjs —— 找到「原插件」dsh-whale-widget，并给升级包造一份可写副本
//
// 升级包自己不带挂件本体（whale-widget.js / assets / lib 全部来自原插件），
// 所以要分两步：
//   ① locatePlugin()：按 WHALE_PLUGIN_DIR → 配置文件 → 常见 DSH 安装位置 的顺序找一个合法的 dsh-whale-widget；
//   ② prepareMirror()：把那个目录（可能是只读的 node_modules）镜像到缓存目录，
//      补丁只打在镜像上 —— 原插件目录一个字节都不动，卸载 = 删缓存目录。
//
// 找不到原插件时这里只返回 null / 抛错，由 main.js 决定怎么提示用户。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'

export const PLUGIN_NAME = 'dsh-whale-widget'
const REQUIRED_FILES = [
  ['package.json'],
  ['lib', 'index.js'],
  ['assets', 'whale-widget.js'],
]

/** DSH 数据目录（与原插件自己的判据一致） */
export function defaultHome() {
  return process.env.WHALE_HOME || process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
}

/** 升级包的缓存根（镜像、打过补丁的挂件脚本都放这儿，和原插件互不干扰） */
export function defaultCacheRoot(home = defaultHome()) {
  return process.env.WHALE_CACHE_DIR || path.join(home, '.whale-pack')
}

export function looksLikePlugin(dir) {
  if (!dir) return false
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'))
    if (String(pkg.name || '') !== PLUGIN_NAME) return false
  } catch (err) {
    return false
  }
  return REQUIRED_FILES.every((seg) => {
    try {
      return fs.statSync(path.join(dir, ...seg)).isFile()
    } catch (err) {
      return false
    }
  })
}

function listDirs(dir) {
  try {
    return fs
      .readdirSync(dir, { withFileTypes: true })
      .filter((d) => d.isDirectory())
      .map((d) => d.name)
  } catch (err) {
    return []
  }
}

/**
 * 可能装着原插件的目录（按优先级）。
 * 只做候选收集，合法性由 looksLikePlugin() 判定。
 */
export function candidateDirs(home = defaultHome()) {
  const out = []
  const push = (p) => {
    if (!p) return
    const abs = path.resolve(p)
    if (!out.includes(abs)) out.push(abs)
  }

  // ① 用户显式指定（最优先，方便多 profile / 便携安装）
  push(process.env.WHALE_PLUGIN_DIR)

  // ② DSH 常见的几个 home
  const homes = [home, path.join(os.homedir(), '.dsh')]
  for (const env of ['APPDATA', 'LOCALAPPDATA']) {
    if (process.env[env]) homes.push(path.join(process.env[env], 'dsh'))
  }
  for (const h of homes) {
    push(path.join(h, 'node_modules', PLUGIN_NAME))
    for (const profile of listDirs(path.join(h, 'profiles'))) {
      push(path.join(h, 'profiles', profile, 'node_modules', PLUGIN_NAME))
    }
  }

  // ③ 升级包自己所在目录的邻居（同目录并列安装的情况）
  push(path.join(process.cwd(), 'node_modules', PLUGIN_NAME))
  push(path.join(path.dirname(process.cwd()), 'node_modules', PLUGIN_NAME))
  return out
}

/**
 * 定位原插件。
 * @returns {{dir:string, version:string, stamp:string} | null}
 */
export function locatePlugin(opts = {}) {
  const home = opts.home || defaultHome()
  const tried = []
  const dirs = opts.explicit ? [path.resolve(opts.explicit), ...candidateDirs(home)] : candidateDirs(home)
  for (const dir of dirs) {
    if (tried.includes(dir)) continue
    tried.push(dir)
    if (!looksLikePlugin(dir)) continue
    let version = '0.0.0'
    try {
      version = String(JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).version || version)
    } catch (err) {}
    return { dir, version, stamp: stampOf(dir), tried }
  }
  return null
}

function sha12(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex').slice(0, 12)
}

/** 用「关键文件内容」做指纹：原插件一升级，镜像自动重建 */
export function stampOf(pluginDir) {
  const h = crypto.createHash('sha256')
  for (const seg of REQUIRED_FILES) {
    try {
      h.update(seg.join('/'))
      h.update(fs.readFileSync(path.join(pluginDir, ...seg)))
    } catch (err) {
      h.update('missing:' + seg.join('/'))
    }
  }
  return h.digest('hex').slice(0, 12)
}

const SKIP_DIRS = new Set(['node_modules', '.git'])
const SKIP_SUFFIX = ['.orig', '.bak', '.broken']

function shouldSkipFile(name) {
  return SKIP_SUFFIX.some((s) => name.endsWith(s))
}

function copyTree(from, to) {
  fs.mkdirSync(to, { recursive: true })
  for (const ent of fs.readdirSync(from, { withFileTypes: true })) {
    const src = path.join(from, ent.name)
    const dst = path.join(to, ent.name)
    if (ent.isDirectory()) {
      if (SKIP_DIRS.has(ent.name)) continue
      copyTree(src, dst)
    } else if (ent.isFile()) {
      if (shouldSkipFile(ent.name)) continue
      fs.copyFileSync(src, dst)
    }
  }
}

/**
 * 把原插件镜像到缓存目录（只读源 → 可打补丁的副本）。
 * 同一份指纹只建一次；旧镜像会被清理（最多留 2 份）。
 * @returns {{dir:string, reused:boolean, version:string, stamp:string, origin:string}}
 */
export function prepareMirror(opts = {}) {
  const plugin = opts.plugin || opts.pluginDir
  if (!plugin) throw new Error('prepareMirror: 缺少原插件目录')
  const info = typeof plugin === 'string'
    ? (() => {
        const dir = path.resolve(plugin)
        if (!looksLikePlugin(dir)) throw new Error('不是有效的 ' + PLUGIN_NAME + ' 目录：' + dir)
        let version = '0.0.0'
        try {
          version = String(JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).version || version)
        } catch (err) {}
        return { dir, version, stamp: stampOf(dir) }
      })()
    : plugin

  const cacheRoot = opts.cacheRoot || defaultCacheRoot()
  fs.mkdirSync(cacheRoot, { recursive: true })
  const name = `mirror-${info.version}-${info.stamp}`
  const target = path.join(cacheRoot, name)
  const ready = path.join(target, '.mirror-ready')

  if (fs.existsSync(ready)) {
    return { dir: target, reused: true, version: info.version, stamp: info.stamp, origin: info.dir }
  }

  // 先写到临时目录再改名，避免半成品被下次启动当成可用镜像
  const temp = target + '.tmp-' + process.pid
  try {
    fs.rmSync(temp, { recursive: true, force: true })
    copyTree(info.dir, temp)
    fs.writeFileSync(
      path.join(temp, '.mirror-ready'),
      JSON.stringify({ origin: info.dir, version: info.version, stamp: info.stamp, at: new Date().toISOString() }, null, 2),
      'utf8',
    )
    fs.rmSync(target, { recursive: true, force: true })
    fs.renameSync(temp, target)
  } finally {
    try {
      fs.rmSync(temp, { recursive: true, force: true })
    } catch (err) {}
  }

  // 清理老镜像，只留最新的两份
  try {
    const mine = listDirs(cacheRoot).filter((d) => d.startsWith('mirror-'))
    mine
      .filter((d) => d !== name)
      .slice(0, Math.max(0, mine.length - 2))
      .forEach((d) => fs.rmSync(path.join(cacheRoot, d), { recursive: true, force: true }))
  } catch (err) {}

  return { dir: target, reused: false, version: info.version, stamp: info.stamp, origin: info.dir }
}

/** 给界面/日志用的一句话描述 */
export function describe(info) {
  if (!info) return '未找到 ' + PLUGIN_NAME
  return `${PLUGIN_NAME} ${info.version} @ ${info.dir}`
}

export { sha12 }
