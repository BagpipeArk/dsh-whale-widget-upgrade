// web-balance.mjs —— 独立版的「DeepSeek 账号余额」来源
//
// 背景：原插件 fetchAccountBalance() 调 ctx.get('deepseekAccount').getBalance(client)，
//       在 DSH 里由宿主用本地 grant token 请求 Platform。脱离 DSH 后没有这个服务，
//       所以这里自己实现一份等价实现。
//
// 实测可用的取数路径（2026-10 验证）：
//   GET https://platform.deepseek.com/api/v0/users/get_user_summary
//   header: x-dsh-auth-token: <grant token>
//   → { code:0, data:{ biz_code:0, biz_data:{ normal_wallets:[{currency,balance}], bonus_wallets:[...], total_costs:[...] } } }
//
// token 来源优先级：
//   1. 环境变量 WHALE_ACCOUNT_TOKEN / DEEPSEEK_ACCOUNT_TOKEN
//   2. 独立版自己的凭据文件 $WHALE_HOME/.whale-standalone-credentials.json（设置页写入）
//   3. DSH 的 $DSH_HOME/.credentials.yaml 里的 deepseek-account-platform/default（只读复用，用户无需登录）
//
// 注意：这里绝不收集账号密码。token 是 DSH 已经登录后落在本机的授权凭据，
//       独立版只是只读复用它；失效了就在设置页重新填一份。

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'

const DEFAULT_ORIGIN = 'https://platform.deepseek.com'
const SUMMARY_PATH = '/api/v0/users/get_user_summary'
const PROFILE_PATH = '/auth-api/v0/users/current'
const CACHE_TTL_MS = 20000

export function resolveHome(opts = {}) {
  return (
    opts.home ||
    process.env.WHALE_HOME ||
    process.env.DSH_HOME ||
    path.join(os.homedir(), '.dsh')
  )
}

// ---------- 极简 YAML 取值：只为了从 .credentials.yaml 里抠 token / issuer ----------
// DSH 的凭据文档结构固定（version / records / <ref> / kind / payload / ...），
// 不引入 yaml 依赖，按缩进逐行扫一遍就够。
function readCredentialRecord(text, recordKey) {
  const lines = String(text || '').split(/\r?\n/)
  let inRecords = false
  let inRecord = false
  let recordIndent = -1
  const out = {}
  for (const raw of lines) {
    if (!raw.trim() || raw.trim().startsWith('#')) continue
    const indent = raw.length - raw.replace(/^\s+/, '').length
    const line = raw.trim()

    if (!inRecords) {
      if (line === 'records:') inRecords = true
      continue
    }
    if (indent === 0) break // records 段结束

    // 段名：`  deepseek-account-platform/default:`
    if (!inRecord) {
      const m = /^(.*):$/.exec(line)
      if (m && indent === 2) {
        if (m[1] === recordKey) {
          inRecord = true
          recordIndent = indent
        }
        continue
      }
      continue
    }

    // 已进入目标段：记录它下面的 key: value
    if (indent <= recordIndent) break
    const kv = /^([A-Za-z0-9_.\-]+):\s*(.*)$/.exec(line)
    if (kv) out[kv[1]] = kv[2].replace(/^["']|["']$/g, '')
  }
  return out
}

function readDshGrant(home) {
  const file = path.join(home, '.credentials.yaml')
  let text = ''
  try {
    text = fs.readFileSync(file, 'utf8')
  } catch (err) {
    return null
  }
  const rec = readCredentialRecord(text, 'deepseek-account-platform/default')
  if (!rec || !rec.payload) {
    // 结构是 records.<name>.payload.* —— 上面的扫描把 payload 下的 token/issuer 放在同一层，
    // 因为极简解析不建嵌套。这里兜底再全文匹配一次。
  }
  const tokenMatch = /deepseek-account-platform\/default:[\s\S]{0,400}?\btoken:\s*(\S+)/.exec(text)
  const issuerMatch = /deepseek-account-platform\/default:[\s\S]{0,400}?\bissuer:\s*(\S+)/.exec(text)
  const token = (tokenMatch && tokenMatch[1]) || rec.token || ''
  const issuer = (issuerMatch && issuerMatch[1]) || rec.issuer || DEFAULT_ORIGIN
  if (!token) return null
  return { token, origin: (issuer || DEFAULT_ORIGIN).replace(/\/+$/, ''), source: 'dsh' }
}

function readStandaloneCreds(home) {
  const file = path.join(home, '.whale-standalone-credentials.json')
  let data = {}
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'))
    if (parsed && typeof parsed === 'object') data = parsed
  } catch (err) {
    return null
  }
  // 两种形态都认：
  //   kind=apiKey → sk-xxx，走官方 /user/balance（给别人用最省事，key 可随时吊销）
  //   kind=grant  → 平台登录态 token，走 /api/v0/users/get_user_summary
  const raw = String(
    data.DEEPSEEK_API_KEY || data.DEEPSEEK_ACCOUNT_TOKEN || data.deepseekAccountToken || ''
  ).trim()
  if (!raw) return null
  const kind = data.kind === 'apiKey' || /^sk-/i.test(raw) ? 'apiKey' : 'grant'
  return {
    token: raw,
    kind,
    origin: String(data.DEEPSEEK_ACCOUNT_ORIGIN || DEFAULT_ORIGIN).replace(/\/+$/, ''),
    source: 'manual',
  }
}

export function writeStandaloneToken(home, token, origin) {
  const file = path.join(home, '.whale-standalone-credentials.json')
  let data = {}
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'))
    if (parsed && typeof parsed === 'object') data = parsed
  } catch (err) {}
  data.DEEPSEEK_ACCOUNT_TOKEN = String(token || '').trim()
  if (origin) data.DEEPSEEK_ACCOUNT_ORIGIN = String(origin).trim()
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600 })
  return file
}

// ---------- 平台客户端头（与 DSH 一致：五个 x-client-*，bundle-id 故意留空） ----------
function clientHeaders(client = {}, origin) {
  const version = String(client.version || process.env.DSH_CLIENT_VERSION || 'unknown')
  let locale = String(client.locale || process.env.DSH_LOCALE || 'zh_CN')
  locale = locale.toLowerCase().startsWith('en') ? 'en_US' : 'zh_CN'
  const tz =
    Number.isFinite(Number(client.timezoneOffsetSeconds))
      ? Number(client.timezoneOffsetSeconds)
      : -new Date().getTimezoneOffset() * 60
  return {
    'x-client-platform': process.platform === 'win32' ? 'desktop-win' : process.platform === 'darwin' ? 'desktop-mac' : 'web',
    'x-client-request-id': crypto.randomUUID(),
    'x-client-bundle-id': '',
    'x-client-locale': locale,
    'x-client-version': version,
    'x-client-timezone-offset': String(Math.round(tz)),
    'x-origin': origin,
  }
}

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

export function createAccountService(opts = {}) {
  const home = resolveHome(opts)
  const log = opts.log || ((s) => console.log('[whale-account] ' + s))
  let cached = null // { at, payload }
  let expired = false // token 被平台判失效
  let lastUserId = null

  function readGrant() {
    if (expired) return null
    const envTok = String(process.env.WHALE_ACCOUNT_TOKEN || process.env.DEEPSEEK_ACCOUNT_TOKEN || '').trim()
    if (envTok) return { token: envTok, origin: DEFAULT_ORIGIN, source: 'env' }
    return readStandaloneCreds(home) || readDshGrant(home)
  }

  function markExpired(reason) {
    if (expired) return
    expired = true
    cached = null
    log('登录态已失效：' + reason + '（可在设置页重新填写 token）')
  }

  async function request(pathname, grant, client) {
    const url = grant.origin + pathname
    const headers = {
      ...clientHeaders(client, grant.origin),
      'x-dsh-auth-token': grant.token,
      accept: 'application/json',
    }
    // x-origin 只用于我们自己日志，别真发给平台
    delete headers['x-origin']
    let res
    try {
      res = await fetch(url, { headers, signal: AbortSignal.timeout(8000) })
    } catch (err) {
      const e = new Error('平台请求失败: ' + String((err && err.message) || err))
      e.code = 'NETWORK'
      throw e
    }
    let body = null
    try {
      body = await res.json()
    } catch (err) {}
    if (res.status === 401) {
      markExpired('HTTP 401')
      const e = new Error('登录态失效（401）')
      e.code = 'AUTH'
      throw e
    }
    if (!res.ok) {
      const e = new Error('HTTP ' + res.status)
      e.code = 'HTTP'
      throw e
    }
    const code = body && typeof body.code === 'number' ? body.code : null
    if (code === 40003) {
      markExpired('code 40003')
      const e = new Error('登录态失效（40003）')
      e.code = 'AUTH'
      throw e
    }
    if (code !== null && code !== 0) {
      const e = new Error('平台返回 code=' + code + ' ' + String((body && body.msg) || ''))
      e.code = 'PLATFORM'
      throw e
    }
    // 剥一层信封：{ code, data:{ biz_code, biz_data:{...} } }
    const data = body && body.data ? body.data : body
    if (data && typeof data === 'object' && data.biz_code != null && data.biz_code !== 0) {
      const e = new Error('业务码 ' + data.biz_code + ' ' + String(data.biz_msg || ''))
      e.code = 'BIZ'
      throw e
    }
    return (data && data.biz_data) || data || {}
  }

  // ---------- API Key 路（官方公开接口，给别人用最省事） ----------
  const APIKEY_BALANCE_URL = 'https://api.deepseek.com/user/balance'

  async function fetchApiKeyBalance(grant) {
    let res
    try {
      res = await fetch(APIKEY_BALANCE_URL, {
        headers: {
          Authorization: 'Bearer ' + grant.token,
          accept: 'application/json',
          'x-client-platform': 'web',
        },
        signal: AbortSignal.timeout(8000),
      })
    } catch (err) {
      const e = new Error('网络请求失败: ' + String((err && err.message) || err))
      e.code = 'NETWORK'
      throw e
    }
    if (res.status === 401 || res.status === 403) {
      markExpired('API Key 被拒（HTTP ' + res.status + '）')
      const e = new Error('API Key 无效或已吊销')
      e.code = 'AUTH'
      throw e
    }
    if (!res.ok) {
      const e = new Error('HTTP ' + res.status)
      e.code = 'HTTP'
      throw e
    }
    const body = await res.json().catch(() => null)
    const infos = Array.isArray(body && body.balance_infos) ? body.balance_infos : []
    if (!infos.length) {
      const e = new Error('该 Key 没有返回余额信息')
      e.code = 'EMPTY'
      throw e
    }
    const value = []
    const bonusWallets = []
    for (const info of infos) {
      const cur = String(info.currency || 'CNY').toUpperCase()
      const topped = num(info.topped_up_balance)
      const granted = num(info.granted_balance)
      const total = num(info.total_balance)
      if (topped !== null) value.push({ currency: cur, balance: String(info.topped_up_balance) })
      else if (total !== null) value.push({ currency: cur, balance: String(info.total_balance) })
      if (granted !== null && granted > 0) bonusWallets.push({ currency: cur, balance: String(info.granted_balance) })
    }
    return { status: 'ready', value, bonusWallets, totalCosts: [] }
  }

  const service = {
    home,

    // 插件只用来取账本 scope；拿不到就退化成固定标识
    getState() {
      return { userId: lastUserId, signedIn: !!readGrant(), source: (readGrant() || {}).source || null }
    },

    async getProfile(client = {}) {
      const grant = readGrant()
      if (!grant) return null
      try {
        const v = await request(PROFILE_PATH, grant, client)
        const uid = (v && (v.id || (v.id_profile && v.id_profile.id) || v.user_id)) || null
        if (uid) lastUserId = String(uid)
        const pic = (v && v.id_profile && v.id_profile.picture) || (v && v.avatar) || null
        return {
          status: 'ready',
          value: {
            userId: lastUserId,
            name: (v && (v.name || (v.id_profile && v.id_profile.name))) || null,
            avatarUrl: pic,
            contact: (v && (v.mobile_number || v.email)) || null,
          },
        }
      } catch (err) {
        log('getProfile 失败: ' + err.message)
        return null
      }
    },

    async getBalance(client = {}) {
      if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.payload
      const grant = readGrant()
      if (!grant) return null // 未登录：让插件走它自己的文案

      if (grant.kind === 'apiKey') {
        try {
          const payload = { ...(await fetchApiKeyBalance(grant)), source: 'apiKey', fetchedAt: Date.now() }
          cached = { at: Date.now(), payload }
          return payload
        } catch (err) {
          log('getBalance(apiKey) 失败: ' + (err.code || '') + ' ' + err.message)
          throw err
        }
      }

      let raw
      try {
        raw = await request(SUMMARY_PATH, grant, client)
      } catch (err) {
        log('getBalance 失败: ' + (err.code || '') + ' ' + err.message)
        throw err
      }
      const normRaw = Array.isArray(raw.normal_wallets) ? raw.normal_wallets : []
      const bonusRaw = Array.isArray(raw.bonus_wallets) ? raw.bonus_wallets : []
      const clean = (list) =>
        list
          .filter((w) => w && num(w.balance) !== null)
          .map((w) => ({ currency: String(w.currency || 'CNY').toUpperCase(), balance: String(w.balance) }))
      const payload = {
        status: 'ready',
        value: clean(normRaw),
        bonusWallets: clean(bonusRaw),
        totalCosts: Array.isArray(raw.total_costs)
          ? raw.total_costs.map((c) => ({ currency: String(c.currency || 'CNY').toUpperCase(), amount: String(c.amount) }))
          : [],
        source: grant.source,
        fetchedAt: Date.now(),
      }
      cached = { at: Date.now(), payload }
      return payload
    },

    // 给设置页/托盘用：当前登录态概况（不含 token 本身）
    status() {
      const grant = readGrant()
      return {
        signedIn: !!grant,
        source: grant ? grant.source : null,
        origin: grant ? grant.origin : DEFAULT_ORIGIN,
        expired,
        lastUserId,
        hasCache: !!cached,
      }
    },

    // 手动换一份 token（设置页写入）后清掉失效标记与缓存
    setManualToken(token, origin) {
      writeStandaloneToken(home, token, origin)
      expired = false
      cached = null
      log('已写入手动 token（来源：设置页）')
      return service.status()
    },

    invalidate() {
      cached = null
    },

    // 兼容：插件不直接调，但保留一份和 DSH 同名的方法，方便以后替换
    async getPlatformSession() {
      const grant = readGrant()
      if (!grant) return null
      return { origin: grant.origin, userId: lastUserId }
    },
  }

  const grant0 = readGrant()
  log(grant0 ? '余额来源：' + grant0.source + '（' + grant0.origin + '）' : '未找到登录态，余额将不可用')

  return service
}
