// control-preload.js —— 控制中心窗口的桥（只暴露窄接口，渲染层拿不到 node）
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('whaleCtl', {
  // 通用代理：直接和挂件宿主（127.0.0.1）上的 /dsh-whale/* 路由对话
  req: (method, path, body) => ipcRenderer.invoke('ctl:req', { method, path, body }),

  // 挂件尺寸/开关类设置（size.json）
  getSize: () => ipcRenderer.invoke('ctl:size:get'),
  putSize: (patch) => ipcRenderer.invoke('ctl:size:put', patch),

  // 吸附与翻转（存在挂件页面的 localStorage 里）
  getSnap: () => ipcRenderer.invoke('ctl:snap:get'),
  putSnap: (cfg) => ipcRenderer.invoke('ctl:snap:put', cfg),

  // 额度与报警（桌面版自己加的配置，不进宿主的 usage-settings）
  getBudget: () => ipcRenderer.invoke('ctl:budget:get'),
  putBudget: (patch) => ipcRenderer.invoke('ctl:budget:put', patch),

  // 各平台每日用量快照（图表切换平台用）
  getApiUsage: () => ipcRenderer.invoke('ctl:api-usage:get'),

  // 点击动效（幅度 / 速度）
  getTap: () => ipcRenderer.invoke('ctl:tap:get'),
  putTap: (patch) => ipcRenderer.invoke('ctl:tap:put', patch),

  // Live2D 形象
  getLive2D: () => ipcRenderer.invoke('ctl:l2d:state'),
  putLive2D: (patch) => ipcRenderer.invoke('ctl:l2d:put', patch),
  importLive2D: () => ipcRenderer.invoke('ctl:l2d:import'),
  deleteLive2D: (id) => ipcRenderer.invoke('ctl:l2d:delete', id),
  refreshLive2D: () => ipcRenderer.invoke('ctl:l2d:refresh'),

  // 系统对话框 + 导入
  renameRole: (id, name) => ipcRenderer.invoke('ctl:role-rename', { id, name }),
  getAutostart: () => ipcRenderer.invoke('whale-settings:get-autostart'),
  setAutostart: (v) => ipcRenderer.invoke('whale-settings:set-autostart', v),

  pickImage: () => ipcRenderer.invoke('ctl:pick-image'),
  pickAudio: () => ipcRenderer.invoke('ctl:pick-audio'),
  importRole: (payload) => ipcRenderer.invoke('ctl:import-role', payload),
  importAudio: (payload) => ipcRenderer.invoke('ctl:import-audio', payload),

  // 窗口动作
  reloadWidget: () => ipcRenderer.invoke('ctl:widget:reload'),
  applyRole: (id) => ipcRenderer.invoke('ctl:role-apply', id),
  focusWidget: () => ipcRenderer.invoke('ctl:widget:focus'),
  quit: () => ipcRenderer.invoke('ctl:quit'),
  openExternal: (url) => ipcRenderer.invoke('ctl:open-external', url),

  onTab: (fn) => {
    ipcRenderer.on('ctl:tab', (e, tab) => fn(tab))
  },
})
