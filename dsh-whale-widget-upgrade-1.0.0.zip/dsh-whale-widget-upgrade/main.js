// main.js —— 小鲸鱼桌面增强包（Electron 主进程）
// 结构：Electron 壳（透明窗口 / 置底 / 穿透） + 本地假宿主（后端与挂件全部来自原插件 dsh-whale-widget）
const { app, BrowserWindow, ipcMain, screen, Tray, Menu, shell } = require('electron')
const path = require('node:path')
const fs = require('node:fs')
const { pathToFileURL } = require('node:url')

const ROOT = __dirname
const PORT = Number(process.env.WHALE_PORT || 32168)

// —— 日志落文件：GUI 进程的 stdout 抓不到，只能自己写盘（写到用户数据目录，不在安装目录留痕） ——
function logDirDefault() {
  try {
    return path.join(app.getPath('userData'), 'logs')
  } catch (err) {
    return path.join(ROOT, 'logs')
  }
}
const LOG_DIR = logDirDefault()
const LOG_FILE = path.join(LOG_DIR, 'upgrade.log')
try {
  fs.mkdirSync(LOG_DIR, { recursive: true })
  fs.writeFileSync(LOG_FILE, '')
} catch (err) {}
function flog(...args) {
  const line = args
    .map((a) => {
      if (a instanceof Error) return a.stack || a.message
      if (typeof a === 'object') {
        try {
          return JSON.stringify(a)
        } catch (e) {
          return String(a)
        }
      }
      return String(a)
    })
    .join(' ')
  try {
    fs.appendFileSync(LOG_FILE, line + '\n')
  } catch (err) {}
}
for (const k of ['log', 'warn', 'error']) {
  const orig = console[k].bind(console)
  console[k] = (...a) => {
    flog('[' + k + ']', ...a)
    try {
      orig(...a)
    } catch (e) {}
  }
}

let win = null
let tray = null
let host = null
let bottomTimer = null
let win32 = null
let accountService = null
let settingsWin = null

// ---------------- Win32：把窗口压到最底层 ----------------
function loadWin32() {
  if (win32) return win32
  try {
    const koffi = require('koffi')
    const user32 = koffi.load('user32.dll')
    win32 = {
      SetWindowPos: user32.func('int __stdcall SetWindowPos(uint64, uint64, int, int, int, int, uint32)'),
    }
  } catch (err) {
    console.warn('[whale] 没能加载 Win32（置底功能将退化为普通窗口）:', err && err.message)
    win32 = null
  }
  return win32
}

const HWND_BOTTOM = 1
const SWP_NOSIZE = 0x0001
const SWP_NOMOVE = 0x0002
const SWP_NOACTIVATE = 0x0010

function hwndOf(win) {
  try {
    const buf = win.getNativeWindowHandle()
    return buf.length === 8 ? buf.readBigUInt64LE(0) : BigInt(buf.readUInt32LE(0))
  } catch (err) {
    return 0n
  }
}

function pushToBottom() {
  const w = loadWin32()
  if (!w || !win || win.isDestroyed()) return
  const hwnd = hwndOf(win)
  if (!hwnd) return
  try {
    w.SetWindowPos(hwnd, BigInt(HWND_BOTTOM), 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
  } catch (err) {}
}

// ---------------- 窗口 ----------------
function createWindow(url) {
  const { workArea } = screen.getPrimaryDisplay()
  // 窗口比工作区略大，保证贴边时气泡不会被裁掉
  const width = Math.round(workArea.width)
  const height = Math.round(workArea.height)

  win = new BrowserWindow({
    x: workArea.x,
    y: workArea.y,
    width,
    height,
    transparent: true,
    backgroundColor: '#00000000',
    frame: false,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    hasShadow: false,
    alwaysOnTop: false,
    focusable: true,
    show: false,
    acceptFirstMouse: true,
    webPreferences: {
      preload: path.join(ROOT, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
      spellcheck: false,
    },
  })

  // 默认整窗穿透；只有指针落在鲸鱼/泡泡/菜单上时才接住鼠标
  win.setIgnoreMouseEvents(true, { forward: true })
  win.setAlwaysOnTop(false)

  win.loadURL(url)

  win.once('ready-to-show', () => {
    win.showInactive()
    pushToBottom()
    setTimeout(pushToBottom, 120)
    setTimeout(pushToBottom, 600)
    setTimeout(pushToBottom, 1500)
  })

  // 每次被激活/置前，都再压回底部
  win.on('focus', () => pushToBottom())
  win.on('blur', () => pushToBottom())
  win.on('show', () => pushToBottom())

  win.webContents.setWindowOpenHandler(({ url: target }) => {
    try {
      shell.openExternal(target)
    } catch (err) {}
    return { action: 'deny' }
  })
  win.webContents.on('will-navigate', (e, target) => {
    if (target !== url) {
      e.preventDefault()
      try {
        shell.openExternal(target)
      } catch (err) {}
    }
  })

  // 持续压底（别的窗口最大化/切前台后仍要待在底层）
  bottomTimer = setInterval(pushToBottom, 1200)

  // 调试：把窗口自身画面截图存盘，方便验证渲染（页面里的 console 也转发到终端）
  win.webContents.on('console-message', (e, level, message, line, sourceId) => {
    flog('[page:' + level + ']', message, sourceId ? '(' + path.basename(String(sourceId)) + ':' + line + ')' : '')
  })
  win.webContents.on('preload-error', (e, p, err) => flog('[preload-error]', p, err))
  win.webContents.on('did-fail-load', (e, code, desc, url) => flog('[did-fail-load]', code, desc, url))
  win.webContents.on('render-process-gone', (e, d) => flog('[render-gone]', d))
  win.webContents.on('unresponsive', () => flog('[unresponsive]'))

  const probePage = async (tag) => {
    try {
      const info = await win.webContents.executeJavaScript(
        `(() => {
          const root = document.querySelector('.dshwv-root');
          const img = document.querySelector('.dshwv-root img');
          const r = root ? root.getBoundingClientRect() : null;
          return {
            bodyLen: document.body ? document.body.innerHTML.length : -1,
            hasRoot: !!root,
            rootCls: root ? String(root.className) : null,
            rootRect: r ? { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) } : null,
            hasImg: !!img,
            imgSrc: img ? img.getAttribute('src') : null,
            dpr: window.devicePixelRatio,
            vw: innerWidth, vh: innerHeight,
            bodyNodes: document.querySelectorAll('[class*="dshwv"]').length,
          };
        })()`,
        true
      )
      flog('[probe:' + tag + ']', info)
    } catch (err) {
      flog('[probe:' + tag + '] ERR', err && err.message)
    }
  }
  win.webContents.on('did-finish-load', () => {
    injectMenuRedirect()
    pushTap()
    // 挂件要等 dshwInit 把 .dshwv-body 建出来，晚一点再叠 Live2D 层
    setTimeout(() => {
      pushLive2D().catch((err) => flog('[l2d] push 失败', err && err.message))
    }, 1200)
  })

  win.webContents.once('did-finish-load', () => {
    setTimeout(() => probePage('2.5s'), 2500)
    setTimeout(() => probePage('8s'), 8000)
  })
}

// 渲染层告知：指针是否落在挂件上
ipcMain.on('whale:set-ignore', (event, ignore) => {
  if (!win || win.isDestroyed()) return
  try {
    win.setIgnoreMouseEvents(!!ignore, { forward: true })
  } catch (err) {}
})

ipcMain.on('whale:push-bottom', () => pushToBottom())

// ---------------- 三条杠按钮 -> 控制中心 ----------------
// 挂件自带的微缩菜单已废弃：点三条杠直接开控制中心，菜单不再弹出。
const MENU_REDIRECT_JS = `
(() => {
  if (window.__whaleMenuRedirect) return
  window.__whaleMenuRedirect = true

  function shutMenu() {
    try {
      document.querySelectorAll('.dshwv-menu').forEach(function (m) {
        m.classList.remove('dshwv-menu-open')
      })
      document.querySelectorAll('.dshwv-menu-btn').forEach(function (b) {
        b.classList.remove('dshwv-menu-btn-visible')
      })
    } catch (err) {}
  }

  var lastAt = 0
  function handler(e) {
    var el = e.target
    if (!el || !el.closest) return
    if (!el.closest('.dshwv-menu-btn')) return
    e.preventDefault()
    e.stopPropagation()
    e.stopImmediatePropagation()
    var now = Date.now()
    if (now - lastAt < 350) return
    lastAt = now
    shutMenu()
    try {
      if (window.whaleShell && window.whaleShell.openControl) window.whaleShell.openControl()
    } catch (err) {}
  }

  ['pointerdown', 'mousedown', 'click'].forEach(function (t) {
    document.addEventListener(t, handler, true)
  })
  // 保险：万一有残留的开启态，加载后先收拾干净
  setTimeout(shutMenu, 800)
})()
`

function injectMenuRedirect() {
  if (!win || win.isDestroyed()) return
  win.webContents.executeJavaScript(MENU_REDIRECT_JS, true).catch(() => {})
}

ipcMain.on('whale:open-control', (event, tab) => {
  openControl(tab || undefined)
})

ipcMain.on('whale:resize-for', (event, rect) => {
  // 预留：气泡区域需要时精确调整窗口。目前用全屏窗口，先不启用
})

// ---------------- 账号与余额设置窗口 ----------------
function openSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) {
    settingsWin.show()
    settingsWin.focus()
    return
  }
  settingsWin = new BrowserWindow({
    width: 460,
    height: 640,
    resizable: true,
    minimizable: true,
    maximizable: false,
    fullscreenable: false,
    title: '小鲸鱼 · 账号与余额',
    backgroundColor: '#f7f9ff',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(ROOT, 'settings-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  })
  settingsWin.loadFile(path.join(ROOT, 'settings.html'))
  settingsWin.once('ready-to-show', () => settingsWin.show())
  settingsWin.on('closed', () => {
    settingsWin = null
  })
  settingsWin.webContents.setWindowOpenHandler(({ url: target }) => {
    try {
      shell.openExternal(target)
    } catch (err) {}
    return { action: 'deny' }
  })
}

async function readAccountForUi({ force = false } = {}) {
  const status = accountService ? accountService.status() : { signedIn: false, source: null }
  let balance = null
  if (accountService && status.signedIn) {
    if (force && typeof accountService.invalidate === 'function') accountService.invalidate()
    try {
      const b = await accountService.getBalance({ version: '0.2.1-rc.2' })
      if (b && b.status === 'ready') {
        balance = { value: b.value || [], bonus: b.bonusWallets || [], costs: b.totalCosts || [] }
      } else {
        balance = { error: '平台没有返回余额数据' }
      }
    } catch (err) {
      balance = { error: String((err && err.message) || err) }
    }
  } else if (status.expired) {
    balance = { error: '登录态已失效，请重新填写凭据' }
  }
  return { status, balance }
}

ipcMain.handle('whale-settings:status', async () => readAccountForUi())
ipcMain.handle('whale-settings:refresh', async () => {
  const r = await readAccountForUi({ force: true })
  try {
    if (host && host.ctx) host.ctx.emit && host.ctx.emit('whale:refresh-balance')
  } catch (err) {}
  return r
})
ipcMain.handle('whale-settings:save-token', async (event, token) => {
  if (!accountService) return { ok: false, error: '余额模块未加载' }
  const value = String(token || '').trim()
  if (!value) return { ok: false, error: '凭据为空' }
  try {
    accountService.setManualToken(value)
    const b = await accountService.getBalance({ version: '0.2.1-rc.2' })
    if (b && b.status === 'ready') return { ok: true }
    return { ok: false, error: '凭据保存了，但平台没返回余额' }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})
ipcMain.handle('whale-settings:clear-token', async () => {
  if (!accountService) return { ok: false, error: '余额模块未加载' }
  try {
    accountService.setManualToken('')
    accountService.invalidate && accountService.invalidate()
    return { ok: true }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

// ---------------- 开机自启动 ----------------
function configFile() {
  try {
    return path.join(app.getPath('userData'), 'whale-config.json')
  } catch (err) {
    return path.join(ROOT, 'whale-config.json')
  }
}
function readConfig() {
  try {
    const raw = fs.readFileSync(configFile(), 'utf8')
    return JSON.parse(raw) || {}
  } catch (err) {
    return {}
  }
}
function writeConfig(patch) {
  const next = Object.assign(readConfig(), patch)
  try {
    fs.mkdirSync(path.dirname(configFile()), { recursive: true })
    fs.writeFileSync(configFile(), JSON.stringify(next, null, 2))
  } catch (err) {
    console.warn('[whale] 写配置失败:', err && err.message)
  }
  return next
}
function autostartEnabled() {
  return readConfig().autostart !== false // 默认开启
}
function applyAutostart(flag) {
  if (process.platform !== 'win32') return
  if (!app.isPackaged) return // 开发模式别把 electron.exe 塞进注册表
  try {
    app.setLoginItemSettings({ openAtLogin: !!flag, path: process.execPath, args: [] })
  } catch (err) {
    console.warn('[whale] 设置开机自启动失败:', err && err.message)
  }
}
ipcMain.handle('whale-settings:get-autostart', async () => ({
  enabled: autostartEnabled(),
  packaged: app.isPackaged,
}))
ipcMain.handle('whale-settings:set-autostart', async (event, flag) => {
  writeConfig({ autostart: !!flag })
  applyAutostart(!!flag)
  return { ok: true, enabled: !!flag }
})

// ---------------- 控制中心（取代原来的微缩菜单） ----------------
let controlWin = null

function hostBase() {
  return host ? 'http://127.0.0.1:' + host.port : ''
}

function widgetEval(script) {
  if (!win || win.isDestroyed()) return Promise.resolve(null)
  return win.webContents.executeJavaScript(script, true).catch(() => null)
}

// 让挂件重读 size.json（挂件用的是「可见性变化 / 打开菜单时」补读，带 2 秒去抖）
function nudgeWidgetResync() {
  const fire = () => widgetEval("document.dispatchEvent(new Event('visibilitychange')); true")
  setTimeout(fire, 60)
  setTimeout(fire, 2400)
}

function openControl(tab) {
  if (controlWin && !controlWin.isDestroyed()) {
    controlWin.show()
    controlWin.focus()
    if (tab) controlWin.webContents.send('ctl:tab', tab)
    return
  }
  controlWin = new BrowserWindow({
    width: 1000,
    height: 680,
    minWidth: 860,
    minHeight: 560,
    title: '鲸鱼娘 · 控制中心',
    backgroundColor: '#f4f7fd',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(ROOT, 'control-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  })
  const base = hostBase()
  if (base) controlWin.loadURL(base + '/control.html')
  else controlWin.loadFile(path.join(ROOT, 'control.html'))
  controlWin.once('ready-to-show', () => controlWin.show())
  controlWin.on('closed', () => {
    controlWin = null
  })
  controlWin.webContents.setWindowOpenHandler(({ url: target }) => {
    try {
      shell.openExternal(target)
    } catch (err) {}
    return { action: 'deny' }
  })
  controlWin.webContents.on('console-message', (e, level, message, line, sourceId) => {
    flog('[ctl:' + level + ']', message, sourceId ? '(' + path.basename(String(sourceId)) + ':' + line + ')' : '')
  })
}

// —— 通用 HTTP 代理：控制中心直接操作宿主上的 /dsh-whale/* 路由 ——
ipcMain.handle('ctl:req', async (event, opts) => {
  const base = hostBase()
  if (!base) return { ok: false, status: 0, json: { ok: false, error: '宿主未就绪' } }
  const method = String((opts && opts.method) || 'GET').toUpperCase()
  const p = String((opts && opts.path) || '/')
  const body = opts && opts.body != null ? JSON.stringify(opts.body) : undefined
  try {
    const r = await fetch(base + p, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body,
    })
    const text = await r.text()
    let json = null
    try {
      json = JSON.parse(text)
    } catch (err) {}
    return { ok: r.ok, status: r.status, json, text: json ? null : text }
  } catch (err) {
    return { ok: false, status: 0, json: { ok: false, error: String((err && err.message) || err) } }
  }
})

ipcMain.handle('ctl:size:get', async () => {
  const base = hostBase()
  if (!base) return {}
  try {
    return await (await fetch(base + '/dsh-whale/size.json', { cache: 'no-store' })).json()
  } catch (err) {
    return {}
  }
})

ipcMain.handle('ctl:size:put', async (event, patch) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  try {
    const cur = await (await fetch(base + '/dsh-whale/size.json', { cache: 'no-store' })).json()
    const next = Object.assign({}, cur, patch || {})
    const r = await fetch(base + '/dsh-whale/size.json', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(next),
    })
    const j = await r.json().catch(() => null)
    if (r.ok) nudgeWidgetResync()
    return { ok: r.ok, size: next, error: j && j.error }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:snap:get', async () => {
  const raw = await widgetEval(
    "(() => { try { return localStorage.getItem('dshw-snap') || '' } catch (e) { return '' } })()"
  )
  try {
    return raw ? JSON.parse(String(raw)) : null
  } catch (err) {
    return null
  }
})

ipcMain.handle('ctl:snap:put', async (event, cfg) => {
  if (!win || win.isDestroyed()) return { ok: false, error: '挂件窗口未就绪' }
  try {
    const payload = JSON.stringify(JSON.stringify(cfg || {}))
    await widgetEval("(() => { try { localStorage.setItem('dshw-snap', " + payload + "); return true } catch (e) { return false } })()")
    setTimeout(() => {
      if (win && !win.isDestroyed()) win.reload()
    }, 220)
    return { ok: true }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

// —— 额度与报警（桌面版扩展，存在自己的配置文件里） ——
function budgetFile() {
  try {
    return path.join(app.getPath('userData'), 'whale-budget.json')
  } catch (err) {
    return path.join(ROOT, 'whale-budget.json')
  }
}
function readBudget() {
  try {
    return JSON.parse(fs.readFileSync(budgetFile(), 'utf8')) || {}
  } catch (err) {
    return {}
  }
}
function writeBudget(patch) {
  const next = Object.assign({}, readBudget(), patch || {})
  try {
    fs.mkdirSync(path.dirname(budgetFile()), { recursive: true })
    fs.writeFileSync(budgetFile(), JSON.stringify(next, null, 2), 'utf8')
  } catch (err) {}
  return next
}
ipcMain.handle('ctl:budget:get', async () => readBudget())
ipcMain.handle('ctl:budget:put', async (event, patch) => ({ ok: true, budget: writeBudget(patch) }))

// —— 各平台每日用量快照（给「使用图表」切换其他平台用） ——
// 宿主（挂件 bundle）只给每个模型「当前余额 + 今日已用」，没有每日历史；
// 这里每 5 分钟采一次，把当天 todayUsage 按天累积成历史，控制中心才能画柱状图。
function apiUsageFile() {
  try {
    return path.join(app.getPath('userData'), 'api-usage-daily.json')
  } catch (err) {
    return path.join(ROOT, 'api-usage-daily.json')
  }
}
function readApiUsage() {
  try {
    const d = JSON.parse(fs.readFileSync(apiUsageFile(), 'utf8'))
    if (d && typeof d === 'object' && d.models) return d
    return { version: 1, models: {} }
  } catch (err) {
    return { version: 1, models: {} }
  }
}
function writeApiUsage(next) {
  try {
    fs.mkdirSync(path.dirname(apiUsageFile()), { recursive: true })
    fs.writeFileSync(apiUsageFile(), JSON.stringify(next, null, 2), 'utf8')
  } catch (err) {}
  return next
}
function dayKeyLocal(t) {
  const d = t || new Date()
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')
}
let apiUsageBusy = false
async function sampleApiUsage() {
  const base = hostBase()
  if (!base || apiUsageBusy) return null
  apiUsageBusy = true
  try {
    const ctl = new AbortController()
    const timer = setTimeout(() => ctl.abort(), 9000)
    const r = await fetch(base + '/dsh-whale/api-models.json', { cache: 'no-store', signal: ctl.signal })
    clearTimeout(timer)
    const data = await r.json()
    const models = (data && Array.isArray(data.models)) ? data.models : []
    const db = readApiUsage()
    db.version = 1
    db.models = db.models || {}
    const now = new Date()
    const today = dayKeyLocal(now)
    const tooOld = dayKeyLocal(new Date(now.getTime() - 130 * 86400000))
    for (const m of models) {
      if (!m || !m.id) continue
      const cur = String(m.currency || 'CNY').toUpperCase()
      const entry = db.models[m.id] || { name: m.name || m.id, currency: cur, days: {} }
      entry.name = m.name || entry.name || m.id
      entry.currency = cur
      entry.builtin = !!m.builtin
      entry.updatedAt = now.getTime()
      if (!entry.days || typeof entry.days !== 'object') entry.days = {}
      // todayUsage 是宿主算出来的「当天累计」（余额观测差 or 会话事件估算），取当天最大值当历史
      const usage = Number(m.todayUsage)
      const amt = Number.isFinite(usage) && usage > 0 ? usage : 0
      const prev = entry.days[today] ? Number(entry.days[today].amount) || 0 : 0
      entry.days[today] = {
        amount: Math.max(prev, amt),
        currency: String(m.todayUsageCurrency || cur).toUpperCase(),
        source: m.usageSource || (m.balanceMode === 'events' ? 'events' : ''),
        observedAt: now.getTime(),
      }
      for (const k of Object.keys(entry.days)) {
        if (String(k) < tooOld) delete entry.days[k]
      }
      db.models[m.id] = entry
    }
    db.sampledAt = now.getTime()
    return writeApiUsage(db)
  } catch (err) {
    return null
  } finally {
    apiUsageBusy = false
  }
}
ipcMain.handle('ctl:api-usage:get', async () => {
  // 打开图表时顺手采一次，保证「今天」这根柱是最新的
  await sampleApiUsage()
  return readApiUsage()
})
setTimeout(() => { sampleApiUsage().catch(() => {}) }, 20000)
setInterval(() => { sampleApiUsage().catch(() => {}) }, 5 * 60 * 1000)

// ---------------- 点击动效（挂件的按压形变幅度 / 速度） ----------------
// 幅度写进挂件的 window.__whaleTap（vendor 已打 [click-tap-patch] 钩子），
// 速度只是 .dshwv-body 的 transition-duration —— 用 CSS 变量注入，不碰 bundle。
function numOr(v, d, min, max) {
  const n = Number(v)
  if (!isFinite(n)) return d
  return Math.max(min, Math.min(max, n))
}

function tapCfg() {
  const c = readConfig().tap || {}
  return {
    on: c.on !== false,
    amp: numOr(c.amp, 0.12, 0, 0.35),
    dur: numOr(c.dur, 0.22, 0.05, 0.9),
  }
}

function pushTap() {
  const c = tapCfg()
  const js =
    '(() => { try {' +
    ' window.__whaleTap = { on: ' + (c.on ? 'true' : 'false') + ', amp: ' + c.amp + ' };' +
    " document.documentElement.style.setProperty('--whale-tap-dur', '" + c.dur + "s');" +
    " if (!document.getElementById('whale-tap-style')) {" +
    "  var st = document.createElement('style'); st.id = 'whale-tap-style';" +
    "  st.textContent = '.dshwv-body{transition:transform var(--whale-tap-dur,.22s) cubic-bezier(.34,1.56,.64,1)}';" +
    '  document.head.appendChild(st);' +
    ' }' +
    ' return true } catch (e) { return false } })()'
  return widgetEval(js)
}

ipcMain.handle('ctl:tap:get', async () => tapCfg())
ipcMain.handle('ctl:tap:put', async (event, patch) => {
  const next = Object.assign({}, tapCfg(), patch || {})
  writeConfig({
    tap: {
      on: next.on !== false,
      amp: numOr(next.amp, 0.12, 0, 0.35),
      dur: numOr(next.dur, 0.22, 0.05, 0.9),
    },
  })
  const cfg = tapCfg()
  await pushTap()
  return { ok: true, tap: cfg }
})

// ---------------- Live2D 形象 ----------------
// 模型放在用户数据目录（不随程序分发），每个模型一个文件夹，里面有 .model3.json。
// 挂件里用 /whale-lib/layer.js 加载 pixi + cubism4 + core，画在一层 canvas 上；
// 原来的 <img> 只是变透明 —— 命中测试和拖拽都挂在它身上，不能摘。
function live2dRoot() {
  let dir
  try {
    dir = path.join(app.getPath('userData'), 'live2d-models')
  } catch (err) {
    dir = path.join(ROOT, 'live2d-models')
  }
  try {
    fs.mkdirSync(dir, { recursive: true })
  } catch (err) {}
  return dir
}

function findModelFiles(dir, depth) {
  const out = []
  if (depth > 3) return out
  let items = []
  try {
    items = fs.readdirSync(dir)
  } catch (err) {
    return out
  }
  for (const name of items) {
    const p = path.join(dir, name)
    let st = null
    try {
      st = fs.statSync(p)
    } catch (err) {
      continue
    }
    if (st.isDirectory()) out.push(...findModelFiles(p, depth + 1))
    else if (/\.model3\.json$/i.test(name)) out.push(p)
  }
  return out
}

function listLive2DModels() {
  const root = live2dRoot()
  const out = []
  let dirs = []
  try {
    dirs = fs.readdirSync(root)
  } catch (err) {
    return out
  }
  for (const id of dirs) {
    const dir = path.join(root, id)
    try {
      if (!fs.statSync(dir).isDirectory()) continue
    } catch (err) {
      continue
    }
    const files = findModelFiles(dir, 0)
    if (!files.length) continue
    // 优先取最浅的那个（多数模型就是 <id>/xxx.model3.json）
    files.sort((a, b) => a.split(path.sep).length - b.split(path.sep).length)
    const modelFile = files[0]
    const rel = path.relative(dir, modelFile).split(path.sep).join('/')
    let groups = []
    let expressions = []
    let cubism = 4
    try {
      const j = JSON.parse(fs.readFileSync(modelFile, 'utf8'))
      const fr = (j && j.FileReferences) || {}
      groups = Object.keys(fr.Motions || {})
      expressions = (fr.Expressions || []).map((x) => (x && x.Name) || '').filter(Boolean)
      if (j && j.Version && Number(j.Version) < 3) cubism = 2
    } catch (err) {}
    out.push({
      id,
      name: id,
      file: rel,
      url: '/whale-l2d/' + encodeURIComponent(id) + '/' + rel.split('/').map(encodeURIComponent).join('/'),
      groups,
      expressions,
      cubism,
    })
  }
  out.sort((a, b) => a.id.localeCompare(b.id))
  return out
}

function live2dCfg() {
  const c = readConfig().live2d || {}
  return {
    on: c.on === true,
    id: typeof c.id === 'string' ? c.id : '',
    scale: numOr(c.scale, 1, 0.3, 3),
    offsetX: numOr(c.offsetX, 0, -1, 1),
    offsetY: numOr(c.offsetY, 0, -1, 1),
    follow: c.follow !== false,
    blink: c.blink !== false,
    idleGroup: typeof c.idleGroup === 'string' ? c.idleGroup : 'Idle',
    // '' / '*' = 在除待机组以外的所有动作组里随机（多数模型每组只有 1 个动作）
    // 'none'   = 不播；'A,B' = 指定多组
    clickGroup: typeof c.clickGroup === 'string' ? c.clickGroup : '*',
    clickExpr: c.clickExpr === true,
    speed: numOr(c.speed, 1, 0.2, 2.5),
  }
}

async function pushLive2D() {
  if (!win || win.isDestroyed()) return { ok: false, error: '挂件窗口未就绪' }
  const cfg = live2dCfg()
  if (!cfg.on) {
    await widgetEval('(() => { try { if (window.__whaleL2D) window.__whaleL2D.stop() } catch (e) {} return true })()')
    return { ok: true, running: false }
  }
  const models = listLive2DModels()
  const model = models.find((m) => m.id === cfg.id) || models[0]
  if (!model) return { ok: false, error: '还没有导入任何 Live2D 模型' }

  const loaded = await widgetEval(
    'new Promise((res) => { if (window.__whaleL2D) return res(true);' +
      " var s = document.createElement('script'); s.src = '/whale-lib/layer.js';" +
      ' s.onload = function () { res(!!window.__whaleL2D) }; s.onerror = function () { res(false) };' +
      ' document.head.appendChild(s) })'
  )
  if (!loaded) return { ok: false, error: '渲染脚本没加载上' }

  const payload = JSON.stringify(
    Object.assign({}, cfg, {
      url: model.url,
      modelId: model.id,
      idleGroup: cfg.idleGroup || (model.groups.includes('Idle') ? 'Idle' : model.groups[0] || ''),
    })
  )
  const r = await widgetEval('window.__whaleL2D.apply(' + payload + ')')
  flog('[l2d] apply ->', r)
  return r && typeof r === 'object' ? r : { ok: false, error: '渲染层没有返回结果' }
}

ipcMain.handle('ctl:l2d:state', async () => ({
  cfg: live2dCfg(),
  models: listLive2DModels(),
  dir: live2dRoot(),
}))

ipcMain.handle('ctl:l2d:put', async (event, patch) => {
  const next = Object.assign({}, live2dCfg(), patch || {})
  writeConfig({
    live2d: {
      on: next.on === true,
      id: String(next.id || ''),
      scale: numOr(next.scale, 1, 0.3, 3),
      offsetX: numOr(next.offsetX, 0, -1, 1),
      offsetY: numOr(next.offsetY, 0, -1, 1),
      follow: next.follow !== false,
      blink: next.blink !== false,
      idleGroup: String(next.idleGroup || ''),
      clickGroup: String(next.clickGroup == null ? '*' : next.clickGroup),
      clickExpr: next.clickExpr === true,
      speed: numOr(next.speed, 1, 0.2, 2.5),
    },
  })
  const result = await pushLive2D()
  return { ok: true, cfg: live2dCfg(), result }
})

ipcMain.handle('ctl:l2d:import', async () => {
  const dir = await pickFile({
    title: '选择 Live2D 模型文件夹（里面要有 .model3.json）',
    properties: ['openDirectory'],
  })
  if (!dir) return { ok: false, cancelled: true }
  try {
    const files = findModelFiles(dir, 0)
    if (!files.length) return { ok: false, error: '这个文件夹里没找到 .model3.json' }
    const base = path.basename(dir).replace(/[\\/:*?"<>|]/g, '_').slice(0, 24) || 'model'
    const root = live2dRoot()
    let id = base
    let n = 1
    while (fs.existsSync(path.join(root, id))) {
      id = base + '-' + n
      n += 1
    }
    fs.cpSync(dir, path.join(root, id), { recursive: true })
    return { ok: true, id, models: listLive2DModels() }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:l2d:delete', async (event, id) => {
  const name = String(id || '')
  if (!name) return { ok: false, error: '缺少模型 id' }
  const root = live2dRoot()
  const dir = path.join(root, name)
  if (!path.resolve(dir).startsWith(path.resolve(root) + path.sep)) return { ok: false, error: '路径不合法' }
  try {
    fs.rmSync(dir, { recursive: true, force: true })
    const cfg = live2dCfg()
    if (cfg.id === name) writeConfig({ live2d: Object.assign({}, cfg, { id: '', on: false }) })
    await pushLive2D()
    return { ok: true, models: listLive2DModels() }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:l2d:refresh', async () => {
  const r = await pushLive2D()
  return { ok: true, models: listLive2DModels(), result: r }
})

// —— 角色改名 ——
ipcMain.handle('ctl:role-rename', async (event, payload) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  const id = String((payload && payload.id) || '')
  const name = String((payload && payload.name) || '').trim().slice(0, 20)
  if (!id || !name) return { ok: false, error: '参数不完整' }
  try {
    const dir = path.join(host.home, 'whale-roles')
    const file = path.join(dir, 'roles.json')
    const raw = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : { version: 1, roles: [] }
    const role = (raw.roles || []).find((r) => r && r.id === id)
    if (!role) return { ok: false, error: '没找到这个角色' }
    role.name = name
    fs.writeFileSync(file, JSON.stringify(raw, null, 2), 'utf8')
    const list = await (await fetch(base + '/dsh-whale/roles.json', { cache: 'no-store' })).json()
    return { ok: true, roles: list.roles }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

// —— 文件选择 + 导入 ——
function pickFile(options) {
  return new Promise((resolve) => {
    const parent = controlWin && !controlWin.isDestroyed() ? controlWin : win
    const { dialog } = require('electron')
    dialog
      .showOpenDialog(parent, options)
      .then((r) => resolve(r && !r.canceled && r.filePaths && r.filePaths[0] ? r.filePaths[0] : null))
      .catch(() => resolve(null))
  })
}

function sniffRoleFormat(file, buf) {
  const ext = path.extname(file).toLowerCase()
  if (ext === '.gif' || (buf.length > 6 && buf.slice(0, 3).toString() === 'GIF')) return 'gif'
  if (ext === '.apng') return 'apng'
  // PNG 里的 acTL 块 = APNG
  try {
    if (buf.includes(Buffer.from('acTL'))) return 'apng'
  } catch (err) {}
  return 'png'
}

ipcMain.handle('ctl:import-role', async (event, payload) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  const file = await pickFile({
    title: '选择角色图片',
    filters: [{ name: '图片', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'apng'] }],
  })
  if (!file) return { ok: false, cancelled: true }
  try {
    const buf = fs.readFileSync(file)
    if (buf.length > 20 * 1024 * 1024) return { ok: false, error: '图片超过 20MB' }
    const format = sniffRoleFormat(file, buf)
    const ext = path.extname(file).toLowerCase()
    const mime =
      ext === '.gif' || format === 'gif' ? 'image/gif'
        : ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg'
          : ext === '.webp' ? 'image/webp'
            : 'image/png'
    const dataUrl = 'data:' + mime + ';base64,' + buf.toString('base64')
    const name =
      (payload && payload.name ? String(payload.name) : path.basename(file, path.extname(file))).slice(0, 20) || '新角色'

    const body = { name, image: dataUrl }
    if (format === 'gif' || format === 'apng') body.format = format
    const r = await fetch(base + '/dsh-whale/roles.json', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    const j = await r.json().catch(() => null)
    if (!r.ok || !j || j.ok === false) return { ok: false, error: (j && j.error) || '保存失败' }

    // 替换模式：导入成功后删掉旧角色
    if (payload && payload.replaceId && payload.replaceId !== 'default') {
      try {
        await fetch(base + '/dsh-whale/role-delete.json', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: payload.replaceId }),
        })
      } catch (err) {}
    }
    const list = await (await fetch(base + '/dsh-whale/roles.json', { cache: 'no-store' })).json()
    return { ok: true, roles: list.roles, format }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.handle('ctl:import-audio', async (event, payload) => {
  const base = hostBase()
  if (!base) return { ok: false, error: '宿主未就绪' }
  const file = await pickFile({
    title: '选择音频片段',
    filters: [{ name: '音频', extensions: ['wav'] }],
  })
  if (!file) return { ok: false, cancelled: true }
  try {
    const buf = fs.readFileSync(file)
    if (buf.length > 8 * 1024 * 1024) return { ok: false, error: '音频超过 8MB' }
    const dataUrl = 'data:audio/wav;base64,' + buf.toString('base64')
    const name = (payload && payload.name ? String(payload.name) : path.basename(file, path.extname(file))).slice(0, 40) || '未命名音频'
    const r = await fetch(base + '/dsh-whale/audio.json', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'upload-fragment', name, audio: dataUrl }),
    })
    const j = await r.json().catch(() => null)
    if (!r.ok || !j || j.ok === false) return { ok: false, error: (j && j.error) || '保存失败' }
    return { ok: true, audio: j }
  } catch (err) {
    return { ok: false, error: String((err && err.message) || err) }
  }
})

ipcMain.on('ctl:pick-image', () => {})
ipcMain.on('ctl:pick-audio', () => {})

ipcMain.handle('ctl:widget:reload', async () => {
  if (win && !win.isDestroyed()) win.reload()
  return { ok: true }
})

ipcMain.handle('ctl:widget:focus', async () => {
  if (!win || win.isDestroyed()) return { ok: false }
  try {
    win.setAlwaysOnTop(true)
    win.showInactive()
  } catch (err) {}
  setTimeout(() => {
    try {
      win.setAlwaysOnTop(false)
    } catch (err) {}
    pushToBottom()
  }, 900)
  return { ok: true }
})

ipcMain.handle('ctl:open-external', async (event, url) => {
  try {
    await shell.openExternal(String(url || ''))
    return { ok: true }
  } catch (err) {
    return { ok: false }
  }
})

ipcMain.handle('ctl:quit', async () => {
  app.isQuitting = true
  app.quit()
  return { ok: true }
})

// —— 额度/余量报警：主进程每 60 秒看一眼，超了就发系统通知（每天每类只响一次） ——
const alertState = { day: '', overDay: false, overMonth: false, low: false }
function notify(title, body, openUrl) {
  try {
    const { Notification } = require('electron')
    if (!Notification.isSupported()) return
    const n = new Notification({ title, body, silent: false })
    if (openUrl) {
      n.on('click', () => {
        try {
          shell.openExternal(openUrl)
        } catch (err) {}
      })
    }
    n.show()
  } catch (err) {}
}
// 报警通知点一下就跳 DeepSeek 官方：余额不足 → 充值页；超预算 → 用量页
const DS_TOPUP_URL = 'https://platform.deepseek.com/top_up'
const DS_USAGE_URL = 'https://platform.deepseek.com/usage'
async function budgetTick() {
  const base = hostBase()
  if (!base) return
  const b = readBudget()
  if (b.warnOn === false && b.overOn === false) return
  try {
    const rec = await (await fetch(base + '/dsh-whale/usage-records.json', { cache: 'no-store' })).json()
    const todayRec = (rec && rec.today) || {}
    const today = Number(todayRec.amount != null ? todayRec.amount : todayRec.total || 0)
    const days = (rec && rec.all && rec.all.days) || []
    const now = new Date()
    const ym = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0')
    let monthSum = 0
    for (const d of days) {
      const ds = String(d.day || d.date || '')
      if (ds.slice(0, 7) === ym) monthSum += Number(d.amount != null ? d.amount : d.total || 0)
    }
    const dayKey = now.toISOString().slice(0, 10)
    if (alertState.day !== dayKey) {
      alertState.day = dayKey
      alertState.overDay = false
      alertState.overMonth = false
      alertState.low = false
    }
    const daily = Number(b.daily || 0)
    const monthly = Number(b.monthly || 0)
    const warnPct = Number(b.warnPercent == null ? 20 : b.warnPercent)

    if (b.overOn !== false && daily > 0 && today > daily && !alertState.overDay) {
      alertState.overDay = true
      notify('今日额度已超', '今天已用 ¥' + today.toFixed(2) + '，超过计划额度 ¥' + daily.toFixed(2), DS_USAGE_URL)
    }
    if (b.overOn !== false && monthly > 0 && monthSum > monthly && !alertState.overMonth) {
      alertState.overMonth = true
      notify('本月额度已超', '本月已用 ¥' + monthSum.toFixed(2) + '，超过额度 ¥' + monthly.toFixed(2), DS_USAGE_URL)
    }
    if (b.warnOn !== false && monthly > 0) {
      const leftPct = ((monthly - monthSum) / monthly) * 100
      if (leftPct <= warnPct && !alertState.low) {
        alertState.low = true
        notify('本月额度快用完了', '剩余 ¥' + Math.max(0, monthly - monthSum).toFixed(2) + '（约 ' + Math.max(0, leftPct).toFixed(0) + '%）', DS_TOPUP_URL)
      }
    }
  } catch (err) {}
}
setInterval(budgetTick, 60000)

// ---------------- 托盘 ----------------
// 图标取自原插件的 assets（升级包不自带挂件素材），取不到就退回包内 ico
let pluginAssetsDir = ''
function trayIconCandidates() {
  const out = []
  if (pluginAssetsDir) {
    out.push(path.join(pluginAssetsDir, 'DSniang1.png'))
    out.push(path.join(pluginAssetsDir, '..', 'icon.png'))
  }
  out.push(path.join(ROOT, 'build', 'icon.ico'))
  return out
}
function createTray() {
  let image = null
  for (const p of trayIconCandidates()) {
    if (!fs.existsSync(p)) continue
    try {
      const { nativeImage } = require('electron')
      image = nativeImage.createFromPath(p).resize({ width: 20, height: 20 })
      break
    } catch (err) {}
  }
  try {
    tray = new Tray(image || undefined)
  } catch (err) {
    tray = null
    return
  }
  const menu = Menu.buildFromTemplate([
    {
      label: '唤到最前（临时）',
      click: () => {
        if (!win || win.isDestroyed()) return
        win.setAlwaysOnTop(true)
        win.showInactive()
        win.setAlwaysOnTop(false)
        setTimeout(pushToBottom, 600)
      },
    },
    { label: '重新载入', click: () => win && win.reload() },
    { label: '控制中心…', click: () => openControl() },
    { label: '账号与余额…', click: () => openSettings() },
    {
      label: '开机自启动',
      type: 'checkbox',
      checked: autostartEnabled(),
      click: (item) => {
        writeConfig({ autostart: !!item.checked })
        applyAutostart(!!item.checked)
      },
    },
    { type: 'separator' },
    {
      label: '退出',
      click: () => {
        app.isQuitting = true
        app.quit()
      },
    },
  ])
  tray.setToolTip('小鲸鱼 · 升级包（依附 dsh-whale-widget）')
  tray.setContextMenu(menu)
  tray.on('double-click', () => openControl())
}

// ---------------- 启动 ----------------
// 升级包依附原插件：先找到 dsh-whale-widget，找不到就给人话提示并退出
async function resolvePlugin() {
  let mod = null
  try {
    mod = await import(pathToFileURL(path.join(ROOT, 'server', 'plugin-locator.mjs')).href)
  } catch (err) {
    console.error('[whale] 插件定位模块加载失败:', err && err.message)
  }
  let found = null
  try {
    found = mod ? mod.locatePlugin({ explicit: readConfig().pluginDir, home: mod.defaultHome() }) : null
  } catch (err) {
    console.warn('[whale] 定位原插件出错:', err && err.message)
  }
  if (found) {
    pluginAssetsDir = path.join(found.dir, 'assets')
    console.log('[whale] 原插件: ' + found.dir + '（v' + found.version + '）')
    return found
  }
  const msg =
    '这个升级包依附原插件 dsh-whale-widget 运行，本机没有找到它。\n\n' +
    '请先安装原插件（DSH 里执行：dsh plugin --profile desktop add dsh-whale-widget），\n' +
    '或者用环境变量 WHALE_PLUGIN_DIR 指向它的安装目录，再重新启动。'
  console.error('[whale] ' + msg)
  try {
    require('electron').dialog.showErrorBox('缺少原插件 dsh-whale-widget', msg)
  } catch (err) {}
  app.isQuitting = true
  app.quit()
  return null
}

async function boot() {
  const shimPath = path.join(ROOT, 'server', 'host-shim.mjs')
  const { startHost } = await import(pathToFileURL(shimPath).href)

  const plugin = await resolvePlugin()
  if (!plugin) return

  // 余额来源：本机有 DSH 登录态就只读复用；别人拿到软件就在「账号与余额」里填自己的 API Key
  let account = null
  try {
    const webBalancePath = path.join(ROOT, 'server', 'web-balance.mjs')
    if (fs.existsSync(webBalancePath)) {
      const mod = await import(pathToFileURL(webBalancePath).href)
      if (typeof mod.createAccountService === 'function') {
        account = mod.createAccountService({ log: (s) => console.log(s) })
        accountService = account
        const st = account.status()
        console.log(
          '[whale] 余额来源: ' + (st.signedIn ? st.source + ' @ ' + st.origin : '未配置（可在托盘「账号与余额」里填）')
        )
      }
    }
  } catch (err) {
    console.warn('[whale] 网页余额模块未启用:', err && err.message)
  }

  host = await startHost({ port: PORT, account, plugin, live2dDir: live2dRoot(), onLog: (s) => console.log(s) })
  console.log('[whale] 宿主就绪:', host.url, '｜原插件', host.plugin ? 'v' + host.plugin.version : '?')

  createWindow(host.url)
  createTray()

  // 调试用：只看「其他 → 资源管理」这一页渲染出了什么

  // 调试用：点击动效 + Live2D 全链路（改配置 → 挂件里真的画出来）

  // 调试用：Live2D v2 —— 视线坐标、点击动作多样性、播放速度

  // 调试用：只看控制中心「角色库 → Live2D 形象」这一页渲染出了什么

  // 调试用：点一次「删除」走完整链路，确认按钮真的能改数据

  // 调试用：直接拉起设置窗口并截图，验证账号模块的 UI 链路
  // 调试用：只测「使用图表」页的平台切换


}

app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion')

app.whenReady().then(() => {
  applyAutostart(autostartEnabled())
  boot().catch((err) => {
    console.error('[whale] 启动失败:', err && (err.stack || err.message))
  })
})

app.on('window-all-closed', () => {
  app.quit()
})

app.on('before-quit', () => {
  if (bottomTimer) clearInterval(bottomTimer)
  try {
    if (host) host.close()
  } catch (err) {}
})
