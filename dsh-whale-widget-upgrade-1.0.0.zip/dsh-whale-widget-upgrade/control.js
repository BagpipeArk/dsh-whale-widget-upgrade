/* control.js —— 控制中心渲染层
   数据来源：① 同源宿主的 /dsh-whale/* 路由  ② 主进程 IPC（窗口动作 / 尺寸 / 吸附 / 额度） */
'use strict'

const $ = (sel, root) => (root || document).querySelector(sel)
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel))
const API = window.whaleCtl

/* ---------------- 小工具 ---------------- */
function h(tag, attrs, ...kids) {
  const n = document.createElement(tag)
  if (attrs) {
    for (const k of Object.keys(attrs)) {
      const v = attrs[k]
      if (v === null || v === undefined || v === false) continue
      if (k === 'class') n.className = v
      else if (k === 'text') n.textContent = v
      else if (k === 'html') n.innerHTML = v
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v)
      else if (k === 'checked' || k === 'disabled' || k === 'selected') n[k] = !!v
      else if (k === 'value') n.value = v
      else n.setAttribute(k, v)
    }
  }
  for (const kid of kids.flat()) {
    if (kid === null || kid === undefined || kid === false) continue
    n.appendChild(typeof kid === 'string' || typeof kid === 'number' ? document.createTextNode(String(kid)) : kid)
  }
  return n
}

function money(v, currency) {
  const n = Number(v || 0)
  const cur = currency === 'USD' ? '$' : '¥'
  if (Math.abs(n) >= 100) return cur + n.toFixed(1)
  return cur + (n >= 10 ? n.toFixed(2) : n.toFixed(3))
}

function setStatus(msg, kind) {
  const s = $('#status')
  s.textContent = msg
  s.style.color = kind === 'error' ? 'var(--danger)' : kind === 'ok' ? 'var(--ok)' : ''
  if (kind) {
    clearTimeout(setStatus._t)
    setStatus._t = setTimeout(() => {
      s.textContent = '就绪'
      s.style.color = ''
    }, 4000)
  }
}

function idOfDay(d) {
  const t = new Date(d + 'T00:00:00')
  return t
}

/* ---------------- 数据层 ---------------- */
const state = {
  tab: 'role',
  sub: { role: 'list', sound: 'volume', ledger: 'overview', misc: 'window' },
  roles: [],
  audio: { groups: [], fragments: [] },
  usage: null, // settings
  records: null,
  api: null,
  size: {},
  snap: null,
  budget: {},
  tap: null,
  l2d: null,
  balance: null,
  focusModel: 'deepseek',
  apiUsage: null,
  chartModel: null,
}

async function http(method, path, body) {
  const r = await API.req(method, path, body)
  if (!r) throw new Error('没有响应')
  if (r.json) {
    if (r.json.ok === false) throw new Error(r.json.error || ('HTTP ' + r.status))
    return r.json
  }
  if (!r.ok) throw new Error('HTTP ' + r.status)
  return r
}

async function loadCore() {
  const [roles, audio, usage, size, tap, l2d] = await Promise.all([
    http('GET', '/dsh-whale/roles.json').catch(() => ({ roles: [] })),
    http('GET', '/dsh-whale/audio.json').catch(() => ({ groups: [], fragments: [] })),
    http('GET', '/dsh-whale/usage-settings.json').catch(() => ({ settings: null })),
    API.getSize().catch(() => ({})),
    API.getTap().catch(() => null),
    API.getLive2D().catch(() => null),
  ])
  state.roles = roles.roles || []
  state.audio = { groups: audio.groups || [], fragments: audio.fragments || [] }
  state.usage = usage.settings || null
  state.size = size || {}
  if (tap) state.tap = tap
  if (l2d) state.l2d = l2d
}

async function loadLedger() {
  const [records, api, budget, balance, apiUsage] = await Promise.all([
    http('GET', '/dsh-whale/usage-records.json').catch(() => null),
    http('GET', '/dsh-whale/api-models.json').catch(() => null),
    API.getBudget().catch(() => ({})),
    http('GET', '/dsh-whale/balance.json').catch(() => null),
    API.getApiUsage().catch(() => null),
  ])
  state.records = records
  state.api = api
  state.budget = budget || {}
  state.balance = balance
  state.apiUsage = apiUsage
  if (api && Array.isArray(api.models) && api.models.length && !api.models.some((m) => m.id === state.focusModel)) {
    state.focusModel = api.models[0].id
  }
}

async function loadSnap() {
  try {
    state.snap = await API.getSnap()
  } catch (e) {
    state.snap = null
  }
}

async function saveUsage(patch) {
  const r = await http('PUT', '/dsh-whale/usage-settings.json', patch)
  const fresh = await http('GET', '/dsh-whale/usage-settings.json').catch(() => null)
  if (fresh && fresh.settings) state.usage = fresh.settings
  return r
}

async function saveSize(patch) {
  Object.assign(state.size, patch)
  const r = await API.putSize(patch)
  if (r && r.size) state.size = r.size
  return r
}

/* ---------------- 顶部 tab ---------------- */
const TABS = {
  role: {
    label: '角色库',
    subs: [
      { id: 'list', label: '形象库' },
      { id: 'tap', label: '点击动效' },
      { id: 'live2d', label: 'Live2D 形象' },
      { id: 'scale', label: '显示大小' },
    ],
  },
  sound: {
    label: '音效',
    subs: [
      { id: 'volume', label: '总开关与音量' },
      { id: 'groups', label: '音效组' },
      { id: 'fragments', label: '音频片段' },
      { id: 'events', label: '提示事件' },
    ],
  },
  ledger: {
    label: '小鲸鱼记账',
    subs: [
      { id: 'overview', label: '概览' },
      { id: 'quota', label: '额度与报警' },
      { id: 'charts', label: '使用图表' },
      { id: 'api', label: 'API 与模型' },
    ],
  },
  misc: {
    label: '其他',
    subs: [
      { id: 'window', label: '窗口与吸附' },
      { id: 'res', label: '资源管理' },
      { id: 'app', label: '程序' },
    ],
  },
}

function renderSubnav() {
  const nav = $('#subnav')
  nav.innerHTML = ''
  const def = TABS[state.tab]
  for (const s of def.subs) {
    nav.appendChild(
      h('button', {
        class: 'subnav-item' + (state.sub[state.tab] === s.id ? ' active' : ''),
        text: s.label,
        onclick: () => {
          state.sub[state.tab] = s.id
          render()
        },
      })
    )
  }
}

function renderTabs() {
  for (const b of $$('#tabs .tab')) {
    b.classList.toggle('active', b.dataset.tab === state.tab)
  }
}

let renderSeq = 0

async function render() {
  // 用代际号隔离并发渲染：慢的那次回来时发现已经过期，就直接丢掉，避免两页内容糊在一起
  const seq = ++renderSeq
  renderTabs()
  renderSubnav()
  const hint = $('#hint')
  const box = h('div', null)
  try {
    if (state.tab === 'role') await renderRole(box)
    else if (state.tab === 'sound') await renderSound(box)
    else if (state.tab === 'ledger') await renderLedger(box)
    else await renderMisc(box)
  } catch (err) {
    box.appendChild(h('div', { class: 'card' }, h('div', { class: 'tip', text: '读取失败：' + (err && err.message) })))
  }
  if (seq !== renderSeq) return
  const panel = $('#panel')
  panel.innerHTML = ''
  while (box.firstChild) panel.appendChild(box.firstChild)
  hint.textContent = ''
}

/* ================= 角色库 ================= */
function roleCard(role) {
  const card = h(
    'div',
    {
      class: 'rolecard' + (role.pinned ? ' active' : ''),
      title: role.name + (role.format !== 'png' ? '（' + role.format + ' 动态）' : ''),
      onclick: () => switchRole(role),
      oncontextmenu: (e) => {
        e.preventDefault()
        openRoleMenu(e, role)
      },
    },
    h('img', { src: role.url, alt: role.name }),
    h('div', { class: 'nm', text: role.name })
  )
  if (role.pinned) card.appendChild(h('div', { class: 'badge', text: '使用中' }))
  if (role.format === 'gif') card.appendChild(h('div', { class: 'fmt', text: 'GIF' }))
  else if (role.format === 'apng') card.appendChild(h('div', { class: 'fmt', text: 'APNG' }))
  return card
}

async function renderRole(panel) {
  const sub = state.sub.role
  if (sub === 'list') {
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '形象库', h('span', { class: 'sub', text: '左键切换 · 右键管理' })))
    const grid = h('div', { class: 'rolegrid' })
    for (const r of state.roles) grid.appendChild(roleCard(r))
    grid.appendChild(
      h(
        'div',
        {
          class: 'rolecard add',
          onclick: () => importRole(),
        },
        h('div', { class: 'plus', text: '+' }),
        h('div', { text: '导入角色' })
      )
    )
    card.appendChild(grid)
    panel.appendChild(card)

    panel.appendChild(
      h(
        'div',
        { class: 'card' },
        h('div', { class: 'card-title' }, '说明'),
        h('div', {
          class: 'tip',
          text: '支持 PNG / JPG / WEBP / GIF / APNG，单个文件不超过 20MB。宽高比不被裁切，按原图等比缩放。导入后点一下卡片就切到它，挂件会立刻换成这个形象。',
        })
      )
    )
    return
  }

  if (sub === 'tap') {
    const tap = Object.assign({ on: true, amp: 0.12, dur: 0.22 }, state.tap || {})
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '点击动效', h('span', { class: 'sub', text: '按下时鲸鱼娘怎么动' })))
    const save = async (patch) => {
      const r = await API.putTap(Object.assign({}, state.tap || tap, patch))
      if (r && r.tap) state.tap = r.tap
      setStatus('已生效，去点一下鲸鱼娘试试', 'ok')
      return r
    }

    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '按压缩放' }),
      switchEl(tap.on !== false, (v) => save({ on: v })),
      h('span', { class: 'tip', text: '关掉后按下不再形变，按压音效照旧' })
    ))

    const ampVal = h('span', { class: 'tip', text: Math.round((tap.amp || 0.12) * 100) + '%' })
    const ampRange = h('input', {
      type: 'range', min: '0', max: '0.35', step: '0.01', value: String(tap.amp || 0.12),
      oninput: (e) => { ampVal.textContent = Math.round(Number(e.target.value) * 100) + '%' },
      onchange: (e) => save({ amp: Number(e.target.value) }),
    })
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '运动幅度' }), ampRange, ampVal,
      h('span', { class: 'tip', text: '压扁多少。出厂 12%，往右压得越狠，往左越轻' })
    ))

    const durVal = h('span', { class: 'tip', text: Math.round((tap.dur || 0.22) * 1000) + ' ms' })
    const durRange = h('input', {
      type: 'range', min: '0.05', max: '0.9', step: '0.01', value: String(tap.dur || 0.22),
      oninput: (e) => { durVal.textContent = Math.round(Number(e.target.value) * 1000) + ' ms' },
      onchange: (e) => save({ dur: Number(e.target.value) }),
    })
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '运动速度' }), durRange, durVal,
      h('span', { class: 'tip', text: '回弹用多久。越短越脆，越长越软' })
    ))

    card.appendChild(h('div', { class: 'row' },
      h('button', { class: 'btn', text: '把挂件叫到前面', onclick: () => API.focusWidget() }),
      h('button', {
        class: 'btn', text: '恢复出厂 12% / 220ms',
        onclick: async () => { await save({ on: true, amp: 0.12, dur: 0.22 }); render() },
      })
    ))
    panel.appendChild(card)

    panel.appendChild(h('div', { class: 'card' },
      h('div', { class: 'card-title' }, '说明'),
      h('div', { class: 'tip', text: '这两个只影响「按住→松开」那一下的形变，和音效、和 Live2D 的待机动作都不冲突。改完立刻生效，不用重开。' })
    ))
    return
  }

  if (sub === 'live2d') {
    const info = state.l2d || { cfg: {}, models: [] }
    const cfg = Object.assign(
      { on: false, id: '', scale: 1, offsetX: 0, offsetY: 0, follow: true, blink: true, idleGroup: '', clickGroup: '*', clickExpr: false, speed: 1 },
      info.cfg || {}
    )
    const models = info.models || []
    const current = models.find((m) => m.id === cfg.id) || null
    const groups = (current && current.groups) || []

    const save = async (patch) => {
      const r = await API.putLive2D(Object.assign({}, cfg, patch))
      if (r && r.cfg) state.l2d = Object.assign({}, info, { cfg: r.cfg })
      const res = r && r.result
      if (res && res.ok === false) setStatus('没跑起来：' + res.error, 'error')
      else setStatus('已生效', 'ok')
      return r
    }

    panel.appendChild(h('div', { class: 'card' },
      h('div', { class: 'card-title' }, 'Live2D 形象', h('span', { class: 'sub', text: '会呼吸、会眨眼、能跟手' })),
      h('div', { class: 'row' },
        h('span', { class: 'label', text: '启用' }),
        switchEl(cfg.on === true, async (v) => {
          if (v && !models.length) {
            setStatus('先导入一个模型再开', 'error')
            return
          }
          const patch = { on: v }
          if (v && !cfg.id && models.length) patch.id = models[0].id
          const r = await API.putLive2D(Object.assign({}, cfg, patch))
          if (r && r.cfg) state.l2d = Object.assign({}, info, { cfg: r.cfg })
          render()
        }),
        h('span', { class: 'tip', text: '开了以后原来的图片形象会隐藏，命中范围照旧（还能拖、还能点）' })
      )
    ))

    const listCard = h('div', { class: 'card' },
      h('div', { class: 'card-title' }, '模型', h('span', { class: 'sub', text: models.length + ' 个' }))
    )
    const list = h('div', { class: 'list' })
    if (!models.length) {
      list.appendChild(h('div', { class: 'tip', text: '还没有模型。点下面的「导入模型文件夹」，选一个里面有 .model3.json 的文件夹。' }))
    }
    for (const m of models) {
      const active = m.id === cfg.id
      list.appendChild(h('div', { class: 'row' + (active ? ' row-active' : '') },
        h('span', { class: 'label', text: m.name + (m.cubism === 2 ? '（Cubism 2）' : '') }),
        h('span', { class: 'tip', text: (m.groups || []).length + ' 组动作 · ' + (m.expressions || []).length + ' 个表情' }),
        h('button', {
          class: 'btn', text: active ? '使用中' : '切换',
          onclick: async () => {
            if (active) return
            const r = await API.putLive2D(Object.assign({}, cfg, { id: m.id, on: true }))
            const st = await API.getLive2D()
            state.l2d = st
            render()
            setStatus('已切到「' + m.name + '」', 'ok')
          },
        }),
        h('button', {
          class: 'btn danger', text: '删除',
          onclick: async () => {
            if (!confirm('删掉模型「' + m.name + '」？文件会一起删掉。')) return
            const r = await API.deleteLive2D(m.id)
            if (r && r.ok) {
              state.l2d = await API.getLive2D()
              render()
              setStatus('已删除', 'ok')
            } else setStatus('删除失败：' + ((r && r.error) || '未知错误'), 'error')
          },
        })
      ))
    }
    listCard.appendChild(list)
    listCard.appendChild(h('div', { class: 'row' },
      h('button', {
        class: 'btn', text: '导入模型文件夹…',
        onclick: async () => {
          const r = await API.importLive2D()
          if (r && r.ok) {
            state.l2d = await API.getLive2D()
            render()
            setStatus('导入成功：' + r.id, 'ok')
          } else if (r && !r.cancelled) setStatus('导入失败：' + (r.error || '未知错误'), 'error')
        },
      }),
      h('button', {
        class: 'btn', text: '重新加载当前模型',
        onclick: async () => {
          const r = await API.refreshLive2D()
          const ok = !!(r && r.result && r.result.ok)
          setStatus(ok ? '已重新加载' : '重载失败', ok ? 'ok' : 'error')
        },
      })
    ))
    panel.appendChild(listCard)

    const view = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '显示'))
    const scaleVal = h('span', { class: 'tip', text: Number(cfg.scale).toFixed(2) + '×' })
    view.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '大小' }),
      h('input', {
        type: 'range', min: '0.3', max: '2', step: '0.02', value: String(cfg.scale),
        oninput: (e) => { scaleVal.textContent = Number(e.target.value).toFixed(2) + '×' },
        onchange: (e) => save({ scale: Number(e.target.value) }),
      }),
      scaleVal,
      h('span', { class: 'tip', text: '相对挂件底部那块区域的高度' })
    ))
    const oxVal = h('span', { class: 'tip', text: Math.round(cfg.offsetX * 100) + '%' })
    view.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '左右偏移' }),
      h('input', {
        type: 'range', min: '-0.5', max: '0.5', step: '0.01', value: String(cfg.offsetX),
        oninput: (e) => { oxVal.textContent = Math.round(Number(e.target.value) * 100) + '%' },
        onchange: (e) => save({ offsetX: Number(e.target.value) }),
      }),
      oxVal
    ))
    const oyVal = h('span', { class: 'tip', text: Math.round(cfg.offsetY * 100) + '%' })
    view.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '上下偏移' }),
      h('input', {
        type: 'range', min: '-0.5', max: '0.5', step: '0.01', value: String(cfg.offsetY),
        oninput: (e) => { oyVal.textContent = Math.round(Number(e.target.value) * 100) + '%' },
        onchange: (e) => save({ offsetY: Number(e.target.value) }),
      }),
      oyVal
    ))
    view.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '视线跟随' }),
      switchEl(cfg.follow !== false, (v) => save({ follow: v })),
      h('span', { class: 'tip', text: '眼睛和头跟着鼠标动' })
    ))
    view.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '自动眨眼' }),
      switchEl(cfg.blink !== false, (v) => save({ blink: v }))
    ))
    const spdVal = h('span', { class: 'tip', text: Number(cfg.speed || 1).toFixed(2) + '×' })
    view.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '播放速度' }),
      h('input', {
        type: 'range', min: '0.2', max: '2.5', step: '0.05', value: String(cfg.speed || 1),
        oninput: (e) => { spdVal.textContent = Number(e.target.value).toFixed(2) + '×' },
        onchange: (e) => save({ speed: Number(e.target.value) }),
      }),
      spdVal,
      h('span', { class: 'tip', text: '动作、呼吸、眨眼的整体快慢。1× 是原速' })
    ))
    panel.appendChild(view)

    // 点击动作：多数模型每个动作组只有 1 个动作，所以默认在「除待机组以外的所有组」里随机
    const act = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '动作'))
    act.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '待机动作' }),
      h('select', { onchange: (e) => save({ idleGroup: e.target.value }) },
        h('option', { value: '', text: '（默认 Idle）', selected: !cfg.idleGroup }),
        ...groups.map((g) => h('option', { value: g, text: g, selected: cfg.idleGroup === g }))
      ),
      h('span', { class: 'tip', text: '空着就循环 Idle 那一组' })
    ))
    const clickVal = !cfg.clickGroup ? '*' : cfg.clickGroup
    const clickOpts = [
      ['*', '全部动作随机（推荐）'],
      ['none', '不播（只做按压形变）'],
    ]
    act.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '点击动作' }),
      h('select', { onchange: (e) => save({ clickGroup: e.target.value }) },
        ...clickOpts.map(([v, t]) => h('option', { value: v, text: t, selected: clickVal === v })),
        ...groups.map((g) => h('option', { value: g, text: '只播 ' + g, selected: clickVal === g }))
      ),
      h('span', { class: 'tip', text: '点一下鲸鱼娘随机播一个；选中单组就只播那组' })
    ))
    act.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '点击换表情' }),
      switchEl(cfg.clickExpr === true, (v) => save({ clickExpr: v })),
      h('span', { class: 'tip', text: '点一下顺便随机换个表情（这个模型有 ' + ((current && (current.expressions || []).length) || 0) + ' 个）' })
    ))
    panel.appendChild(act)

    panel.appendChild(h('div', { class: 'card' },
      h('div', { class: 'card-title' }, '模型放哪儿、怎么来'),
      h('div', { class: 'tip', text: '只认 Cubism 3/4（.model3.json）。导入时选「整个模型文件夹」，里面要包含 moc3、贴图、动作；程序会复制一份到自己的模型库。' }),
      h('div', { class: 'tip', text: '模型库：' + (info.dir || '（未就绪）') }),
      h('div', { class: 'tip', text: '模型版权归原作者，程序只负责渲染，不代下载也不分发模型。' })
    ))
    return
  }

  // scale
  const scale = Number(state.size.scale || 1.5)
  const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '显示大小'))
  const val = h('span', { class: 'tip', text: scale.toFixed(2) + '×' })
  const range = h('input', {
    type: 'range', min: '0.6', max: '4', step: '0.05', value: String(scale),
    oninput: (e) => { val.textContent = Number(e.target.value).toFixed(2) + '×' },
    onchange: async (e) => {
      await saveSize({ scale: Number(e.target.value) })
      setStatus('大小已保存', 'ok')
    },
  })
  const num = h('input', {
    type: 'number', min: '0.6', max: '4', step: '0.05', value: String(scale),
    onchange: async (e) => {
      const v = Math.min(4, Math.max(0.6, Number(e.target.value) || 1.5))
      range.value = String(v)
      val.textContent = v.toFixed(2) + '×'
      await saveSize({ scale: v })
      setStatus('大小已保存', 'ok')
    },
  })
  card.appendChild(h('div', { class: 'row' }, h('span', { class: 'label', text: '缩放' }), range, num, val))
  card.appendChild(h('div', { class: 'row' },
    h('button', { class: 'btn', text: '恢复 1.5×', onclick: async () => { await saveSize({ scale: 1.5 }); state.sub.role = 'scale'; render() } })
  ))
  panel.appendChild(card)
}

function switchEl(checked, onchange) {
  const input = h('input', { type: 'checkbox', checked })
  input.addEventListener('change', () => onchange(input.checked))
  return h('label', { class: 'switch' }, input, h('i'))
}

async function switchRole(role) {
  if (role.pinned) return
  try {
    const r = await http('POST', '/dsh-whale/role-pin.json', { id: role.id, pinned: true })
    state.roles = r.roles || state.roles
    await API.focusWidget()
    render()
    setStatus('已切换到「' + role.name + '」', 'ok')
  } catch (err) {
    setStatus('切换失败：' + err.message, 'error')
  }
}

async function importRole() {
  try {
    setStatus('正在导入…')
    const r = await API.importRole({})
    if (!r || !r.ok) {
      setStatus('导入失败：' + ((r && r.error) || '未知原因'), 'error')
      return
    }
    state.roles = r.roles || state.roles
    render()
    setStatus('导入成功', 'ok')
  } catch (err) {
    setStatus('导入失败：' + err.message, 'error')
  }
}

function openRoleMenu(e, role) {
  const menu = $('#ctxmenu')
  menu.innerHTML = ''
  const add = (label, fn, danger) =>
    menu.appendChild(h('button', { class: danger ? 'danger' : '', text: label, onclick: () => { closeCtx(); fn() } }))
  add('切换到这个形象', () => switchRole(role))
  add('重命名…', () => renameRole(role))
  add('更换图片…', () => replaceRoleImage(role))
  add('单独调整大小', () => { state.tab = 'role'; state.sub.role = 'scale'; render() })
  menu.appendChild(h('div', { class: 'sep' }))
  add('删除这个形象', () => deleteRole(role), true)
  menu.classList.add('open')
  const rect = menu.getBoundingClientRect()
  const x = Math.min(e.clientX, window.innerWidth - rect.width - 8)
  const y = Math.min(e.clientY, window.innerHeight - rect.height - 8)
  menu.style.left = x + 'px'
  menu.style.top = y + 'px'
}

function closeCtx() {
  $('#ctxmenu').classList.remove('open')
}

async function renameRole(role) {
  const name = await promptModal('重命名形象', role.name)
  if (name === null) return
  const r = await API.renameRole(role.id, name)
  if (r && r.ok) {
    state.roles = r.roles || state.roles
    render()
    setStatus('已重命名', 'ok')
  } else {
    setStatus('重命名失败：' + ((r && r.error) || ''), 'error')
  }
}

async function replaceRoleImage(role) {
  if (role.id === 'default') {
    setStatus('默认小鲸鱼不支持替换图片，可以先导入一个新形象再删除旧的', 'error')
    return
  }
  const ok = await confirmModal('更换图片', '会导入一张新图并替换「' + role.name + '」，原图删除。继续？')
  if (!ok) return
  const r = await API.importRole({ name: role.name, replaceId: role.id })
  if (r && r.ok) {
    state.roles = r.roles || state.roles
    render()
    setStatus('已更换图片', 'ok')
  } else {
    setStatus('更换失败：' + ((r && r.error) || ''), 'error')
  }
}

async function deleteRole(role) {
  if (role.id === 'default') {
    setStatus('默认形象不能删除', 'error')
    return
  }
  const ok = await confirmModal('删除形象', '确定删除「' + role.name + '」？图片文件会一起删掉。')
  if (!ok) return
  try {
    const r = await http('POST', '/dsh-whale/role-delete.json', { id: role.id })
    state.roles = r.roles || state.roles
    render()
    setStatus('已删除', 'ok')
  } catch (err) {
    setStatus('删除失败：' + err.message, 'error')
  }
}

/* ================= 音效 ================= */
function fragOptions(selected) {
  return state.audio.fragments.map((f) =>
    h('option', { value: 'frag:' + f.id, text: f.name + (f.preset ? '' : ''), selected: selected === 'frag:' + f.id })
  )
}

async function renderSound(panel) {
  const sub = state.sub.sound
  const soundOn = state.size.sound !== false
  const vol = Number(state.size.vol == null ? 0.9 : state.size.vol)

  if (sub === 'volume') {
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '总开关与音量'))
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '音效总开关' }),
      switchEl(soundOn, async (v) => { await saveSize({ sound: v }); setStatus(v ? '已开启音效' : '已关闭音效', 'ok') })
    ))
    const volText = h('span', { class: 'tip', text: Math.round(vol * 100) + '%' })
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '音量' }),
      h('input', {
        type: 'range', min: '0', max: '1', step: '0.05', value: String(vol),
        oninput: (e) => { volText.textContent = Math.round(Number(e.target.value) * 100) + '%' },
        onchange: async (e) => { await saveSize({ vol: Number(e.target.value) }); setStatus('音量已保存', 'ok') },
      }),
      volText
    ))
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '按压音效' }),
      switchEl(state.size.pressOn !== false, async (v) => { await saveSize({ pressOn: v }); setStatus('已保存', 'ok') })
    ))
    panel.appendChild(card)
    return
  }

  if (sub === 'groups') {
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '音效组', h('span', { class: 'sub', text: '一组 = 按下音 + 松开音' })))
    const list = h('div', { class: 'list' })
    const current = state.size.soundSet || 'duck'
    for (const g of state.audio.groups) {
      list.appendChild(h('div', { class: 'list-item' },
        h('input', {
          type: 'radio', name: 'soundset', checked: g.id === current,
          onchange: async () => { await saveSize({ soundSet: g.id }); setStatus('已切到「' + g.name + '」', 'ok'); render() },
        }),
        h('span', { class: 'name', text: g.name }),
        g.preset ? h('span', { class: 'tag', text: '内置' }) : null,
        h('span', { class: 'meta', text: fragName(g.press) + ' / ' + fragName(g.release) }),
        g.preset ? null : h('button', {
          class: 'btn danger ghost', text: '删除',
          onclick: async () => {
            if (!(await confirmModal('删除音效组', '确定删除「' + g.name + '」？'))) return
            await http('POST', '/dsh-whale/audio.json', { action: 'delete-group', id: g.id })
            await loadCore(); render(); setStatus('已删除', 'ok')
          },
        })
      ))
    }
    if (!state.audio.groups.length) list.appendChild(h('div', { class: 'empty', text: '还没有音效组' }))
    card.appendChild(list)
    card.appendChild(h('div', { class: 'row' },
      h('button', { class: 'btn primary', text: '新建音效组', onclick: () => newAudioGroup() })
    ))
    panel.appendChild(card)
    return
  }

  if (sub === 'fragments') {
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '音频片段', h('span', { class: 'sub', text: '支持 WAV' })))
    const list = h('div', { class: 'list' })
    for (const f of state.audio.fragments) {
      list.appendChild(h('div', { class: 'list-item' },
        h('span', { class: 'name', text: f.name }),
        f.preset ? h('span', { class: 'tag', text: '内置' }) : null,
        h('button', {
          class: 'btn ghost', text: '试听',
          onclick: () => {
            try {
              const a = new Audio('/dsh-whale/audio-fragment.wav?id=' + encodeURIComponent(f.id))
              a.volume = Number(state.size.vol == null ? 0.9 : state.size.vol)
              a.play().catch(() => setStatus('试听失败', 'error'))
            } catch (e) {}
          },
        }),
        f.preset ? null : h('button', {
          class: 'btn danger ghost', text: '删除',
          onclick: async () => {
            if (!(await confirmModal('删除片段', '确定删除「' + f.name + '」？'))) return
            await http('POST', '/dsh-whale/audio.json', { action: 'delete-fragment', id: f.id })
            await loadCore(); render(); setStatus('已删除', 'ok')
          },
        })
      ))
    }
    if (!state.audio.fragments.length) list.appendChild(h('div', { class: 'empty', text: '还没有音频片段' }))
    card.appendChild(list)
    card.appendChild(h('div', { class: 'row' },
      h('button', {
        class: 'btn primary', text: '导入 WAV 片段',
        onclick: async () => {
          const r = await API.importAudio({})
          if (r && r.ok) { await loadCore(); render(); setStatus('已导入', 'ok') }
          else setStatus('导入失败：' + ((r && r.error) || ''), 'error')
        },
      })
    ))
    panel.appendChild(card)
    return
  }

  // events
  const s = state.usage || {}
  const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '提示事件', h('span', { class: 'sub', text: '哪些时候出声、出哪个' })))

  const ev = s.events || {}
  const taskEnd = s.taskEnd || { on: true, sel: 'frag:cost_a' }
  card.appendChild(h('div', { class: 'row' },
    h('span', { class: 'label', text: '任务结束音效' }),
    switchEl(taskEnd.on !== false, async (v) => { await saveUsage({ taskEnd: Object.assign({}, taskEnd, { on: v }) }); setStatus('已保存', 'ok') }),
    h('select', {
      onchange: async (e) => { await saveUsage({ taskEnd: Object.assign({}, taskEnd, { sel: e.target.value }) }); setStatus('已保存', 'ok') },
    }, fragOptions(taskEnd.sel))
  ))

  const turnCost = ev.turnCost || { vol: 1, bubbleOn: true }
  card.appendChild(h('div', { class: 'row' },
    h('span', { class: 'label', text: '每轮消耗提示' }),
    switchEl(state.size.turnCostOn !== false, async (v) => { await saveSize({ turnCostOn: v }); setStatus('已保存', 'ok') }),
    h('span', { class: 'tip', text: '对话结束弹一次本轮花了多少' })
  ))

  for (const [key, title] of [['question', '提问提示'], ['approval', '授权提示']]) {
    const e2 = ev[key] || {}
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: title }),
      switchEl(e2.on !== false, async (v) => {
        await saveUsage({ events: Object.assign({}, ev, { [key]: Object.assign({}, e2, { on: v }) }) })
        setStatus('已保存', 'ok')
      }),
      switchEl(e2.soundOn === true, async (v) => {
        await saveUsage({ events: Object.assign({}, ev, { [key]: Object.assign({}, e2, { soundOn: v }) }) })
        setStatus('已保存', 'ok')
      }),
      h('span', { class: 'tip', text: '出声' }),
      h('select', {
        onchange: async (ev2) => {
          await saveUsage({ events: Object.assign({}, ev, { [key]: Object.assign({}, e2, { sel: ev2.target.value }) }) })
          setStatus('已保存', 'ok')
        },
      }, fragOptions(e2.sel || 'frag:ask_a'))
    ))
  }
  panel.appendChild(card)

  const alertCfg = s.alert || {}
  const card2 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '余额与预算提示'))
  card2.appendChild(h('div', { class: 'row' },
    h('span', { class: 'label', text: '余额不足提示' }),
    switchEl(alertCfg.on !== false, async (v) => {
      await saveUsage({ alert: Object.assign({}, alertCfg, { on: v }) })
      setStatus('已保存', 'ok')
    }),
    h('span', { class: 'tip', text: '余额低于' }),
    h('input', {
      type: 'number', min: '0', step: '1', value: String(alertCfg.below == null ? 5 : alertCfg.below),
      onchange: async (e) => {
        await saveUsage({ alert: Object.assign({}, alertCfg, { below: Number(e.target.value) || 0 }) })
        setStatus('已保存', 'ok')
      },
    }),
    h('span', { class: 'tip', text: '元时提醒' })
  ))
  const budgetCfg = s.budget || {}
  card2.appendChild(h('div', { class: 'row' },
    h('span', { class: 'label', text: '每日预算提示' }),
    switchEl(budgetCfg.on !== false, async (v) => {
      await saveUsage({ budget: Object.assign({}, budgetCfg, { on: v }) })
      setStatus('已保存', 'ok')
    }),
    h('span', { class: 'tip', text: '今日消费超过' }),
    h('input', {
      type: 'number', min: '0', step: '1', value: String(budgetCfg.amount == null ? 10 : budgetCfg.amount),
      onchange: async (e) => {
        await saveUsage({ budget: Object.assign({}, budgetCfg, { amount: Number(e.target.value) || 0 }) })
        setStatus('已保存', 'ok')
      },
    }),
    h('span', { class: 'tip', text: '元时提醒' })
  ))
  panel.appendChild(card2)
}

function fragName(id) {
  const f = state.audio.fragments.find((x) => x.id === id)
  return f ? f.name : id
}

async function newAudioGroup() {
  const name = await promptModal('新建音效组', '我的音效')
  if (!name) return
  const press = state.audio.fragments[0] && state.audio.fragments[0].id
  const release = state.audio.fragments[1] && state.audio.fragments[1].id
  if (!press || !release) {
    setStatus('至少需要两个音频片段', 'error')
    return
  }
  const r = await http('POST', '/dsh-whale/audio.json', { action: 'save-group', name, press, release })
  await loadCore()
  render()
  setStatus('已新建音效组', 'ok')
}

/* ================= 记账 ================= */
function currentModel() {
  const models = (state.api && state.api.models) || []
  return models.find((m) => m.id === state.focusModel) || models[0] || null
}

function todayAmount() {
  const t = state.records && state.records.today
  return t ? Number(t.amount || t.total || 0) : 0
}

function days7() {
  const arr = (state.records && state.records.days7) || []
  return arr.slice(-7)
}

function amountOfDay(d) {
  if (!d) return 0
  return Number(d.amount != null ? d.amount : d.total || 0)
}

function monthTotal() {
  const days = (state.records && state.records.all && state.records.all.days) || []
  const now = new Date()
  const ym = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0')
  let sum = 0
  let cur = 'CNY'
  for (const d of days) {
    const day = d.day || d.date || ''
    if (String(day).slice(0, 7) === ym) {
      sum += amountOfDay(d)
      cur = d.currency || cur
    }
  }
  return { sum, cur }
}

function weeks10() {
  const days = (state.records && state.records.all && state.records.all.days) || []
  const map = new Map()
  for (const d of days) {
    const ds = d.day || d.date
    if (!ds) continue
    const t = idOfDay(ds)
    const monday = new Date(t)
    const wd = (t.getDay() + 6) % 7
    monday.setDate(t.getDate() - wd)
    const key = monday.getFullYear() + '-' + String(monday.getMonth() + 1).padStart(2, '0') + '-' + String(monday.getDate()).padStart(2, '0')
    map.set(key, (map.get(key) || 0) + amountOfDay(d))
  }
  const out = []
  const today = new Date()
  const wd = (today.getDay() + 6) % 7
  const thisMonday = new Date(today)
  thisMonday.setDate(today.getDate() - wd)
  for (let i = 9; i >= 0; i--) {
    const m = new Date(thisMonday)
    m.setDate(thisMonday.getDate() - i * 7)
    const key = m.getFullYear() + '-' + String(m.getMonth() + 1).padStart(2, '0') + '-' + String(m.getDate()).padStart(2, '0')
    out.push({ key, label: (m.getMonth() + 1) + '/' + m.getDate(), value: map.get(key) || 0, today: i === 0 })
  }
  return out
}

function dayKeyOf(t) {
  const d = t || new Date()
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')
}

function mondayKeyOf(t) {
  const m = new Date(t)
  const wd = (m.getDay() + 6) % 7
  m.setDate(m.getDate() - wd)
  return dayKeyOf(m)
}

// 由「每天金额」表生成日/周两组柱子（时间正序）
function barsFromDaily(map, cur) {
  const today = new Date()
  const todayKey = dayKeyOf(today)
  const days = []
  for (let i = 6; i >= 0; i--) {
    const t = new Date(today)
    t.setDate(today.getDate() - i)
    const k = dayKeyOf(t)
    const v = Number(map[k]) || 0
    days.push({
      key: k, label: (t.getMonth() + 1) + '/' + t.getDate(), value: v,
      today: k === todayKey, full: k + ' · ' + money(v, cur),
    })
  }
  const wsum = new Map()
  for (const k of Object.keys(map)) {
    const wk = mondayKeyOf(new Date(k + 'T12:00:00'))
    wsum.set(wk, (wsum.get(wk) || 0) + (Number(map[k]) || 0))
  }
  const weeks = []
  const thisMonday = mondayKeyOf(today)
  for (let i = 9; i >= 0; i--) {
    const m = new Date(thisMonday + 'T12:00:00')
    m.setDate(m.getDate() - i * 7)
    const k = dayKeyOf(m)
    const v = wsum.get(k) || 0
    weeks.push({
      key: k, label: (m.getMonth() + 1) + '/' + m.getDate(), value: v,
      today: i === 0, full: k + ' 起那周 · ' + money(v, cur),
    })
  }
  return { days, weeks }
}

// 某个平台的图表数据：内置 DeepSeek 走宿主账本（历史最全），其他平台走主进程的每日快照
function chartSeriesFor(id) {
  const models = (state.api && state.api.models) || []
  const m = models.find((x) => x.id === id) || null
  const builtinId = (state.api && state.api.builtinId) || 'deepseek'
  const isBuiltin = !m || !!m.builtin || id === builtinId

  if (isBuiltin) {
    const cur = (m && m.currency) || (state.records && state.records.today && state.records.today.currency) || 'CNY'
    const days = days7().slice().reverse().map((d) => {
      const ds = d.day || d.date || ''
      const t = ds ? idOfDay(ds) : null
      return {
        label: t ? (t.getMonth() + 1) + '/' + t.getDate() : '—',
        value: amountOfDay(d),
        today: ds === (state.records.today && (state.records.today.day || state.records.today.date)),
        full: ds + ' · ' + money(amountOfDay(d), d.currency || cur),
      }
    })
    const all = (state.records && state.records.all && state.records.all.days) || []
    const keys = all.map((d) => d.day || d.date).filter(Boolean).sort()
    return { days, weeks: weeks10(), cur, from: keys[0] || '' }
  }

  const entry = (state.apiUsage && state.apiUsage.models && state.apiUsage.models[id]) || null
  const cur = (entry && entry.currency) || (m && m.currency) || 'CNY'
  const map = {}
  if (entry && entry.days) {
    for (const k of Object.keys(entry.days)) map[k] = Number(entry.days[k] && entry.days[k].amount) || 0
  }
  const out = barsFromDaily(map, cur)
  const keys = Object.keys(map).filter((k) => Number(map[k]) > 0).sort()
  return { days: out.days, weeks: out.weeks, cur, from: keys[0] || '' }
}

function moneyShort(v) {
  const n = Number(v || 0)
  if (n >= 100) return n.toFixed(0)
  if (n >= 10) return n.toFixed(1)
  if (n >= 1) return n.toFixed(2)
  return n.toFixed(3)
}

function barChart(items, opts) {
  const o = Object.assign({ height: 170, pad: { l: 34, r: 8, t: 12, b: 22 } }, opts || {})
  const W = 620
  const H = o.height
  const innerW = W - o.pad.l - o.pad.r
  const innerH = H - o.pad.t - o.pad.b
  const max = Math.max(0.0001, ...items.map((i) => i.value))
  const svgns = 'http://www.w3.org/2000/svg'
  const svg = document.createElementNS(svgns, 'svg')
  svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H)
  svg.setAttribute('preserveAspectRatio', 'none')
  svg.style.height = H + 'px'

  const ticks = 4
  for (let i = 0; i <= ticks; i++) {
    const y = o.pad.t + (innerH * i) / ticks
    const line = document.createElementNS(svgns, 'line')
    line.setAttribute('x1', String(o.pad.l))
    line.setAttribute('x2', String(W - o.pad.r))
    line.setAttribute('y1', String(y))
    line.setAttribute('y2', String(y))
    line.setAttribute('class', 'gridline')
    svg.appendChild(line)
    const t = document.createElementNS(svgns, 'text')
    t.setAttribute('x', String(o.pad.l - 6))
    t.setAttribute('y', String(y + 3))
    t.setAttribute('text-anchor', 'end')
    t.setAttribute('class', 'axis')
    t.textContent = moneyShort((max * (ticks - i)) / ticks)
    svg.appendChild(t)
  }

  const gap = innerW / items.length
  const bw = Math.min(38, gap * 0.56)
  items.forEach((it, i) => {
    const x = o.pad.l + gap * i + (gap - bw) / 2
    const hgt = Math.max(it.value > 0 ? 2 : 0, (it.value / max) * innerH)
    const r = document.createElementNS(svgns, 'rect')
    r.setAttribute('x', String(x))
    r.setAttribute('y', String(o.pad.t + innerH - hgt))
    r.setAttribute('width', String(bw))
    r.setAttribute('height', String(hgt))
    r.setAttribute('rx', '4')
    r.setAttribute('class', 'bar' + (it.today ? ' today' : ''))
    const tip = document.createElementNS(svgns, 'title')
    tip.textContent = it.full || (it.label + ' · ' + money(it.value))
    r.appendChild(tip)
    svg.appendChild(r)

    const lab = document.createElementNS(svgns, 'text')
    lab.setAttribute('x', String(x + bw / 2))
    lab.setAttribute('y', String(H - 6))
    lab.setAttribute('text-anchor', 'middle')
    lab.setAttribute('class', 'axis')
    lab.textContent = it.label
    svg.appendChild(lab)

    if (it.value > 0) {
      const v = document.createElementNS(svgns, 'text')
      v.setAttribute('x', String(x + bw / 2))
      v.setAttribute('y', String(o.pad.t + innerH - hgt - 4))
      v.setAttribute('text-anchor', 'middle')
      v.setAttribute('class', 'val')
      v.textContent = moneyShort(it.value)
      svg.appendChild(v)
    }
  })
  return svg
}

// 官方入口：报警时一键跳过去看用量/充值
const DS_USAGE_URL = 'https://platform.deepseek.com/usage'
const DS_TOPUP_URL = 'https://platform.deepseek.com/top_up'
function deepseekLinksCard() {
  const open = (url) => () => { API.openExternal(url).catch(() => {}) }
  return h('div', { class: 'card' },
    h('div', { class: 'card-title' }, 'DeepSeek 官方', h('span', { class: 'sub', text: '看用量 / 充值' })),
    h('div', { class: 'row' },
      h('button', { class: 'btn', text: '打开用量页 ↗', onclick: open(DS_USAGE_URL) }),
      h('button', { class: 'btn primary', text: '去充值 ↗', onclick: open(DS_TOPUP_URL) }),
      h('span', { class: 'tip', text: '余额不足或 token 报警时，点一下就能跳过去' })
    )
  )
}

async function renderLedger(panel) {
  if (!state.records) await loadLedger()
  const sub = state.sub.ledger
  const m = currentModel()
  const cur = (m && m.currency) || 'CNY'

  if (sub === 'overview') {
    const bal = state.balance || {}
    const balCur = bal.currency || cur
    const balValue = bal.totalBalance != null ? Number(bal.totalBalance) : null
    const today = todayAmount()
    const t7 = days7().reduce((a, b) => a + amountOfDay(b), 0)
    const mt = monthTotal()
    const grid = h('div', { class: 'statgrid' },
      h('div', { class: 'stat' },
        h('div', { class: 'k', text: '当前余额' }),
        h('div', { class: 'v', text: balValue == null ? '—' : money(balValue, balCur) }),
        bal.bonusBalance ? h('div', { class: 'k', text: '含赠金 ' + money(bal.bonusBalance, balCur) }) : null),
      h('div', { class: 'stat' }, h('div', { class: 'k', text: '今日已用' }), h('div', { class: 'v', text: money(today, cur) })),
      h('div', { class: 'stat' }, h('div', { class: 'k', text: '近 7 天' }), h('div', { class: 'v', text: money(t7, cur) })),
      h('div', { class: 'stat' + (state.budget.monthly && mt.sum > state.budget.monthly ? ' warn' : '') },
        h('div', { class: 'k', text: '本月累计' }), h('div', { class: 'v', text: money(mt.sum, mt.cur || cur) }))
    )
    panel.appendChild(h('div', { class: 'card' }, h('div', { class: 'card-title' }, '今天'), grid))

    const info = []
    info.push(h('div', { class: 'row' }, h('span', { class: 'label', text: '当前模型' }), h('span', { text: m ? m.name : '未配置' })))
    info.push(h('div', { class: 'row' }, h('span', { class: 'label', text: '余额来源' }), h('span', { text: bal.balanceSource === 'account' ? '平台账号登录态' : (bal.balanceSource || '平台账号') })))
    info.push(h('div', { class: 'row' },
      h('span', { class: 'label', text: '当前时段' }),
      h('span', { text: bal.isPeak ? '高峰时段（错峰更便宜）' : '谷时' })))
    if (state.records && state.records.today) {
      info.push(h('div', { class: 'row' }, h('span', { class: 'label', text: '记账方式' }), h('span', { text: state.records.today.label || state.records.today.source || '—' })))
    }
    info.push(h('div', { class: 'row' }, h('span', { class: 'label', text: '更新时间' }), h('span', { text: bal.updatedAt ? new Date(bal.updatedAt).toLocaleTimeString('zh-CN') : '—' })))
    panel.appendChild(h('div', { class: 'card' }, h('div', { class: 'card-title' }, '明细'), ...info))
    panel.appendChild(deepseekLinksCard())

    // 其他平台（非内置）单独列：各自币种、各自的余额与今日已用，不做汇率折算合并
    const others = ((state.api && state.api.models) || []).filter((x) => !x.builtin)
    if (others.length) {
      const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '其他平台', h('span', { class: 'sub', text: '各自平台自己的账，不换算合并' })))
      const list = h('div', { class: 'list' })
      for (const x of others) {
        const c = x.currency || 'CNY'
        const bits = []
        if (x.balance !== null && x.balance !== undefined) bits.push('余额 ' + money(x.balance, c))
        if (Number(x.todayUsage) > 0) bits.push('今日已用 ' + money(x.todayUsage, x.todayUsageCurrency || c))
        if (x.error) bits.push('⚠ ' + String(x.error).slice(0, 36))
        list.appendChild(h('div', { class: 'list-item' },
          h('span', { class: 'name', text: x.name }),
          h('span', { class: 'meta', text: bits.join(' · ') || '还没有数据' }),
          x.hasKey ? h('span', { class: 'tag', text: '已存密钥' }) : h('span', { class: 'meta', text: '未填密钥' })
        ))
      }
      card.appendChild(list)
      panel.appendChild(card)
    }
    return
  }

  if (sub === 'quota') {
    const b = state.budget || {}
    const today = todayAmount()
    const mt = monthTotal()
    const monthly = Number(b.monthly || 0)
    const daily = Number(b.daily || 0)
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '额度', h('span', { class: 'sub', text: '这里填的额度会同步给挂件做提示' })))

    const dailyBar = h('div', { class: 'progress' }, h('i'))
    const monthlyBar = h('div', { class: 'progress' }, h('i'))
    function paint() {
      const dp = daily > 0 ? Math.min(1, today / daily) : 0
      dailyBar.firstChild.style.width = (dp * 100).toFixed(1) + '%'
      dailyBar.className = 'progress' + (dp >= 1 ? ' over' : dp >= 0.8 ? ' warn' : '')
      const mp = monthly > 0 ? Math.min(1, mt.sum / monthly) : 0
      monthlyBar.firstChild.style.width = (mp * 100).toFixed(1) + '%'
      monthlyBar.className = 'progress' + (mp >= 1 ? ' over' : mp >= 0.8 ? ' warn' : '')
    }

    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '每日计划额度' }),
      h('input', {
        type: 'number', min: '0', step: '1', value: daily ? String(daily) : '', placeholder: '不限',
        onchange: async (e) => {
          const v = Number(e.target.value) || 0
          state.budget.daily = v
          await API.putBudget({ daily: v })
          await saveUsage({ budget: Object.assign({}, state.usage.budget || {}, { amount: v, on: v > 0 }) })
          setStatus('每日额度已保存', 'ok'); render()
        },
      }),
      h('span', { class: 'tip', text: '元' }),
      h('span', { class: 'tip', text: '今日 ' + money(today, cur) + ' / ' + (daily ? money(daily, cur) : '未设置') })
    ))
    if (daily > 0) card.appendChild(h('div', { class: 'row' }, h('div', { class: 'grow' }, dailyBar)))

    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '每月使用额度' }),
      h('input', {
        type: 'number', min: '0', step: '10', value: monthly ? String(monthly) : '', placeholder: '不限',
        onchange: async (e) => {
          const v = Number(e.target.value) || 0
          state.budget.monthly = v
          await API.putBudget({ monthly: v })
          setStatus('每月额度已保存', 'ok'); render()
        },
      }),
      h('span', { class: 'tip', text: '元' }),
      h('span', { class: 'tip', text: '本月 ' + money(mt.sum, mt.cur || cur) + ' / ' + (monthly ? money(monthly, cur) : '未设置') })
    ))
    if (monthly > 0) card.appendChild(h('div', { class: 'row' }, h('div', { class: 'grow' }, monthlyBar)))
    panel.appendChild(card)

    const card2 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '报警'))
    card2.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '余量不足报警' }),
      switchEl(b.warnOn !== false, async (v) => { state.budget.warnOn = v; await API.putBudget({ warnOn: v }); setStatus('已保存', 'ok') }),
      h('span', { class: 'tip', text: '剩余额度少于' }),
      h('input', {
        type: 'number', min: '0', max: '100', step: '5', value: String(b.warnPercent == null ? 20 : b.warnPercent),
        onchange: async (e) => { const v = Number(e.target.value) || 0; state.budget.warnPercent = v; await API.putBudget({ warnPercent: v }); setStatus('已保存', 'ok') },
      }),
      h('span', { class: 'tip', text: '% 时提醒' })
    ))
    card2.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '计划超额报警' }),
      switchEl(b.overOn !== false, async (v) => { state.budget.overOn = v; await API.putBudget({ overOn: v }); setStatus('已保存', 'ok') }),
      h('span', { class: 'tip', text: '当天/当月超过计划额度时提醒（走系统通知）' })
    ))
    card2.appendChild(h('div', { class: 'row' }, h('span', { class: 'tip', text: '提示：挂件上那两句「余额低于 X」「今日已超预算」的文案，在「音效 → 提示事件」里可以改。' })))
    panel.appendChild(card2)
    panel.appendChild(deepseekLinksCard())
    paint()
    return
  }

  if (sub === 'charts') {
    let opts = ((state.api && state.api.models) || []).map((x) => ({
      id: x.id, name: x.name || x.id, cur: x.currency || 'CNY', builtin: !!x.builtin,
    }))
    if (!opts.length) opts = [{ id: (state.api && state.api.builtinId) || 'deepseek', name: 'DeepSeek', cur: 'CNY', builtin: true }]
    if (!state.chartModel || !opts.some((o) => o.id === state.chartModel)) state.chartModel = opts[0].id
    const series = chartSeriesFor(state.chartModel)

    const sel = h('select', {
      onchange: (e) => { state.chartModel = e.target.value; render() },
    }, opts.map((o) => h('option', {
      value: o.id,
      text: o.name + (o.builtin ? '' : '（' + o.cur + '）'),
      selected: o.id === state.chartModel,
    })))
    panel.appendChild(h('div', { class: 'card' },
      h('div', { class: 'card-title' }, '平台', h('span', { class: 'sub', text: '各平台各自算，不换算合并' })),
      h('div', { class: 'row' },
        h('span', { class: 'label', text: '查看' }),
        sel,
        h('span', { class: 'tip', text: series.from ? ('数据自 ' + series.from + ' 起') : '还没有历史数据' })
      )
    ))

    const d7sum = series.days.reduce((a, b) => a + b.value, 0)
    const c1 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '每日对比',
      h('span', { class: 'sub', text: '最近 7 天 · 合计 ' + money(d7sum, series.cur) })))
    c1.appendChild(h('div', { class: 'chart' }, barChart(series.days)))
    panel.appendChild(c1)

    const w10sum = series.weeks.reduce((a, b) => a + b.value, 0)
    const c2 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '每周对比',
      h('span', { class: 'sub', text: '最近 10 周（按周一为起点）· 合计 ' + money(w10sum, series.cur) })))
    c2.appendChild(h('div', { class: 'chart' }, barChart(series.weeks)))
    panel.appendChild(c2)

    if (!d7sum && !w10sum) {
      panel.appendChild(h('div', { class: 'card' }, h('div', { class: 'tip', text: state.chartModel === ((state.api && state.api.builtinId) || 'deepseek')
        ? '内置平台还没有用量记录，等宿主那边记上就有了。'
        : '这个平台还没攒到用量。其他平台没有每日历史接口，桌面版每 5 分钟存一次快照来攒，从记录开始那天往后才有柱子。' })))
    }
    return
  }

  // api
  const models = (state.api && state.api.models) || []
  const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, 'API 与模型', h('span', { class: 'sub', text: '切换后，上面的余额/记账会按这个模型显示' })))
  const list = h('div', { class: 'list' })
  for (const mm of models) {
    const cur = mm.currency || 'CNY'
    const bits = []
    if (mm.balance !== null && mm.balance !== undefined) bits.push('余额 ' + money(mm.balance, cur))
    if (Number(mm.todayUsage) > 0) bits.push('今日已用 ' + money(mm.todayUsage, mm.todayUsageCurrency || cur))
    if (mm.error) bits.push('⚠ ' + String(mm.error).slice(0, 36))
    list.appendChild(h('div', { class: 'list-item' },
      h('input', {
        type: 'radio', name: 'focusmodel', checked: mm.id === state.focusModel,
        onchange: () => { state.focusModel = mm.id; render(); setStatus('已切到「' + mm.name + '」', 'ok') },
      }),
      h('span', { class: 'name', text: mm.name }),
      h('span', { class: 'meta', text: bits.join(' · ') || (mm.currency || '') }),
      mm.hasKey ? h('span', { class: 'tag', text: '已存密钥' }) : h('span', { class: 'meta', text: '未填密钥（也可走平台登录态）' }),
      mm.canAdjustBalance ? h('span', { class: 'tag', text: '可校正余额' }) : null,
      mm.builtin ? null : h('button', {
        class: 'btn', text: '删除',
        onclick: async () => {
          try {
            await http('POST', '/dsh-whale/api-models.json', { action: 'delete', id: mm.id })
            setStatus('已删除「' + mm.name + '」', 'ok'); await loadLedger(); render()
          } catch (e) { setStatus('删除失败：' + e.message, 'error') }
        },
      })
    ))
  }
  if (!models.length) list.appendChild(h('div', { class: 'empty', text: '还没有模型' }))
  card.appendChild(list)
  panel.appendChild(card)

  const mm = currentModel()
  if (mm) {
    const card2 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, mm.name + ' · 设置'))
    card2.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: 'API Key' }),
      h('input', {
        type: 'password', placeholder: mm.hasKey ? '已保存，留空则不修改' : '填这个平台的 Key',
        id: 'keyInput', class: 'grow',
      }),
      h('button', {
        class: 'btn primary', text: '保存 Key',
        onclick: async () => {
          const v = $('#keyInput').value.trim()
          if (!v) { setStatus('Key 为空', 'error'); return }
          try {
            await http('POST', '/dsh-whale/api-models.json', { action: 'set-key', keyRef: mm.keyRef, keyValue: v })
            setStatus('Key 已保存', 'ok'); await loadLedger(); render()
          } catch (e) { setStatus('保存失败：' + e.message, 'error') }
        },
      })
    ))
    card2.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '余额查询' }),
      h('span', {
        class: 'tip',
        text: (function () {
          const tpl = ((state.api && state.api.templates) || []).find((t) => t.id === mm.id)
          return tpl && tpl.hasBalance === false ? '这个平台不提供余额接口，只能看本地记账' : '这个平台支持查余额'
        })(),
      })
    ))
    if (mm.canAdjustBalance) {
      card2.appendChild(h('div', { class: 'row' },
        h('span', { class: 'label', text: '余额校正' }),
        h('input', { type: 'number', step: '0.01', id: 'adjInput', placeholder: '实际余额' }),
        h('button', {
          class: 'btn', text: '校正',
          onclick: async () => {
            const v = Number($('#adjInput').value)
            if (!isFinite(v)) { setStatus('填个数字', 'error'); return }
            try {
              await http('POST', '/dsh-whale/balance-adjustments.json', { amount: v })
              setStatus('已校正', 'ok'); await loadLedger(); render()
            } catch (e) { setStatus('校正失败：' + e.message, 'error') }
          },
        })
      ))
    }
    panel.appendChild(card2)
  }

  /* 添加其他平台：选模板 + 填 Key（需要时再填接口地址），保存后就能查余额、按余额差记今日已用 */
  const tpls = ((state.api && state.api.templates) || [])
    .slice()
    .sort((a, b) => String(a.sortKey || a.name).localeCompare(String(b.sortKey || b.name)))
  const cardAdd = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '添加其他平台', h('span', { class: 'sub', text: '填这个平台的 Key 就能查余额、记今日已用' })))
  if (!tpls.length) {
    cardAdd.appendChild(h('div', { class: 'empty', text: '没读到平台模板，试试点「重新载入」' }))
  } else {
    const sel = h('select', { id: 'tplSel', class: 'grow' })
    for (const t of tpls) sel.appendChild(h('option', { value: t.id, text: t.name + (t.hasBalance ? '' : '（无余额接口）') }))
    const hint = h('span', { class: 'tip', text: '' })
    const syncHint = () => {
      const t = tpls.find((x) => x.id === sel.value) || {}
      const bits = [t.currency ? '币种 ' + t.currency : '', t.hasBalance ? '可查余额' : '无余额接口，只按会话估算', t.needsBaseUrl ? '需要填接口地址' : '']
      hint.textContent = bits.filter(Boolean).join(' · ')
      const needsBase = !!t.needsBaseUrl
      baseRow.style.display = needsBase ? '' : 'none'
      allowRow.style.display = needsBase ? '' : 'none'
    }
    const baseInp = h('input', { type: 'text', id: 'newBase', class: 'grow', placeholder: '例如 https://api.xxx.com（不带 /v1）' })
    const allowChk = h('input', { type: 'checkbox', id: 'newAllow', checked: true })
    const baseRow = h('div', { class: 'row' }, h('span', { class: 'label', text: '接口地址' }), baseInp)
    const allowRow = h('div', { class: 'row' }, h('span', { class: 'label', text: '允许发凭据到此地址' }), allowChk,
      h('span', { class: 'meta', text: '自建/中转站必须勾上，否则 Key 不会发过去' }))
    sel.addEventListener('change', syncHint)
    // 默认落在「OpenAI 兼容中转站」上（最常用的“其他平台”），没有就退回第一个
    if (tpls.some((t) => t.id === 'openai_compat')) sel.value = 'openai_compat'
    cardAdd.appendChild(h('div', { class: 'row' }, h('span', { class: 'label', text: '平台' }), sel, hint))
    cardAdd.appendChild(h('div', { class: 'row' }, h('span', { class: 'label', text: '显示名称' }),
      h('input', { type: 'text', id: 'newName', class: 'grow', placeholder: '留空就用平台名' })))
    cardAdd.appendChild(h('div', { class: 'row' }, h('span', { class: 'label', text: 'API Key' }),
      h('input', { type: 'password', id: 'newKey', class: 'grow', placeholder: '这个平台的 Key' })))
    cardAdd.appendChild(baseRow)
    cardAdd.appendChild(allowRow)
    cardAdd.appendChild(h('div', { class: 'row' },
      h('button', {
        class: 'btn primary', text: '保存并查一次余额',
        onclick: async () => {
          const t = tpls.find((x) => x.id === sel.value)
          if (!t) { setStatus('先选一个平台', 'error'); return }
          const key = ($('#newKey').value || '').trim()
          const baseUrl = ($('#newBase').value || '').trim()
          if (!key) { setStatus('先填这个平台的 Key', 'error'); return }
          if (t.needsBaseUrl && !baseUrl) { setStatus('这个平台要填接口地址', 'error'); return }
          const model = {
            provider: t.id,
            name: ($('#newName').value || '').trim() || t.name,
            currency: t.currency,
            keyRef: t.keyRef,
            baseUrl,
          }
          if (baseUrl && $('#newAllow').checked) model.allowCustomHost = true
          try {
            const r = await http('POST', '/dsh-whale/api-models.json', { action: 'save', model, keyValue: key })
            setStatus('已添加「' + model.name + '」' + (r.keySaved ? '' : '，但 Key 没存上'), r.keySaved ? 'ok' : 'error')
            await loadLedger(); render()
          } catch (e) { setStatus('添加失败：' + e.message, 'error') }
        },
      }),
      h('button', {
        class: 'btn', text: '刷新列表',
        onclick: async () => { await loadLedger(); render(); setStatus('已刷新', 'ok') },
      })
    ))
    syncHint()
  }
  panel.appendChild(cardAdd)
}

/* ================= 资源管理辅助 ================= */
function withTimeout(p, ms) {
  return Promise.race([
    p,
    new Promise((_, reject) => setTimeout(() => reject(new Error('超时')), ms || 6000)),
  ])
}

async function safeGet(path, ms) {
  try {
    return await withTimeout(http('GET', path), ms)
  } catch (err) {
    return null
  }
}

let resPreviewAudio = null
function previewFragment(f) {
  try {
    if (resPreviewAudio) {
      resPreviewAudio.pause()
      resPreviewAudio = null
    }
    const a = new Audio('/dsh-whale/audio-fragment?id=' + encodeURIComponent(f.id))
    a.volume = Number(state.size.vol == null ? 0.9 : state.size.vol)
    a.onended = () => { resPreviewAudio = null }
    resPreviewAudio = a
    a.play().catch(() => setStatus('试听失败', 'error'))
  } catch (err) {
    setStatus('试听失败', 'error')
  }
}

async function deleteFragment(f) {
  if (f.preset) return
  const ok = await confirmModal('删除音频片段', '确定删除「' + f.name + '」？引用它的音效组会自动回退预设。')
  if (!ok) return
  try {
    await http('POST', '/dsh-whale/audio.json', { action: 'delete-fragment', id: f.id })
    await loadCore()
    render()
    setStatus('已删除', 'ok')
  } catch (err) {
    setStatus('删除失败：' + err.message, 'error')
  }
}

async function deleteSoundGroup(g) {
  if (g.preset) return
  const ok = await confirmModal('删除音效组', '确定删除「' + g.name + '」？')
  if (!ok) return
  try {
    await http('POST', '/dsh-whale/audio.json', { action: 'delete-group', id: g.id })
    await loadCore()
    render()
    setStatus('已删除', 'ok')
  } catch (err) {
    setStatus('删除失败：' + err.message, 'error')
  }
}

async function renameSoundGroup(g) {
  if (g.preset) return
  const name = await promptModal('重命名音效组', g.name)
  if (name === null || !name.trim()) return
  try {
    await http('POST', '/dsh-whale/audio.json', {
      action: 'save-group', id: g.id, name: name.trim().slice(0, 20), press: g.press, release: g.release,
    })
    await loadCore()
    render()
    setStatus('已重命名', 'ok')
  } catch (err) {
    setStatus('重命名失败：' + err.message, 'error')
  }
}

async function deleteBubbleImg(im) {
  if (im.builtin) return
  const ok = await confirmModal('删除泡泡图片', '确定删除「' + (im.name || im.id) + '」？正在引用它的泡泡会显示不出来。')
  if (!ok) return
  try {
    await http('POST', '/dsh-whale/bubble-img-upload.json', { action: 'delete', id: im.id })
    render()
    setStatus('已删除', 'ok')
  } catch (err) {
    setStatus('删除失败：' + err.message, 'error')
  }
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader()
    fr.onload = () => resolve(String(fr.result || ''))
    fr.onerror = () => reject(new Error('读取文件失败'))
    fr.readAsDataURL(file)
  })
}

function pickLocalFile(accept) {
  return new Promise((resolve) => {
    const inp = document.createElement('input')
    inp.type = 'file'
    inp.accept = accept
    inp.style.display = 'none'
    document.body.appendChild(inp)
    let done = false
    const finish = (f) => {
      if (done) return
      done = true
      try { inp.remove() } catch (err) {}
      resolve(f || null)
    }
    inp.onchange = () => finish(inp.files && inp.files[0])
    inp.addEventListener('cancel', () => finish(null))
    window.addEventListener('focus', () => setTimeout(() => finish(inp.files && inp.files[0]), 500), { once: true })
    inp.click()
  })
}

async function importBubbleImg() {
  const file = await pickLocalFile('image/png,image/gif')
  if (!file) return
  if (!/^image\/(png|gif)$/.test(file.type)) {
    setStatus('只支持 PNG / GIF', 'error')
    return
  }
  if (file.size > 8 * 1024 * 1024) {
    setStatus('图片超过 8MB', 'error')
    return
  }
  setStatus('正在导入…')
  try {
    const dataUrl = await readFileAsDataUrl(file)
    const name = String(file.name || '图片').replace(/\.[^.]+$/, '').slice(0, 20)
    await http('POST', '/dsh-whale/bubble-img-upload.json', { action: 'upload', name, data: dataUrl })
    render()
    setStatus('已导入', 'ok')
  } catch (err) {
    setStatus('导入失败：' + err.message, 'error')
  }
}

async function renameBubbleImg(im) {
  if (im.builtin) return
  const name = await promptModal('重命名泡泡图片', im.name || im.id)
  if (name === null || !name.trim()) return
  setStatus('正在保存…')
  try {
    const res = await fetch('/dsh-whale/bubble-img.png?id=' + encodeURIComponent(im.id), { cache: 'no-store' })
    if (!res.ok) throw new Error('读不到原图')
    const dataUrl = await readFileAsDataUrl(await res.blob())
    await http('POST', '/dsh-whale/bubble-img-upload.json', {
      action: 'upload', name: name.trim().slice(0, 20), data: dataUrl,
    })
    await http('POST', '/dsh-whale/bubble-img-upload.json', { action: 'delete', id: im.id })
    render()
    setStatus('已重命名', 'ok')
  } catch (err) {
    setStatus('重命名失败：' + err.message, 'error')
  }
}

/* ================= 其他 ================= */
async function renderMisc(panel) {
  const sub = state.sub.misc

  if (sub === 'window') {
    if (!state.snap) await loadSnap()
    const gapOn = state.size.scrollGapOn === true
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '窗口'))
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '避让滚动条' }),
      switchEl(gapOn, async (v) => { await saveSize({ scrollGapOn: v }); setStatus('已保存', 'ok'); render() }),
      h('span', { class: 'tip', text: '开启后挂件右侧' }),
      h('input', {
        type: 'number', min: '0', step: '1', value: String(state.size.scrollGapPx == null ? 17 : state.size.scrollGapPx),
        disabled: !gapOn,
        onchange: async (e) => { await saveSize({ scrollGapPx: Number(e.target.value) || 0 }); setStatus('已保存', 'ok') },
      }),
      h('span', { class: 'tip', text: 'px，0 表示贴边' })
    ))
    card.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '隐藏菜单按钮' }),
      switchEl(state.size.menuBtnHide === true, async (v) => { await saveSize({ menuBtnHide: v }); setStatus(v ? '已隐藏菜单按钮（右键小鲸鱼可唤出）' : '菜单按钮已恢复', 'ok') })
    ))
    panel.appendChild(card)

    // 吸附与翻转
    const snap = state.snap || { mode: 'ratio', ratio: { L: 10, T: 0, R: 10, B: 15, F: 50 }, px: { L: 80, T: 0, R: 80, B: 80, F: 640 } }
    const mode = snap.mode || 'ratio'
    const card2 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '吸附与翻转', h('span', { class: 'sub', text: '左边/右边贴边吸附，翻转线左侧镜像' })))
    card2.appendChild(h('div', { class: 'row' },
      h('span', { class: 'label', text: '模式' }),
      h('select', {
        id: 'snapMode',
        onchange: () => { card2._mode = $('#snapMode').value; render() },
      },
        h('option', { value: 'off', text: '关闭吸附', selected: mode === 'off' }),
        h('option', { value: 'ratio', text: '按屏幕百分比', selected: mode === 'ratio' }),
        h('option', { value: 'px', text: '按像素', selected: mode === 'px' })
      )
    ))
    const useMode = mode === 'off' ? 'off' : mode
    const set = useMode === 'px' ? (snap.px || {}) : (snap.ratio || {})
    const grid = h('div', { class: 'snapgrid' })
    const keys = [['L', '左吸附区'], ['T', '上吸附区'], ['R', '右吸附区'], ['B', '下吸附区'], ['F', '翻转线']]
    const inputs = {}
    for (const [k, label] of keys) {
      inputs[k] = h('input', { type: 'number', min: '0', step: '1', value: String(Math.round(Number(set[k] || 0))), disabled: useMode === 'off' })
      grid.appendChild(h('div', null, h('label', { text: label }), inputs[k]))
    }
    card2.appendChild(h('div', { class: 'row' }, grid))
    card2.appendChild(h('div', { class: 'row' },
      h('span', { class: 'tip', text: useMode === 'px' ? '单位：像素' : '单位：屏幕的百分比（0-100）' }),
      h('button', {
        class: 'btn primary', text: '应用',
        onclick: async () => {
          const next = Object.assign({}, snap)
          next.mode = $('#snapMode').value
          const vals = {}
          for (const [k] of keys) vals[k] = Number(inputs[k].value) || 0
          if (next.mode === 'px') next.px = vals
          else if (next.mode === 'ratio') next.ratio = vals
          const r = await API.putSnap(next)
          if (r && r.ok) { state.snap = next; setStatus('吸附设置已应用（挂件会重新载入一次）', 'ok') }
          else setStatus('应用失败：' + ((r && r.error) || ''), 'error')
        },
      })
    ))
    panel.appendChild(card2)
    return
  }

  if (sub === 'res') {
    // 资源管理：角色形象 / 泡泡图片 / 音频片段 / 音效组 —— 导入、改名、换图、删除都在这里
    const [rolesRes, bubRes, audioRes] = await Promise.all([
      safeGet('/dsh-whale/roles.json'),
      safeGet('/dsh-whale/bubble-imgs.json'),
      safeGet('/dsh-whale/audio.json'),
    ])
    const roles = rolesRes && Array.isArray(rolesRes.roles) ? rolesRes.roles : state.roles || []
    if (rolesRes && Array.isArray(rolesRes.roles)) state.roles = roles
    const imgs = bubRes && Array.isArray(bubRes.images) ? bubRes.images : []
    const groups = audioRes && Array.isArray(audioRes.groups) ? audioRes.groups : state.audio.groups || []
    const frags = audioRes && Array.isArray(audioRes.fragments) ? audioRes.fragments : state.audio.fragments || []
    if (audioRes) state.audio = { groups, fragments: frags }

    const thumb = (src) => h('img', { class: 'resthumb', src, alt: '' })
    const miniBtn = (text, fn, danger) => h('button', { class: 'btn ' + (danger ? 'danger ghost' : 'ghost'), text, onclick: fn })
    const item = (...kids) => h('div', { class: 'list-item restitem' }, ...kids)

    // —— 角色形象 ——
    const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '角色形象', h('span', { class: 'sub', text: '改名 · 换图 · 删除' })))
    const l1 = h('div', { class: 'list' })
    for (const r of roles) {
      const url = r.id === 'default' ? r.url || '/dsh-whale/image.png' : '/dsh-whale/role-image.png?id=' + encodeURIComponent(r.id)
      const acts = []
      if (r.id === 'default') {
        acts.push(h('span', { class: 'tag', text: '内置' }))
      } else {
        acts.push(miniBtn('改名', () => renameRole(r)))
        acts.push(miniBtn('换图', () => replaceRoleImage(r)))
        acts.push(miniBtn('删除', () => deleteRole(r), true))
      }
      l1.appendChild(item(thumb(url), h('span', { class: 'name', text: r.name }),
        h('span', { class: 'meta', text: (r.format || 'png') + (r.pinned ? ' · 使用中' : '') }), ...acts))
    }
    if (!roles.length) l1.appendChild(h('div', { class: 'empty', text: '还没有导入过形象' }))
    card.appendChild(l1)
    card.appendChild(h('div', { class: 'row' },
      h('button', { class: 'btn primary', text: '导入角色图片…', onclick: () => importRole() })))
    panel.appendChild(card)

    // —— 泡泡图片 ——
    const card2 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '泡泡图片', h('span', { class: 'sub', text: 'PNG / GIF' })))
    const l2 = h('div', { class: 'list' })
    for (const im of imgs) {
      const acts = [h('span', { class: 'meta', text: im.format || 'png' })]
      if (im.builtin) {
        acts.push(h('span', { class: 'tag', text: '内置' }))
      } else {
        acts.push(miniBtn('改名', () => renameBubbleImg(im)))
        acts.push(miniBtn('删除', () => deleteBubbleImg(im), true))
      }
      l2.appendChild(item(thumb('/dsh-whale/bubble-img.png?id=' + encodeURIComponent(im.id)),
        h('span', { class: 'name', text: im.name || im.id }), ...acts))
    }
    if (!imgs.length) l2.appendChild(h('div', { class: 'empty', text: '没有泡泡图片' }))
    card2.appendChild(l2)
    card2.appendChild(h('div', { class: 'row' },
      h('button', { class: 'btn primary', text: '导入泡泡图片…', onclick: () => importBubbleImg() })))
    panel.appendChild(card2)

    // —— 音效组 ——
    const card3 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '音效组', h('span', { class: 'sub', text: '按下 / 松开 的配对' })))
    const l3 = h('div', { class: 'list' })
    for (const g of groups) {
      const acts = [
        h('span', { class: 'meta', text: fragName(g.press) + ' / ' + fragName(g.release) }),
      ]
      if (g.preset) {
        acts.push(h('span', { class: 'tag', text: '内置' }))
      } else {
        acts.push(miniBtn('改名', () => renameSoundGroup(g)))
        acts.push(miniBtn('删除', () => deleteSoundGroup(g), true))
      }
      l3.appendChild(item(h('span', { class: 'name', text: g.name }), ...acts))
    }
    if (!groups.length) l3.appendChild(h('div', { class: 'empty', text: '还没有音效组' }))
    card3.appendChild(l3)
    panel.appendChild(card3)

    // —— 音频片段 ——
    const card4 = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '音频片段', h('span', { class: 'sub', text: '支持 WAV' })))
    const l4 = h('div', { class: 'list' })
    for (const f of frags) {
      const acts = []
      acts.push(miniBtn('试听', () => previewFragment(f)))
      if (f.preset) {
        acts.push(h('span', { class: 'tag', text: '内置' }))
      } else {
        acts.push(miniBtn('删除', () => deleteFragment(f), true))
      }
      l4.appendChild(item(h('span', { class: 'name', text: f.name }), ...acts))
    }
    if (!frags.length) l4.appendChild(h('div', { class: 'empty', text: '还没有音频片段' }))
    card4.appendChild(l4)
    card4.appendChild(h('div', { class: 'row' },
      h('button', {
        class: 'btn primary', text: '导入 WAV 片段…',
        onclick: async () => {
          const r = await API.importAudio({})
          if (r && r.ok) { await loadCore(); render(); setStatus('已导入', 'ok') }
          else if (r && r.cancelled) setStatus('已取消')
          else setStatus('导入失败：' + ((r && r.error) || ''), 'error')
        },
      })))
    panel.appendChild(card4)
    return
  }

  // app
  const card = h('div', { class: 'card' }, h('div', { class: 'card-title' }, '程序'))
  card.appendChild(h('div', { class: 'row' },
    h('span', { class: 'label', text: '挂件' }),
    h('button', {
      class: 'btn', text: '重新载入挂件',
      onclick: async () => { await API.reloadWidget(); setStatus('挂件已重新载入', 'ok') },
    }),
    h('button', {
      class: 'btn', text: '把挂件唤到最前',
      onclick: async () => { await API.focusWidget(); setStatus('已唤到最前', 'ok') },
    })
  ))
  const auto = await API.getAutostart().catch(() => ({ enabled: false }))
  card.appendChild(h('div', { class: 'row' },
    h('span', { class: 'label', text: '开机自启动' }),
    switchEl(auto.enabled !== false, async (v) => {
      await API.setAutostart(v)
      setStatus(v ? '已设置开机启动' : '已取消开机启动', 'ok')
    }),
    auto.packaged === false ? h('span', { class: 'tip', text: '（开发模式下不会真的写注册表）' }) : null
  ))
  card.appendChild(h('div', { class: 'row' },
    h('span', { class: 'label', text: '退出' }),
    h('button', {
      class: 'btn danger', text: '退出整个程序',
      onclick: async () => {
        const ok = await confirmModal('退出', '挂件和控制中心都会关掉。确定？')
        if (ok) API.quit()
      },
    })
  ))
  panel.appendChild(card)
}

/* ---------------- 弹窗 ---------------- */
function modalBox(title, bodyNodes, footNodes) {
  const modal = $('#modal')
  modal.innerHTML = ''
  const box = h('div', { class: 'modal-box' }, h('h3', { text: title }), ...bodyNodes, h('div', { class: 'foot' }, ...footNodes))
  modal.appendChild(box)
  modal.classList.add('open')
  return { modal, box }
}

function closeModal() {
  const modal = $('#modal')
  modal.classList.remove('open')
  modal.innerHTML = ''
}

function confirmModal(title, message) {
  return new Promise((resolve) => {
    const { modal } = modalBox(title, [h('div', { class: 'tip', text: message })], [
      h('button', { class: 'btn', text: '取消', onclick: () => { closeModal(); resolve(false) } }),
      h('button', { class: 'btn primary', text: '确定', onclick: () => { closeModal(); resolve(true) } }),
    ])
    modal.onclick = (e) => { if (e.target === modal) { closeModal(); resolve(false) } }
  })
}

function promptModal(title, defaultValue) {
  return new Promise((resolve) => {
    const input = h('input', { type: 'text', value: defaultValue || '', style: 'width:100%' })
    const { modal } = modalBox(title, [input], [
      h('button', { class: 'btn', text: '取消', onclick: () => { closeModal(); resolve(null) } }),
      h('button', { class: 'btn primary', text: '保存', onclick: () => { const v = input.value.trim(); closeModal(); resolve(v || null) } }),
    ])
    modal.onclick = (e) => { if (e.target === modal) { closeModal(); resolve(null) } }
    setTimeout(() => { input.focus(); input.select() }, 30)
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { const v = input.value.trim(); closeModal(); resolve(v || null) }
      if (e.key === 'Escape') { closeModal(); resolve(null) }
    })
  })
}

/* ---------------- 启动 ---------------- */
async function boot() {
  for (const b of $$('#tabs .tab')) {
    b.addEventListener('click', () => {
      state.tab = b.dataset.tab
      render()
    })
  }
  $('#btnRefresh').addEventListener('click', async () => {
    setStatus('正在刷新…')
    await loadCore()
    await loadLedger()
    await loadSnap()
    render()
    setStatus('已刷新', 'ok')
  })
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#ctxmenu')) closeCtx()
  })
  window.addEventListener('blur', closeCtx)
  if (API.onTab) API.onTab((tab) => { if (tab) { state.tab = tab; render() } })

  await loadCore()
  await loadLedger()
  await loadSnap()
  render()
  setStatus('就绪')

  // 账目每 30 秒自己刷一次，报警由主进程负责
  setInterval(async () => {
    if (state.tab === 'ledger') {
      await loadLedger()
      render()
    }
  }, 30000)
}

boot()
